import json
import re
from dataclasses import dataclass
from typing import Dict, List, Optional


OEM_DEVICE_PROFILE_COMMAND = (
    "$system=Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue; "
    "$bios=Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue; "
    "$baseboard=Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue; "
    "$tools=@("
    "@{Vendor='Dell';Name='Dell Command Update';Path=\"$env:ProgramFiles\\Dell\\CommandUpdate\\dcu-cli.exe\";Command='dcu-cli.exe /scan'},"
    "@{Vendor='Dell';Name='Dell Command Update';Path=\"${env:ProgramFiles(x86)}\\Dell\\CommandUpdate\\dcu-cli.exe\";Command='dcu-cli.exe /scan'},"
    "@{Vendor='HP';Name='HP Image Assistant';Path='C:\\SWSetup\\HPImageAssistant\\HPImageAssistant.exe';Command='HPImageAssistant.exe'},"
    "@{Vendor='Lenovo';Name='Lenovo System Update';Path=\"$env:ProgramFiles\\Lenovo\\System Update\\tvsu.exe\";Command='tvsu.exe'},"
    "@{Vendor='Lenovo';Name='Lenovo System Update';Path=\"${env:ProgramFiles(x86)}\\Lenovo\\System Update\\tvsu.exe\";Command='tvsu.exe'}"
    "); "
    "$installed=@($tools | Where-Object { $_.Path -and (Test-Path -LiteralPath $_.Path) } | "
    "ForEach-Object { [PSCustomObject]@{Vendor=$_.Vendor;Name=$_.Name;Path=$_.Path;Command=$_.Command} }); "
    "$packages=@(); "
    "try { $packages += Get-AppxPackage -Name '*Lenovo*Vantage*' -ErrorAction SilentlyContinue | "
    "Select-Object Name,Version,PackageFullName } catch {}; "
    "try { $packages += Get-AppxPackage -Name '*Dell*' -ErrorAction SilentlyContinue | "
    "Where-Object { $_.Name -match 'Command|SupportAssist|Update' } | Select-Object Name,Version,PackageFullName } catch {}; "
    "try { $packages += Get-AppxPackage -Name '*HP*' -ErrorAction SilentlyContinue | "
    "Where-Object { $_.Name -match 'Support|Assistant|Command' } | Select-Object Name,Version,PackageFullName } catch {}; "
    "[PSCustomObject]@{"
    "Manufacturer=$system.Manufacturer;"
    "Model=$system.Model;"
    "SystemFamily=$system.SystemFamily;"
    "SystemSKUNumber=$system.SystemSKUNumber;"
    "BIOSVersion=$bios.SMBIOSBIOSVersion;"
    "SerialNumber=$bios.SerialNumber;"
    "BaseBoardProduct=$baseboard.Product;"
    "InstalledTools=$installed;"
    "InstalledPackages=@($packages)"
    "} | ConvertTo-Json -Depth 6"
)


@dataclass(frozen=True)
class OEMVendor:
    id: str
    name: str
    manufacturer_keywords: List[str]
    official_tools: List[str]
    support_url: str
    enterprise_url: str
    update_strategy: str
    safety_note: str

    def to_guidance(self, score: float = 0.0, model: str = "") -> Dict:
        return {
            "id": self.id,
            "vendor": self.name,
            "model": model,
            "official_tools": self.official_tools,
            "support_url": self.support_url,
            "enterprise_url": self.enterprise_url,
            "update_strategy": self.update_strategy,
            "safety_note": self.safety_note,
            "score": round(score, 2),
        }


OEM_VENDORS: List[OEMVendor] = [
    OEMVendor(
        id="dell",
        name="Dell",
        manufacturer_keywords=["dell", "alienware"],
        official_tools=["Dell Command Update", "Dell SupportAssist", "Dell Update Packages"],
        support_url="https://www.dell.com/support/home",
        enterprise_url=(
            "https://www.dell.com/support/manuals/command-update/"
            "dellcommandupdate_3.1_ug/command-line-interface-reference"
        ),
        update_strategy="Use Dell Command Update or enterprise-managed Dell update packages for model-matched driver, BIOS, and firmware updates.",
        safety_note="Use Dell tooling or managed catalogs only; BIOS/firmware updates should be staged and may require power, BitLocker, and reboot checks.",
    ),
    OEMVendor(
        id="hp",
        name="HP",
        manufacturer_keywords=["hp", "hewlett", "hewlett-packard"],
        official_tools=["HP Image Assistant", "HP Support Assistant", "HP Client Management Script Library"],
        support_url="https://support.hp.com/drivers",
        enterprise_url="https://support.hp.com/us-en/document/ish_7636709-7636753-16",
        update_strategy="Use HP Image Assistant or HP enterprise management tooling to analyze and apply HP model-specific drivers, BIOS, and firmware.",
        safety_note="Do not install random driver packages; use HP Image Assistant recommendations or your managed HP catalog.",
    ),
    OEMVendor(
        id="lenovo",
        name="Lenovo",
        manufacturer_keywords=["lenovo", "thinkpad", "thinkcentre", "thinkstation"],
        official_tools=["Lenovo Commercial Vantage", "Lenovo System Update", "SU Helper"],
        support_url="https://support.lenovo.com",
        enterprise_url="https://docs.lenovocdrt.com/guides/lcv/",
        update_strategy="Use Lenovo Commercial Vantage, System Update, or SU Helper for Lenovo model-specific drivers, BIOS, firmware, and diagnostics.",
        safety_note="Prefer Lenovo Commercial Vantage or System Update policies; avoid ad hoc driver reinstall without the Lenovo model catalog.",
    ),
    OEMVendor(
        id="microsoft_surface",
        name="Microsoft Surface",
        manufacturer_keywords=["microsoft", "surface"],
        official_tools=["Windows Update", "Surface MSI driver and firmware packages", "Intune", "Configuration Manager"],
        support_url="https://support.microsoft.com/surface",
        enterprise_url="https://learn.microsoft.com/surface/manage-surface-driver-and-firmware-updates",
        update_strategy="Use Windows Update, Intune, Configuration Manager, or Surface model-specific MSI packages for Surface driver and firmware updates.",
        safety_note="Surface firmware packages must match the exact Surface model and Windows build; prefer managed deployment for enterprises.",
    ),
]


def get_oem_device_profile(executor=None) -> Dict:
    if executor is None:
        from tools.diagnose import run_powershell
        executor = run_powershell

    result = executor(OEM_DEVICE_PROFILE_COMMAND)
    profile = _profile_from_stdout(result.get("stdout", ""))
    vendor = detect_oem_vendor(profile.get("manufacturer", ""), profile.get("model", ""))
    profile["oem_vendor"] = vendor.name if vendor else "Unknown"
    profile["oem_vendor_id"] = vendor.id if vendor else ""
    guidance = search_oem_guidance(
        "driver firmware BIOS update",
        manufacturer=profile.get("manufacturer", ""),
        model=profile.get("model", ""),
        limit=2,
    )["guidance"]

    return {
        "tool": "get_oem_device_profile",
        "profile": profile,
        "guidance": guidance,
        "result": result,
    }


def scan_oem_driver_updates(executor=None) -> Dict:
    if executor is None:
        from tools.diagnose import run_powershell
        executor = lambda command: run_powershell(command, timeout=900)

    profile_result = get_oem_device_profile(executor=executor)
    installer = _select_oem_driver_installer(profile_result.get("profile") or {})
    if not installer:
        return {
            "tool": "scan_oem_driver_updates",
            "profile": profile_result.get("profile") or {},
            "installer": None,
            "supported": False,
            "message": "No supported OEM driver update utility was detected on this endpoint.",
            "result": {"ok": False, "stdout": "", "stderr": "No supported OEM driver update utility detected.", "returncode": 1},
        }

    result = executor(installer["scan_command"])
    return {
        "tool": "scan_oem_driver_updates",
        "profile": profile_result.get("profile") or {},
        "installer": _public_installer(installer),
        "supported": True,
        "message": "OEM driver scan completed." if result.get("ok") else "OEM driver scan could not complete.",
        "result": result,
    }


def install_oem_driver_updates(approved: bool, executor=None) -> Dict:
    if not approved:
        raise ValueError("Install-OEMDriverUpdates requires explicit user approval")
    if executor is None:
        from tools.diagnose import run_powershell
        executor = lambda command: run_powershell(command, timeout=1800)

    profile_result = get_oem_device_profile(executor=executor)
    profile = profile_result.get("profile") or {}
    installer = _select_oem_driver_installer(profile)
    if not installer:
        raise ValueError("No supported OEM driver update utility was detected on this endpoint")

    result = executor(installer["install_command"])
    return {
        "tool": "install_oem_driver_updates",
        "profile": profile,
        "installer": _public_installer(installer),
        "action": {
            "name": "Install-OEMDriverUpdates",
            "tier": 3,
            "type": "action",
            "description": (
                f"Install driver updates only through {installer['name']} for "
                f"{profile.get('oem_vendor') or installer['vendor']} endpoints."
            ),
            "requires_approval": True,
        },
        "result": result,
    }


def install_oem_driver_utility_and_updates(approved: bool, executor=None) -> Dict:
    if not approved:
        raise ValueError("Install-OEMDriverUtilityAndUpdates requires explicit user approval")
    if executor is None:
        from tools.diagnose import run_powershell
        executor = lambda command: run_powershell(command, timeout=1800)

    profile_result = get_oem_device_profile(executor=executor)
    profile = profile_result.get("profile") or {}
    installed_installer = _select_oem_driver_installer(profile)
    utility_was_installed = False

    if installed_installer:
        installer = dict(installed_installer)
        installer["already_installed"] = True
        result = executor(installer["install_command"])
    else:
        installer = _select_oem_driver_utility_installer(profile)
        if not installer:
            vendor = profile.get("oem_vendor") or profile.get("manufacturer") or "this endpoint"
            raise ValueError(
                f"No supported OEM driver utility installer is available for {vendor}. "
                "Use the vendor's managed driver workflow or enterprise deployment tool."
            )
        utility_was_installed = True
        result = executor(installer["install_command"])

    return {
        "tool": "install_oem_driver_utility_and_updates",
        "profile": profile,
        "installer": _public_installer(installer),
        "utility_was_installed": utility_was_installed,
        "action": {
            "name": "Install-OEMDriverUtilityAndUpdates",
            "tier": 3,
            "type": "action",
            "description": (
                f"Install or verify {installer['name']} for "
                f"{profile.get('oem_vendor') or installer['vendor']} endpoints, then run OEM driver updates."
            ),
            "requires_approval": True,
        },
        "result": result,
    }


def oem_driver_utility_install_plan(profile: Dict) -> Optional[Dict]:
    installed_installer = _select_oem_driver_installer(profile)
    if installed_installer:
        plan = _public_installer(installed_installer)
        plan["already_installed"] = True
        plan["available"] = True
        return plan

    utility_installer = _select_oem_driver_utility_installer(profile)
    if not utility_installer:
        return None

    plan = _public_installer(utility_installer)
    plan["already_installed"] = False
    plan["available"] = True
    return plan


def search_oem_guidance(
    query: str,
    manufacturer: str = "",
    model: str = "",
    limit: int = 4,
) -> Dict:
    ranked = _rank_oem_vendors(query, manufacturer=manufacturer, model=model)
    return {
        "tool": "search_oem_guidance",
        "query": query,
        "manufacturer": manufacturer,
        "model": model,
        "guidance": [vendor.to_guidance(score=score, model=model) for vendor, score in ranked[: max(1, int(limit or 4))]],
    }


def oem_guidance_for_request(request: str, manufacturer: str = "", model: str = "", limit: int = 2) -> List[Dict]:
    text = str(request or "").lower()
    if not re.search(r"\b(oem|vendor|manufacturer|driver|drivers|bios|firmware|dock|docking|camera|webcam)\b", text):
        return []
    return search_oem_guidance(request, manufacturer=manufacturer, model=model, limit=limit)["guidance"]


def detect_oem_vendor(manufacturer: str = "", model: str = "") -> Optional[OEMVendor]:
    text = f"{manufacturer} {model}".lower()
    for vendor in OEM_VENDORS:
        if any(keyword in text for keyword in vendor.manufacturer_keywords):
            return vendor
    return None


def _rank_oem_vendors(query: str, manufacturer: str = "", model: str = "") -> List:
    text = f"{query} {manufacturer} {model}".lower()
    tokens = _tokens(text)
    ranked = []
    generic_oem_request = bool({"oem", "vendor", "manufacturer", "driver", "drivers", "bios", "firmware"}.intersection(tokens))

    for vendor in OEM_VENDORS:
        score = 0.0
        for keyword in vendor.manufacturer_keywords:
            if keyword in text:
                score += 8.0
        for tool in vendor.official_tools:
            score += len(tokens.intersection(_tokens(tool))) * 1.5
        if vendor.id == "microsoft_surface" and "surface" in text:
            score += 8.0
        if generic_oem_request and score == 0:
            score = 0.5
        if score > 0:
            ranked.append((vendor, score))

    ranked.sort(key=lambda item: (item[1], item[0].name), reverse=True)
    return ranked


def _select_oem_driver_installer(profile: Dict) -> Optional[Dict]:
    vendor = str(profile.get("oem_vendor_id") or "").lower()
    tools = profile.get("installed_tools") or []
    for tool in tools:
        name = str(tool.get("name") or "")
        path = str(tool.get("path") or "")
        if not path:
            continue
        name_lower = name.lower()
        if vendor == "dell" and "dell command update" in name_lower:
            return _dell_installer(name, path)
        if vendor == "hp" and "hp image assistant" in name_lower:
            return _hp_installer(name, path)
        if vendor == "lenovo" and "lenovo system update" in name_lower:
            return _lenovo_installer(name, path)
    return None


def _select_oem_driver_utility_installer(profile: Dict) -> Optional[Dict]:
    vendor = str(profile.get("oem_vendor_id") or "").lower()
    if not vendor:
        detected = detect_oem_vendor(profile.get("manufacturer", ""), profile.get("model", ""))
        vendor = detected.id if detected else ""

    if vendor == "dell":
        return _dell_utility_installer()
    if vendor == "hp":
        return _hp_utility_installer()
    if vendor == "lenovo":
        return _lenovo_utility_installer()
    return None


def _dell_installer(name: str, path: str) -> Dict:
    quoted = _ps_single_quote(path)
    return {
        "vendor": "Dell",
        "name": name or "Dell Command Update",
        "path": path,
        "scan_command": f"& {quoted} /scan -updateType=driver",
        "install_command": f"& {quoted} /applyUpdates -updateType=driver -reboot=disable",
    }


def _dell_utility_installer() -> Dict:
    command = (
        _winget_install_command("Dell.CommandUpdate", "Dell Command Update")
        + "$paths=@('C:\\Program Files\\Dell\\CommandUpdate\\dcu-cli.exe','C:\\Program Files (x86)\\Dell\\CommandUpdate\\dcu-cli.exe'); "
        "$tool=($paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1); "
        "if (-not $tool) { throw 'Dell Command Update was installed, but dcu-cli.exe was not found in the expected OEM paths.' }; "
        "& $tool /applyUpdates -updateType=driver -reboot=disable; "
        "if ($LASTEXITCODE -ne 0) { throw \"Dell Command Update failed with exit code $LASTEXITCODE\" }; "
        "Write-Output 'Dell Command Update driver installation command completed.'"
    )
    return {
        "vendor": "Dell",
        "name": "Dell Command Update",
        "path": "C:\\Program Files\\Dell\\CommandUpdate\\dcu-cli.exe",
        "package_id": "Dell.CommandUpdate",
        "install_method": "Windows Package Manager (winget)",
        "install_command": command,
    }


def _hp_installer(name: str, path: str) -> Dict:
    quoted = _ps_single_quote(path)
    setup = (
        "$root=Join-Path $env:ProgramData 'EndpointSupportAgent\\HPIA'; "
        "$download=Join-Path $root 'SoftPaqs'; "
        "New-Item -ItemType Directory -Path $root,$download -Force | Out-Null; "
    )
    common = (
        "/Operation:Analyze /Category:Drivers /Selection:All "
        "/Silent /Noninteractive /ReportFolder:$root /SoftpaqDownloadFolder:$download"
    )
    return {
        "vendor": "HP",
        "name": name or "HP Image Assistant",
        "path": path,
        "scan_command": f"{setup}& {quoted} {common} /Action:List",
        "install_command": f"{setup}& {quoted} {common} /Action:Install",
    }


def _hp_utility_installer() -> Dict:
    command = (
        _winget_install_command("HP.HPCMSL", "HP Client Management Script Library")
        + "$hpiaRoot='C:\\SWSetup\\HPImageAssistant'; "
        "New-Item -ItemType Directory -Path $hpiaRoot -Force | Out-Null; "
        "Import-Module HPCMSL -ErrorAction Stop; "
        "Install-HPImageAssistant -Extract -DestinationPath $hpiaRoot -Quiet; "
        "$tool=(Get-ChildItem -Path $hpiaRoot,'C:\\SWSetup' -Filter HPImageAssistant.exe -Recurse -ErrorAction SilentlyContinue | "
        "Select-Object -First 1 -ExpandProperty FullName); "
        "if (-not $tool) { throw 'HP Image Assistant was not found after installing HP CMSL and extracting HPIA.' }; "
        "$root=Join-Path $env:ProgramData 'EndpointSupportAgent\\HPIA'; "
        "$download=Join-Path $root 'SoftPaqs'; "
        "New-Item -ItemType Directory -Path $root,$download -Force | Out-Null; "
        "& $tool /Operation:Analyze /Category:Drivers /Selection:All /Silent /Noninteractive /ReportFolder:$root /SoftpaqDownloadFolder:$download /Action:Install; "
        "if ($LASTEXITCODE -ne 0) { throw \"HP Image Assistant failed with exit code $LASTEXITCODE\" }; "
        "Write-Output 'HP Image Assistant driver installation command completed.'"
    )
    return {
        "vendor": "HP",
        "name": "HP Image Assistant",
        "path": "C:\\SWSetup\\HPImageAssistant\\HPImageAssistant.exe",
        "package_id": "HP.HPCMSL",
        "install_method": "Windows Package Manager (winget) + HP CMSL",
        "install_command": command,
    }


def _lenovo_installer(name: str, path: str) -> Dict:
    quoted = _ps_single_quote(path)
    common = "/CM -search R -packagetypes 3 -includerebootpackages 0 -nolicense -noicon"
    return {
        "vendor": "Lenovo",
        "name": name or "Lenovo System Update",
        "path": path,
        "scan_command": f"& {quoted} {common} -action LIST",
        "install_command": f"& {quoted} {common} -action INSTALL",
    }


def _lenovo_utility_installer() -> Dict:
    command = (
        _winget_install_command("Lenovo.SystemUpdate", "Lenovo System Update")
        + "$paths=@('C:\\Program Files\\Lenovo\\System Update\\tvsu.exe','C:\\Program Files (x86)\\Lenovo\\System Update\\tvsu.exe'); "
        "$tool=($paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1); "
        "if (-not $tool) { throw 'Lenovo System Update was installed, but tvsu.exe was not found in the expected OEM paths.' }; "
        "& $tool /CM -search R -packagetypes 3 -includerebootpackages 0 -nolicense -noicon -action INSTALL; "
        "if ($LASTEXITCODE -ne 0) { throw \"Lenovo System Update failed with exit code $LASTEXITCODE\" }; "
        "Write-Output 'Lenovo System Update driver installation command completed.'"
    )
    return {
        "vendor": "Lenovo",
        "name": "Lenovo System Update",
        "path": "C:\\Program Files\\Lenovo\\System Update\\tvsu.exe",
        "package_id": "Lenovo.SystemUpdate",
        "install_method": "Windows Package Manager (winget)",
        "install_command": command,
    }


def _winget_install_command(package_id: str, display_name: str) -> str:
    package = _ps_single_quote(package_id)
    label = _ps_single_quote(display_name)
    return (
        "$ErrorActionPreference='Stop'; "
        "$isAdmin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator); "
        "if (-not $isAdmin) { throw 'OEM driver utility installation requires an elevated PowerShell or Command Prompt. Restart the agent as Administrator and try again.' }; "
        "$winget=Get-Command winget -ErrorAction SilentlyContinue; "
        "if (-not $winget) { throw 'Windows Package Manager (winget) was not found. Install App Installer or deploy the OEM utility through your management system.' }; "
        "$wingetPath=$winget.Source; "
        f"Write-Output ('Installing ' + {label} + ' using Windows Package Manager...'); "
        f"& $wingetPath install --id {package} --exact --source winget --accept-package-agreements --accept-source-agreements --silent --disable-interactivity; "
        "if ($LASTEXITCODE -ne 0) { throw \"winget install failed with exit code $LASTEXITCODE\" }; "
    )


def _public_installer(installer: Dict) -> Dict:
    public = {
        "vendor": installer.get("vendor", ""),
        "name": installer.get("name", ""),
        "path": installer.get("path", ""),
    }
    for key in ("package_id", "install_method", "already_installed"):
        if key in installer:
            public[key] = installer.get(key)
    return public


def _profile_from_stdout(stdout: str) -> Dict:
    payload = _json_from_stdout(stdout)
    installed_tools = payload.get("InstalledTools") or []
    installed_packages = payload.get("InstalledPackages") or []
    if isinstance(installed_tools, dict):
        installed_tools = [installed_tools]
    if isinstance(installed_packages, dict):
        installed_packages = [installed_packages]

    return {
        "manufacturer": str(payload.get("Manufacturer") or "").strip(),
        "model": str(payload.get("Model") or "").strip(),
        "system_family": str(payload.get("SystemFamily") or "").strip(),
        "system_sku": str(payload.get("SystemSKUNumber") or "").strip(),
        "bios_version": str(payload.get("BIOSVersion") or "").strip(),
        "serial_number": str(payload.get("SerialNumber") or "").strip(),
        "baseboard_product": str(payload.get("BaseBoardProduct") or "").strip(),
        "installed_tools": [_compact_tool(item) for item in installed_tools if isinstance(item, dict)],
        "installed_packages": [_compact_package(item) for item in installed_packages if isinstance(item, dict)],
    }


def _json_from_stdout(stdout: str) -> Dict:
    text = str(stdout or "").strip()
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"(\{.*\})", text, flags=re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                return {}
    return {}


def _compact_tool(item: Dict) -> Dict:
    return {
        "vendor": str(item.get("Vendor") or item.get("vendor") or "").strip(),
        "name": str(item.get("Name") or item.get("name") or "").strip(),
        "path": str(item.get("Path") or item.get("path") or "").strip(),
        "command": str(item.get("Command") or item.get("command") or "").strip(),
    }


def _compact_package(item: Dict) -> Dict:
    return {
        "name": str(item.get("Name") or item.get("name") or "").strip(),
        "version": str(item.get("Version") or item.get("version") or "").strip(),
    }


def _ps_single_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _tokens(text: str) -> set:
    return set(re.findall(r"[a-z0-9-]+", str(text or "").lower()))
