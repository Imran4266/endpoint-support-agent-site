import json
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Protocol

from mcp_client import MCPClient, MCPClientError
from tools.diagnose import get_tool, get_tools
from tools.endpoint_skills import rank_endpoint_skills
from tools.resolve_issue import IssueRecord, Resolution


class ExternalKnowledgeProvider(Protocol):
    def search(self, issue: str, context: Optional[Dict] = None) -> List[Dict]:
        ...


class StaticExternalKnowledgeProvider:
    """Test-friendly provider that behaves like an external runbook source."""

    def __init__(self, documents: Iterable[Dict]):
        self.documents = list(documents)

    def search(self, issue: str, context: Optional[Dict] = None) -> List[Dict]:
        issue_words = _tokenize(issue)
        matches = []
        for document in self.documents:
            keywords = {keyword.lower() for keyword in document.get("keywords", [])}
            if issue_words.intersection(keywords):
                matches.append(document)
        return matches


class GitHubKnowledgeFileProvider:
    """Reads a JSON export produced from GitHub runbooks or issues.

    The file should contain either a list of documents or an object with a
    `documents` list. Each document may include title, source, keywords, and
    steps. This keeps GitHub behind a provider boundary until a live GitHub MCP
    connector is configured.
    """

    def __init__(self, file_path: str):
        self.file_path = Path(file_path)

    def search(self, issue: str, context: Optional[Dict] = None) -> List[Dict]:
        if not self.file_path.exists():
            return []

        with self.file_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)

        documents = payload.get("documents", payload) if isinstance(payload, dict) else payload
        if not isinstance(documents, list):
            return []

        return StaticExternalKnowledgeProvider(documents).search(issue, context)


class GitHubMCPKnowledgeProvider:
    """Calls a configured GitHub MCP server as an external knowledge source."""

    def __init__(
        self,
        command: Iterable[str],
        tool_name: str,
        repository: Optional[str] = None,
        timeout: float = 15,
    ):
        self.command = tuple(command)
        self.tool_name = tool_name
        self.repository = repository
        self.timeout = timeout

    def search(self, issue: str, context: Optional[Dict] = None) -> List[Dict]:
        arguments = {"query": issue, "context": context or {}}
        if self.repository:
            arguments["repository"] = self.repository

        try:
            with MCPClient(command=self.command, timeout=self.timeout) as client:
                result = client.call_tool(self.tool_name, arguments)
        except MCPClientError:
            return []

        return _documents_from_mcp_result(result)


class KnowledgeBase:
    def __init__(
        self,
        issue_records: Iterable[IssueRecord],
        external_providers: Optional[Iterable[ExternalKnowledgeProvider]] = None,
        llm_client = None,
        model: str = "openrouter/auto",
    ):
        self.issue_records = list(issue_records)
        self.external_providers = list(external_providers or [])
        self.llm_client = llm_client
        self.model = model
        # Pre-compute IDF weights: keywords unique to one record score higher
        self._keyword_idf = self._compute_idf()

    def _compute_idf(self) -> Dict[str, float]:
        """Compute inverse document frequency for each keyword.

        Keywords appearing in fewer records are more distinctive and get
        higher weights.  For example, 'internet' (only in network) gets a
        higher weight than 'install' (in software, intune, patching).
        """
        import math

        # Count how many records contain each keyword
        doc_freq: Dict[str, int] = {}
        for record in self.issue_records:
            for kw in {k.lower() for k in record.keywords}:
                doc_freq[kw] = doc_freq.get(kw, 0) + 1

        n = len(self.issue_records)
        if n == 0:
            return {}
        # IDF = log(total_records / records_containing_keyword) + 1
        return {kw: math.log(n / freq) + 1.0 for kw, freq in doc_freq.items()}

    def resolve(self, issue: str, context: Optional[Dict] = None) -> Resolution:
        record = self._best_record(issue, context or {})
        external_matches = self._external_matches(issue, context or {})
        skill_matches = rank_endpoint_skills(
            issue,
            category=record.category,
            intents=[],
            limit=2,
        )

        external_steps: List[str] = []
        external_sources: List[Dict] = []
        for match in external_matches:
            external_steps.extend(match.get("steps", []))
            external_sources.append(
                {
                    "type": _source_type(match.get("source", "")),
                    "title": match.get("title", "External knowledge"),
                    "source": match.get("source", ""),
                }
            )

        return Resolution(
            title=record.title,
            category=record.category,
            confidence=record.confidence,
            findings=record.findings,
            steps=record.steps,
            external_steps=external_steps,
            diagnostic_tools=get_tools(record.diagnostic_tool_names),
            recommended_action=get_tool(record.recommended_action_name),
            sources=[
                {
                    "type": "local",
                    "title": record.title,
                    "source": f"issue_database:{record.id}",
                }
            ]
            + external_sources,
            skills=[skill.to_dict(score=score) for skill, score in skill_matches],
        )

    def _llm_classify(self, issue: str, context: Dict) -> Optional[IssueRecord]:
        """Use an LLM to semantically classify the issue into an IssueRecord."""
        if not self.llm_client:
            return None

        # Build prompt listing all available records
        categories_text = ""
        for r in self.issue_records:
            categories_text += f"- ID: {r.id} | Title: {r.title} | Keywords: {', '.join(r.keywords)}\n"

        prompt = (
            "You are an IT Support classifier. Map the user's issue to the most appropriate "
            "runbook ID from the list below based on semantic meaning, not just keywords.\n\n"
            f"Available Runbooks:\n{categories_text}\n"
            f"User Issue: '{issue}'\n"
            f"Context: {context}\n\n"
            "Respond ONLY with a JSON object in this exact format: {\"best_id\": \"<ID>\"}. "
            "If none match well, use \"unknown\"."
        )

        try:
            import json
            response = self.llm_client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
                temperature=0.1,
            )
            content = response.choices[0].message.content
            result = json.loads(content)
            best_id = result.get("best_id")
            if best_id:
                for r in self.issue_records:
                    if r.id == best_id:
                        return r
        except Exception:
            pass  # Fall back to IDF scoring on any error
            
        return None

    def _best_record(self, issue: str, context: Dict) -> IssueRecord:
        # Attempt LLM classification first
        llm_record = self._llm_classify(issue, context)
        if llm_record:
            return llm_record

        # Fallback to IDF-weighted keyword scoring
        issue_words = _tokenize(" ".join([issue, " ".join(str(v) for v in context.values())]))
        best_score = -1.0
        best_record = self.issue_records[0]

        for record in self.issue_records:
            record_keywords = {keyword.lower() for keyword in record.keywords}
            matched = issue_words.intersection(record_keywords)
            if not matched:
                continue
            # Sum of IDF weights for matched keywords (distinctive keywords count more)
            idf_score = sum(self._keyword_idf.get(kw, 1.0) for kw in matched)
            # Use record confidence as a tiebreaker
            score = idf_score + (record.confidence * 0.1)
            if score > best_score:
                best_score = score
                best_record = record

        if best_score < 0:
            return IssueRecord(
                id="unknown",
                title="Unknown issue",
                category="general",
                keywords=[],
                findings="I could not match this issue to any known runbooks. Could you provide more details?",
                steps=[],
                diagnostic_tool_names=[],
                recommended_action_name="",
                confidence=0.0
            )

        return best_record

    def _external_matches(self, issue: str, context: Dict) -> List[Dict]:
        matches: List[Dict] = []
        for provider in self.external_providers:
            matches.extend(provider.search(issue, context))
        return matches


def _tokenize(text: str) -> set:
    return set(re.findall(r"[a-z0-9:.-]+", text.lower()))


def _source_type(source: str) -> str:
    return "github" if source.lower().startswith("github") else "external"


def _documents_from_mcp_result(result: Dict) -> List[Dict]:
    if isinstance(result.get("documents"), list):
        return [_github_document(document) for document in result["documents"]]
    if isinstance(result.get("items"), list):
        return [_github_document(document) for document in result["items"]]

    content = result.get("content")
    if isinstance(content, list):
        steps = [
            item.get("text", "")
            for item in content
            if isinstance(item, dict) and item.get("type") == "text" and item.get("text")
        ]
        if steps:
            return [
                {
                    "title": "GitHub MCP result",
                    "source": "github:mcp",
                    "keywords": [],
                    "steps": steps,
                }
            ]

    text = result.get("text")
    if isinstance(text, str) and text.strip():
        return [
            {
                "title": "GitHub MCP result",
                "source": "github:mcp",
                "keywords": [],
                "steps": [text.strip()],
            }
        ]
    return []


def _github_document(document: Dict) -> Dict:
    normalized = dict(document)
    normalized.setdefault("title", "GitHub knowledge")
    normalized.setdefault("source", "github:mcp")
    normalized.setdefault("steps", [])
    return normalized
