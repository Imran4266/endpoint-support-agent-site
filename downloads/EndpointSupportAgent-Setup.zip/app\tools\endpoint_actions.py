import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from tools.diagnose import (
    disable_startup_app,
    execute_diagnostic_tool,
    execute_tool,
    get_tool,
)
from tools.endpoint_skills import rank_endpoint_skills
from tools.oem_support import (
    install_oem_driver_updates,
    install_oem_driver_utility_and_updates,
    oem_guidance_for_request,
)


@dataclass(frozen=True)
class EndpointCapability:
    intent: str
    title: str
    keywords: List[str]
    diagnostic_tools: List[str]
    verification_tools: List[str]
    action_tool: Optional[str] = None
    action_name: Optional[str] = None
    target_kind: Optional[str] = None
    tier: int = 2
    supported: bool = True
    description: str = ""
    unsupported_reason: str = ""

    def to_dict(self) -> Dict:
        return {
            "intent": self.intent,
            "title": self.title,
            "description": self.description,
            "keywords": self.keywords,
            "diagnostic_tools": self.diagnostic_tools,
            "verification_tools": self.verification_tools,
            "action_tool": self.action_tool,
            "action_name": self.action_name,
            "target_kind": self.target_kind,
            "tier": self.tier,
            "supported": self.supported,
            "unsupported_reason": self.unsupported_reason,
        }


CAPABILITIES: List[EndpointCapability] = [
    EndpointCapability(
        intent="startup.disable_app",
        title="Disable startup application",
        keywords=["disable", "remove", "startup", "start-up", "autostart", "login", "logon", "boot", "launch"],
        diagnostic_tools=["Get-StartupPrograms"],
        verification_tools=["Get-StartupPrograms"],
        action_tool="disable_startup_app",
        target_kind="app",
        description="Disable a matching Windows startup entry by app or display name without removing the Startup Apps entry where supported.",
    ),
    EndpointCapability(
        intent="browser.clear_cache",
        title="Clear browser cache",
        keywords=["browser", "chrome", "edge", "firefox", "cache", "cookies", "website", "webpage", "clear"],
        diagnostic_tools=["Get-BrowserStatus", "Get-FirewallProxyStatus", "Test-PortConnection"],
        verification_tools=["Get-BrowserStatus"],
        action_tool="execute_remediation",
        action_name="Clear-BrowserCache",
        description="Close common browsers and clear current-user browser cache folders.",
    ),
    EndpointCapability(
        intent="onedrive.reset_sync",
        title="Reset OneDrive sync",
        keywords=["onedrive", "sync", "syncing", "sharepoint", "file", "files", "upload", "download", "pending", "reset"],
        diagnostic_tools=["Get-OneDriveStatus", "Test-Internet", "Get-DiskUsage"],
        verification_tools=["Get-OneDriveStatus"],
        action_tool="execute_remediation",
        action_name="Reset-OneDriveSync",
        description="Reset and restart the local OneDrive sync client.",
    ),
    EndpointCapability(
        intent="teams.clear_cache",
        title="Clear Teams cache",
        keywords=["teams", "meeting", "chat", "call", "cache", "clear", "sign", "login"],
        diagnostic_tools=["Get-TeamsStatus", "Test-Internet", "Get-HealthReport"],
        verification_tools=["Get-TeamsStatus"],
        action_tool="execute_remediation",
        action_name="Clear-TeamsCache",
        description="Close Teams and clear common Teams cache folders.",
    ),
    EndpointCapability(
        intent="outlook.reset_client",
        title="Reset Outlook client state",
        keywords=["outlook", "mail", "email", "calendar", "ost", "pst", "sync", "profile", "reset"],
        diagnostic_tools=["Get-OutlookStatus", "Check-DNSResolution", "Test-Internet"],
        verification_tools=["Get-OutlookStatus"],
        action_tool="execute_remediation",
        action_name="Reset-OutlookClientState",
        description="Reset Outlook navigation pane and clear Outlook RoamCache.",
    ),
    EndpointCapability(
        intent="office.clear_document_cache",
        title="Clear Office document cache",
        keywords=["office", "word", "excel", "powerpoint", "onenote", "document", "addin", "add-in", "cache"],
        diagnostic_tools=["Get-OfficeAppStatus", "Get-IdentityTicketStatus", "Test-Internet"],
        verification_tools=["Get-OfficeAppStatus"],
        action_tool="execute_remediation",
        action_name="Clear-OfficeDocumentCache",
        description="Close Office apps and clear the Microsoft Office document cache.",
    ),
    EndpointCapability(
        intent="adobe.clear_cache",
        title="Clear Adobe Reader or Acrobat cache",
        keywords=["adobe", "acrobat", "reader", "pdf", "preview", "cache", "clear"],
        diagnostic_tools=["Get-AdobeReaderStatus", "Get-RecentInstallEvents"],
        verification_tools=["Get-AdobeReaderStatus"],
        action_tool="execute_remediation",
        action_name="Clear-AdobeReaderCache",
        description="Close Adobe Reader/Acrobat and clear common cache folders.",
    ),
    EndpointCapability(
        intent="collaboration.clear_cache",
        title="Clear collaboration app caches",
        keywords=["zoom", "webex", "slack", "collaboration", "meeting", "conference", "screen", "share", "cache"],
        diagnostic_tools=["Get-CollaborationAppStatus", "Test-Internet", "Get-AudioDeviceStatus"],
        verification_tools=["Get-CollaborationAppStatus"],
        action_tool="execute_remediation",
        action_name="Clear-CollaborationAppCaches",
        description="Close Zoom, Webex, and Slack and clear common cache folders.",
    ),
    EndpointCapability(
        intent="audio.restart_services",
        title="Restart audio services",
        keywords=["audio", "sound", "speaker", "microphone", "mic", "headset", "volume", "mute", "restart"],
        diagnostic_tools=["Get-AudioDeviceStatus", "Get-SystemInfo"],
        verification_tools=["Get-AudioDeviceStatus"],
        action_tool="execute_remediation",
        action_name="Restart-AudioServices",
        description="Restart Windows audio services for speaker, microphone, or headset issues.",
    ),
    EndpointCapability(
        intent="camera.restart_service",
        title="Restart camera service",
        keywords=["camera", "webcam", "video", "frame", "black", "blank", "restart"],
        diagnostic_tools=["Get-CameraDeviceStatus", "Get-SystemInfo"],
        verification_tools=["Get-CameraDeviceStatus"],
        action_tool="execute_remediation",
        action_name="Restart-CameraFrameServer",
        description="Restart the Windows Camera Frame Server service when present.",
    ),
    EndpointCapability(
        intent="bluetooth.restart_service",
        title="Restart Bluetooth service",
        keywords=["bluetooth", "pair", "pairing", "wireless", "keyboard", "mouse", "headphones", "restart"],
        diagnostic_tools=["Get-BluetoothStatus", "Get-SystemInfo"],
        verification_tools=["Get-BluetoothStatus"],
        action_tool="execute_remediation",
        action_name="Restart-BluetoothService",
        description="Restart the Bluetooth Support Service.",
    ),
    EndpointCapability(
        intent="printer.restart_spooler",
        title="Restart print spooler",
        keywords=["printer", "print", "printing", "queue", "spooler", "offline", "restart"],
        diagnostic_tools=["Get-PrinterStatus", "Get-PrintQueue"],
        verification_tools=["Get-PrinterStatus", "Get-PrintQueue"],
        action_tool="execute_remediation",
        action_name="Restart-PrintSpooler",
        description="Restart the Windows Print Spooler service.",
    ),
    EndpointCapability(
        intent="network.flush_dns",
        title="Flush DNS cache",
        keywords=["dns", "network", "internet", "website", "resolve", "resolution", "flush"],
        diagnostic_tools=["Get-NetworkConfig", "Check-DNSResolution", "Test-Internet"],
        verification_tools=["Check-DNSResolution", "Test-Internet"],
        action_tool="execute_remediation",
        action_name="Flush-DNS",
        description="Clear the local DNS resolver cache.",
    ),
    EndpointCapability(
        intent="network.restart_adapter",
        title="Restart network adapters",
        keywords=["network", "adapter", "wifi", "wi-fi", "ethernet", "restart", "disconnect"],
        diagnostic_tools=["Get-NetworkAdapterStatus", "Get-NetworkConfig"],
        verification_tools=["Get-NetworkAdapterStatus", "Test-Internet"],
        action_tool="execute_remediation",
        action_name="Restart-NetAdapter",
        description="Disable and re-enable active network adapters.",
    ),
    EndpointCapability(
        intent="network.renew_dhcp",
        title="Renew DHCP lease",
        keywords=["dhcp", "ip", "address", "lease", "renew", "release"],
        diagnostic_tools=["Get-NetworkConfig", "Test-Internet"],
        verification_tools=["Get-NetworkConfig", "Test-Internet"],
        action_tool="execute_remediation",
        action_name="Renew-DHCPLease",
        description="Release and request a new IPv4 address from DHCP.",
    ),
    EndpointCapability(
        intent="performance.cleanup",
        title="Run performance cleanup",
        keywords=["slow", "performance", "cleanup", "temp", "temporary", "hang", "freeze", "lag"],
        diagnostic_tools=["Get-HealthReport", "Get-MemoryUsage", "Get-StartupPrograms"],
        verification_tools=["Get-HealthReport", "Get-TempFolderSize"],
        action_tool="execute_remediation",
        action_name="Run-PerformanceCleanup",
        description="Clear temporary files to reduce common endpoint performance drag.",
    ),
    EndpointCapability(
        intent="storage.clear_temp",
        title="Clear temporary files",
        keywords=["disk", "storage", "space", "temp", "temporary", "clear", "full"],
        diagnostic_tools=["Get-DiskUsage", "Get-TempFolderSize"],
        verification_tools=["Get-DiskUsage", "Get-TempFolderSize"],
        action_tool="execute_remediation",
        action_name="Clear-TempFiles",
        description="Remove user temporary files.",
    ),
    EndpointCapability(
        intent="windows_update.restart_services",
        title="Restart Windows Update services",
        keywords=["windows", "update", "patch", "kb", "wuauserv", "bits", "restart"],
        diagnostic_tools=["Get-WindowsUpdateStatus", "Get-PendingRebootStatus", "Get-RecentUpdateEvents"],
        verification_tools=["Get-WindowsUpdateStatus"],
        action_tool="execute_remediation",
        action_name="Restart-WindowsUpdateServices",
        description="Restart Windows Update related services.",
    ),
    EndpointCapability(
        intent="windows_update.reset_cache",
        title="Reset Windows Update cache",
        keywords=["windows", "update", "patch", "softwaredistribution", "catroot2", "cache", "reset"],
        diagnostic_tools=["Get-WindowsUpdateStatus", "Get-PendingRebootStatus", "Get-RecentUpdateEvents"],
        verification_tools=["Get-WindowsUpdateStatus"],
        action_tool="execute_remediation",
        action_name="Reset-WindowsUpdateCache",
        tier=3,
        description="Reset Windows Update cache folders and restart update services.",
    ),
    EndpointCapability(
        intent="defender.update_signatures",
        title="Update Defender signatures",
        keywords=["defender", "antivirus", "signature", "signatures", "malware", "virus", "protection", "update"],
        diagnostic_tools=["Get-DefenderStatus", "Test-Internet"],
        verification_tools=["Get-DefenderStatus"],
        action_tool="execute_remediation",
        action_name="Update-DefenderSignatures",
        description="Update Microsoft Defender antivirus signatures.",
    ),
    EndpointCapability(
        intent="sccm.restart_client",
        title="Restart SCCM client",
        keywords=["sccm", "software", "center", "configuration", "manager", "ccmexec", "deployment", "restart"],
        diagnostic_tools=["Get-SCCMClientStatus", "Get-RecentInstallEvents", "Test-Internet"],
        verification_tools=["Get-SCCMClientStatus"],
        action_tool="execute_remediation",
        action_name="Restart-SCCMClient",
        description="Restart the Configuration Manager/SCCM client service when installed.",
    ),
    EndpointCapability(
        intent="intune.sync_device",
        title="Sync Intune device",
        keywords=["intune", "company", "portal", "enrollment", "compliance", "managed", "sync"],
        diagnostic_tools=["Get-IntuneEnrollmentStatus", "Get-CompanyPortalStatus", "Test-Internet"],
        verification_tools=["Get-IntuneEnrollmentStatus", "Get-CompanyPortalStatus"],
        action_tool="execute_remediation",
        action_name="Sync-IntuneDevice",
        description="Trigger Intune device management sync from local scheduled tasks.",
    ),
    EndpointCapability(
        intent="group_policy.refresh",
        title="Refresh Group Policy",
        keywords=["gpo", "gpupdate", "group", "policy", "mapped", "drive", "settings", "refresh"],
        diagnostic_tools=["Get-GroupPolicyStatus", "Get-NetworkConfig", "Get-IdentityTicketStatus"],
        verification_tools=["Get-GroupPolicyStatus"],
        action_tool="execute_remediation",
        action_name="Refresh-GroupPolicy",
        description="Force a user and computer Group Policy refresh.",
    ),
    EndpointCapability(
        intent="shell.restart_explorer",
        title="Restart Explorer shell",
        keywords=["explorer", "taskbar", "start", "menu", "desktop", "icons", "right-click", "frozen", "restart"],
        diagnostic_tools=["Get-ExplorerShellStatus", "Get-HealthReport"],
        verification_tools=["Get-ExplorerShellStatus"],
        action_tool="execute_remediation",
        action_name="Restart-ExplorerShell",
        description="Restart Windows Explorer shell.",
    ),
    EndpointCapability(
        intent="search.restart_service",
        title="Restart Windows Search",
        keywords=["windows search", "search", "index", "indexing", "indexer", "wsearch", "service", "restart"],
        diagnostic_tools=["Get-WindowsSearchStatus", "Get-ExplorerShellStatus"],
        verification_tools=["Get-WindowsSearchStatus"],
        action_tool="execute_remediation",
        action_name="Restart-WindowsSearchService",
        description="Restart Windows Search indexing services.",
    ),
    EndpointCapability(
        intent="store.reset_cache",
        title="Reset Microsoft Store cache",
        keywords=["store", "microsoft", "appx", "msix", "uwp", "winget", "cache", "reset"],
        diagnostic_tools=["Get-WindowsStoreStatus", "Test-Internet"],
        verification_tools=["Get-WindowsStoreStatus"],
        action_tool="execute_remediation",
        action_name="Reset-WindowsStoreCache",
        description="Reset Microsoft Store cache with wsreset.",
    ),
    EndpointCapability(
        intent="time.resync",
        title="Resync system time",
        keywords=["time", "clock", "date", "timezone", "w32time", "certificate", "ssl", "tls", "trust", "resync"],
        diagnostic_tools=["Get-TimeSyncStatus", "Get-CertificateStoreHealth", "Test-Internet"],
        verification_tools=["Get-TimeSyncStatus"],
        action_tool="execute_remediation",
        action_name="Resync-SystemTime",
        description="Start Windows Time if needed and request time resynchronization.",
    ),
    EndpointCapability(
        intent="identity.purge_kerberos",
        title="Purge Kerberos tickets",
        keywords=["kerberos", "klist", "ticket", "tickets", "credential", "login", "signin", "authentication", "purge"],
        diagnostic_tools=["Get-IdentityTicketStatus", "Test-Internet"],
        verification_tools=["Get-IdentityTicketStatus"],
        action_tool="execute_remediation",
        action_name="Purge-KerberosTickets",
        description="Purge cached Kerberos tickets so the user can reauthenticate.",
    ),
    EndpointCapability(
        intent="power.set_balanced",
        title="Set Balanced power plan",
        keywords=["battery", "charging", "power", "sleep", "hibernate", "lid", "drain", "powerplan", "balanced"],
        diagnostic_tools=["Get-PowerBatteryStatus", "Get-SystemInfo"],
        verification_tools=["Get-PowerBatteryStatus"],
        action_tool="execute_remediation",
        action_name="Set-BalancedPowerPlan",
        description="Switch Windows to the Balanced power plan.",
    ),
    EndpointCapability(
        intent="devices.rescan_pnp",
        title="Rescan Plug and Play devices",
        keywords=[
            "usb",
            "peripheral",
            "device",
            "driver",
            "dock",
            "docking",
            "display",
            "monitor",
            "camera",
            "keyboard",
            "mouse",
            "scanner",
            "not detected",
            "not recognized",
            "rescan",
        ],
        diagnostic_tools=["Get-USBDeviceStatus", "Get-DisplayDockStatus", "Get-DriverProblemDevices", "Get-OEMDeviceProfile"],
        verification_tools=["Get-USBDeviceStatus", "Get-DriverProblemDevices"],
        action_tool="execute_remediation",
        action_name="Rescan-PnPDevices",
        description="Rescan Plug and Play devices to redetect hardware.",
    ),
    EndpointCapability(
        intent="profile.clear_shell_cache",
        title="Clear user shell cache",
        keywords=["user profile", "icon cache", "shell cache", "profile", "desktop", "appdata", "icon", "icons", "thumbnail", "thumbnails", "shell", "cache", "clear", "temporary profile"],
        diagnostic_tools=["Get-UserProfileStatus", "Get-ExplorerShellStatus"],
        verification_tools=["Get-UserProfileStatus", "Get-ExplorerShellStatus"],
        action_tool="execute_remediation",
        action_name="Clear-UserShellCache",
        description="Restart Explorer and clear current-user icon and thumbnail cache files.",
    ),
    EndpointCapability(
        intent="file_access.restart_workstation",
        title="Restart Workstation service",
        keywords=["mapped", "drive", "network drive", "share", "smb", "file access", "permission", "unc", "workstation", "lanmanworkstation"],
        diagnostic_tools=["Get-NetworkDriveStatus", "Get-IdentityTicketStatus", "Get-NetworkConfig"],
        verification_tools=["Get-NetworkDriveStatus"],
        action_tool="execute_remediation",
        action_name="Restart-WorkstationService",
        tier=3,
        description="Restart the Workstation service for mapped drive or SMB client issues.",
    ),
    EndpointCapability(
        intent="offline_files.restart_service",
        title="Restart Offline Files service",
        keywords=["offline files", "offline files service", "sync center", "sync-center", "csc", "cached files", "offline", "files", "service", "restart", "conflict"],
        diagnostic_tools=["Get-OfflineFilesStatus", "Get-NetworkDriveStatus"],
        verification_tools=["Get-OfflineFilesStatus"],
        action_tool="execute_remediation",
        action_name="Restart-OfflineFilesService",
        tier=3,
        description="Restart the Offline Files service for sync/cache issues.",
    ),
    EndpointCapability(
        intent="remote_support.restart_tools",
        title="Restart remote support tools",
        keywords=["anydesk", "teamviewer", "quick assist", "quickassist", "remote help", "remote support", "tailscale", "support tool"],
        diagnostic_tools=["Get-RemoteSupportToolStatus", "Get-NetworkConfig"],
        verification_tools=["Get-RemoteSupportToolStatus"],
        action_tool="execute_remediation",
        action_name="Restart-RemoteSupportTools",
        description="Restart common remote support services when installed.",
    ),
    EndpointCapability(
        intent="citrix.restart_workspace",
        title="Restart Citrix Workspace client",
        keywords=["citrix", "workspace", "receiver", "vdi", "virtual desktop", "ica", "wfica", "published app", "remote app"],
        diagnostic_tools=["Get-CitrixVDIStatus", "Test-Internet"],
        verification_tools=["Get-CitrixVDIStatus"],
        action_tool="execute_remediation",
        action_name="Restart-CitrixWorkspace",
        description="Close common Citrix Workspace processes for a clean relaunch.",
    ),
    EndpointCapability(
        intent="asset.sync_compliance",
        title="Sync endpoint compliance and inventory",
        keywords=["asset", "inventory", "serial", "hostname", "compliance", "non-compliant", "noncompliant", "check-in", "checkin", "managed device"],
        diagnostic_tools=["Get-AssetComplianceStatus", "Get-IntuneEnrollmentStatus", "Get-CompanyPortalStatus"],
        verification_tools=["Get-AssetComplianceStatus", "Get-IntuneEnrollmentStatus"],
        action_tool="execute_remediation",
        action_name="Sync-IntuneDevice",
        description="Trigger device management sync to refresh compliance and inventory status.",
    ),
    EndpointCapability(
        intent="system.repair_files",
        title="Repair Windows system files",
        keywords=["sfc", "system", "file", "files", "corrupt", "corruption", "dll", "repair"],
        diagnostic_tools=["Get-RecentSystemErrors", "Get-SystemInfo", "Get-DiskUsage"],
        verification_tools=["Get-RecentSystemErrors"],
        action_tool="execute_remediation",
        action_name="Repair-SystemFiles",
        tier=3,
        description="Run System File Checker to repair protected Windows system files.",
    ),
    EndpointCapability(
        intent="driver.oem_update",
        title="Install OEM driver updates",
        keywords=[
            "oem",
            "vendor",
            "manufacturer",
            "driver",
            "drivers",
            "install",
            "update",
            "reinstall",
            "camera",
            "webcam",
            "dock",
            "docking",
            "display",
            "usb",
            "peripheral",
        ],
        diagnostic_tools=["Get-OEMDeviceProfile", "Get-DriverProblemDevices"],
        verification_tools=["Get-OEMDeviceProfile", "Get-DriverProblemDevices"],
        action_tool="install_oem_driver_updates",
        action_name="Install-OEMDriverUpdates",
        tier=3,
        description="Install available driver updates only through a detected trusted OEM update utility.",
    ),
    EndpointCapability(
        intent="driver.oem_bootstrap_update",
        title="Install OEM driver utility and driver updates",
        keywords=[
            "oem",
            "vendor",
            "manufacturer",
            "utility",
            "tool",
            "missing",
            "winget",
            "driver",
            "drivers",
            "install",
            "update",
            "reinstall",
            "camera",
            "webcam",
            "dock",
            "docking",
            "display",
            "usb",
            "peripheral",
        ],
        diagnostic_tools=["Get-OEMDeviceProfile", "Get-DriverProblemDevices"],
        verification_tools=["Get-OEMDeviceProfile", "Get-DriverProblemDevices"],
        action_tool="install_oem_driver_utility_and_updates",
        action_name="Install-OEMDriverUtilityAndUpdates",
        tier=3,
        description="Install the approved OEM update utility when missing, then install available driver updates through that utility.",
    ),
    EndpointCapability(
        intent="driver.camera_reinstall",
        title="Camera driver reinstall or update",
        keywords=["camera", "webcam", "driver", "drivers", "update", "reinstall", "rollback"],
        diagnostic_tools=["Get-CameraDeviceStatus", "Get-DriverProblemDevices", "Get-OEMDeviceProfile", "Get-RecentSystemErrors"],
        verification_tools=["Get-CameraDeviceStatus"],
        supported=False,
        tier=3,
        description="Camera driver repair requires a vendor-approved driver source or device-management workflow.",
        unsupported_reason="Driver reinstall/update is not enabled as a generic remediation because it can break hardware or install the wrong vendor driver.",
    ),
]


def search_endpoint_capabilities(query: str, limit: int = 8) -> Dict:
    matches = _rank_capabilities(query)
    limited = matches[: max(1, int(limit or 8))]
    return {
        "tool": "search_endpoint_capabilities",
        "query": query,
        "capabilities": [
            {
                **capability.to_dict(),
                "score": score,
                "skills": [skill.to_dict(score=skill_score) for skill, skill_score in rank_endpoint_skills(
                    query,
                    intents=[capability.intent],
                    limit=2,
                )],
            }
            for capability, score in limited
        ],
    }


def plan_endpoint_action(request: str, context: Optional[Dict] = None) -> Dict:
    ranked = _rank_capabilities(request)
    if not ranked:
        return _unknown_plan(request)

    capability, score = ranked[0]
    confidence = min(0.95, max(0.35, score / 8.0))
    target = _extract_target(request, capability)
    skill_matches = rank_endpoint_skills(request, intents=[capability.intent], limit=2)

    plan = {
        "tool": "plan_endpoint_action",
        "request": request,
        "intent": capability.intent,
        "title": capability.title,
        "description": capability.description,
        "confidence": round(confidence, 2),
        "supported": capability.supported,
        "status": "ready",
        "target": target,
        "target_kind": capability.target_kind,
        "diagnostic_tools": capability.diagnostic_tools,
        "verification_tools": capability.verification_tools,
        "requires_approval": bool(capability.action_tool),
        "tier": capability.tier,
        "remediation": None,
        "skills": [skill.to_dict(score=skill_score) for skill, skill_score in skill_matches],
        "oem_guidance": oem_guidance_for_request(request, limit=2),
        "message": "",
    }

    if not capability.supported:
        plan["status"] = "unsupported"
        plan["message"] = capability.unsupported_reason
        return plan

    if capability.target_kind and not target:
        plan["status"] = "needs_target"
        plan["message"] = f"Please specify the {capability.target_kind} to use for this action."
        return plan

    action = _action_metadata(capability, target)
    if not action:
        plan["status"] = "unsupported"
        plan["message"] = "This capability does not have an executable remediation action yet."
        return plan

    plan["remediation"] = action
    plan["message"] = "I found a supported endpoint action. Approval is required before making changes."
    return plan


def execute_parameterized_remediation(
    intent: str,
    target: Optional[str],
    approved: bool,
    parameters: Optional[Dict] = None,
    executor=None,
) -> Dict:
    capability = _capability_by_intent(intent)
    if not capability:
        raise ValueError(f"Unknown endpoint action intent: {intent}")
    if not capability.supported or not capability.action_tool:
        raise ValueError(f"{intent} is not an executable endpoint remediation")
    if not approved:
        raise ValueError(f"{intent} requires explicit user approval")

    parameters = parameters or {}
    target = _clean_target(target or parameters.get("target") or parameters.get("app") or "")
    if capability.target_kind and not target:
        raise ValueError(f"{intent} requires a {capability.target_kind} target")

    if capability.action_tool == "disable_startup_app":
        remediation = disable_startup_app(target, approved=True, executor=executor)
    elif capability.action_tool == "execute_remediation" and capability.action_name:
        remediation = execute_tool(capability.action_name, approved=True, executor=executor)
    elif capability.action_tool == "install_oem_driver_updates":
        remediation = install_oem_driver_updates(approved=True, executor=executor)
    elif capability.action_tool == "install_oem_driver_utility_and_updates":
        remediation = install_oem_driver_utility_and_updates(approved=True, executor=executor)
    else:
        raise ValueError(f"{intent} does not have a supported execution route")

    response = {
        "tool": "execute_parameterized_remediation",
        "intent": capability.intent,
        "target": target,
        "action": remediation["action"],
        "result": remediation["result"],
    }
    for key in ("profile", "installer", "utility_was_installed"):
        if key in remediation:
            response[key] = remediation[key]
    return response


def verify_endpoint_action(intent: str, target: Optional[str] = None, executor=None) -> Dict:
    capability = _capability_by_intent(intent)
    if not capability:
        raise ValueError(f"Unknown endpoint action intent: {intent}")

    diagnostics = []
    for tool_name in capability.verification_tools:
        diagnostics.append(execute_diagnostic_tool(tool_name, executor=executor))

    return {
        "tool": "verify_endpoint_action",
        "intent": capability.intent,
        "target": _clean_target(target or ""),
        "diagnostics": diagnostics,
    }


def _rank_capabilities(query: str) -> List:
    query_tokens = _tokens(query)
    if not query_tokens:
        return []

    ranked = []
    query_lower = query.lower()
    for capability in CAPABILITIES:
        keyword_tokens = {token for keyword in capability.keywords for token in _tokens(keyword)}
        matched = query_tokens.intersection(keyword_tokens)
        phrase_bonus = sum(2 for keyword in capability.keywords if keyword.lower() in query_lower)
        score = len(matched) + phrase_bonus
        if capability.intent.startswith("driver.") and "driver" in query_tokens:
            score += 3
        if capability.intent == "driver.oem_update" and "driver" in query_tokens:
            if {"install", "update", "reinstall", "oem", "vendor", "manufacturer"}.intersection(query_tokens):
                score += 4
        if capability.intent == "driver.oem_bootstrap_update" and "driver" in query_tokens:
            if {"utility", "tool", "missing", "winget"}.intersection(query_tokens):
                score += 6
        if capability.target_kind == "app" and {"startup", "start-up", "autostart"}.intersection(query_tokens):
            score += 2
        if score > 0:
            ranked.append((capability, float(score)))

    ranked.sort(key=lambda item: (item[1], item[0].supported, -item[0].tier), reverse=True)
    return ranked


def _capability_by_intent(intent: str) -> Optional[EndpointCapability]:
    for capability in CAPABILITIES:
        if capability.intent == intent:
            return capability
    return None


def _action_metadata(capability: EndpointCapability, target: str) -> Optional[Dict]:
    if capability.action_tool == "disable_startup_app":
        return {
            "name": "Disable-StartupApp",
            "intent": capability.intent,
            "target": target,
            "tier": capability.tier,
            "type": "action",
            "description": f"Disable '{target}' from Windows startup without removing its Startup Apps entry where supported.",
            "requires_approval": True,
        }
    if capability.action_tool == "execute_remediation" and capability.action_name:
        action = get_tool(capability.action_name)
        if action:
            action = dict(action)
            action["intent"] = capability.intent
            action["target"] = target
            return action
    if capability.action_tool == "install_oem_driver_updates":
        return {
            "name": "Install-OEMDriverUpdates",
            "intent": capability.intent,
            "target": target,
            "tier": capability.tier,
            "type": "action",
            "description": "Install available driver updates only through a detected trusted OEM update utility.",
            "requires_approval": True,
        }
    if capability.action_tool == "install_oem_driver_utility_and_updates":
        return {
            "name": "Install-OEMDriverUtilityAndUpdates",
            "intent": capability.intent,
            "target": target,
            "tier": capability.tier,
            "type": "action",
            "description": "Install the approved OEM update utility when missing, then install available driver updates through that utility.",
            "requires_approval": True,
        }
    return None


def _extract_target(request: str, capability: EndpointCapability) -> str:
    if capability.target_kind != "app":
        return ""

    patterns = [
        r"\b(?:disable|remove|turn\s+off|stop|prevent)\s+(.+?)\s+(?:from|at|during|on)\s+(?:startup|start-up|boot|login|logon|launch)\b",
        r"\b(?:disable|remove|turn\s+off|stop|prevent)\s+(.+?)\s*$",
    ]
    for pattern in patterns:
        match = re.search(pattern, request, flags=re.IGNORECASE)
        if match:
            return _clean_target(match.group(1))
    return ""


def _clean_target(value: str) -> str:
    cleaned = re.sub(r"\s+", " ", str(value or "")).strip(" .\"'")
    cleaned = re.sub(
        r"\b(app|application|program|process|startup|start-up|entry|entries|item|items)\b",
        " ",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .\"'")
    if len(cleaned) > 80:
        cleaned = cleaned[:80].strip()
    if re.search(r"[\r\n;&|`$<>]", cleaned):
        return ""
    if cleaned.lower() in {"my", "mine", "all", "everything", "these", "those"}:
        return ""
    return cleaned


def _unknown_plan(request: str) -> Dict:
    skill_matches = rank_endpoint_skills(request, limit=2)
    return {
        "tool": "plan_endpoint_action",
        "request": request,
        "intent": "",
        "title": "Unknown endpoint action",
        "description": "",
        "confidence": 0.0,
        "supported": False,
        "status": "unknown",
        "target": "",
        "target_kind": "",
        "diagnostic_tools": [],
        "verification_tools": [],
        "requires_approval": False,
        "tier": None,
        "remediation": None,
        "skills": [skill.to_dict(score=score) for skill, score in skill_matches],
        "oem_guidance": oem_guidance_for_request(request, limit=2),
        "message": "I could not map that request to a safe endpoint action yet.",
    }


def _tokens(text: str) -> set:
    return set(re.findall(r"[a-z0-9-]+", text.lower()))
