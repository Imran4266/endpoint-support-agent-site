$ErrorActionPreference = "Stop"

# Self-elevate to Administrator if not already running elevated
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Requesting Administrator privileges..." -ForegroundColor Yellow
    $scriptPath = $MyInvocation.MyCommand.Path
    Start-Process -FilePath "powershell.exe" `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`"" `
        -Verb RunAs -Wait
    exit $LASTEXITCODE
}

$InstallPath = "$env:ProgramFiles\EndpointSupportAgent"

Write-Host ""
Write-Host "  Endpoint Support Agent - Uninstaller" -ForegroundColor Cyan
Write-Host ""

# Remove Desktop shortcut
$desktop = [Environment]::GetFolderPath("Desktop")
$desktopShortcut = Join-Path $desktop "Endpoint Support Agent.lnk"
if (Test-Path -LiteralPath $desktopShortcut) {
    Remove-Item -LiteralPath $desktopShortcut -Force
    Write-Host "  [OK] Desktop shortcut removed." -ForegroundColor Green
}

# Remove Start Menu shortcut
$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$startMenuShortcut = Join-Path $startMenu "Endpoint Support Agent.lnk"
if (Test-Path -LiteralPath $startMenuShortcut) {
    Remove-Item -LiteralPath $startMenuShortcut -Force
    Write-Host "  [OK] Start Menu shortcut removed." -ForegroundColor Green
}

# Remove registry entry (Programs and Features)
$uninstallRegKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EndpointSupportAgent"
if (Test-Path -LiteralPath $uninstallRegKey) {
    Remove-Item -LiteralPath $uninstallRegKey -Recurse -Force
    Write-Host "  [OK] Registry entry removed." -ForegroundColor Green
}

# Remove install directory
if (Test-Path -LiteralPath $InstallPath) {
    Remove-Item -LiteralPath $InstallPath -Recurse -Force
    Write-Host "  [OK] Application files removed from $InstallPath" -ForegroundColor Green
}

Write-Host ""
Write-Host "  Endpoint Support Agent has been uninstalled successfully." -ForegroundColor Green
Write-Host ""

if ($Host.Name -eq "ConsoleHost") {
    Read-Host "  Press Enter to close"
}
