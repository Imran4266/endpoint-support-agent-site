param(
    [string]$InstallPath = "$env:LOCALAPPDATA\EndpointSupportAgent",
    [switch]$SkipPythonDependencies,
    [switch]$SkipNodeBuild
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "[Endpoint Support Agent] $Message" -ForegroundColor Cyan
}

function Refresh-PathEnv {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Install-PythonIfMissing {
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    if ($pythonCmd) {
        Write-Step "Python found: $($pythonCmd.Source)"
        return
    }

    Write-Step "Python not found. Installing Python automatically..."

    # Try winget first
    $wingetCmd = Get-Command winget -ErrorAction SilentlyContinue
    if ($wingetCmd) {
        Write-Step "Installing Python via winget..."
        & winget install -e --id Python.Python.3.13 --accept-source-agreements --accept-package-agreements --silent
        Refresh-PathEnv
        $pythonCheck = Get-Command python -ErrorAction SilentlyContinue
        if ($pythonCheck) {
            Write-Step "Python installed successfully via winget."
            return
        }
    }

    # Fallback: download from python.org
    Write-Step "Downloading Python installer from python.org..."
    $pythonInstallerUrl = "https://www.python.org/ftp/python/3.13.5/python-3.13.5-amd64.exe"
    $pythonInstaller = Join-Path $env:TEMP "python-installer.exe"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $pythonInstallerUrl -OutFile $pythonInstaller -UseBasicParsing

    Write-Step "Running Python installer silently..."
    Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1" -Wait -NoNewWindow
    Remove-Item -LiteralPath $pythonInstaller -Force -ErrorAction SilentlyContinue

    Refresh-PathEnv
    $pythonCheck = Get-Command python -ErrorAction SilentlyContinue
    if (-not $pythonCheck) {
        throw "Python installation failed. Please install Python 3.10+ manually from https://python.org and re-run setup."
    }
    Write-Step "Python installed successfully."
}

function Install-NodeIfMissing {
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if ($nodeCmd) {
        Write-Step "Node.js found: $($nodeCmd.Source)"
        return
    }

    Write-Step "Node.js not found. Installing Node.js automatically..."

    # Try winget first
    $wingetCmd = Get-Command winget -ErrorAction SilentlyContinue
    if ($wingetCmd) {
        Write-Step "Installing Node.js via winget..."
        & winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements --silent
        Refresh-PathEnv
        $nodeCheck = Get-Command node -ErrorAction SilentlyContinue
        if ($nodeCheck) {
            Write-Step "Node.js installed successfully via winget."
            return
        }
    }

    # Fallback: download from nodejs.org
    Write-Step "Downloading Node.js installer from nodejs.org..."
    $nodeInstallerUrl = "https://nodejs.org/dist/v22.16.0/node-v22.16.0-x64.msi"
    $nodeInstaller = Join-Path $env:TEMP "node-installer.msi"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $nodeInstallerUrl -OutFile $nodeInstaller -UseBasicParsing

    Write-Step "Running Node.js installer silently..."
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$nodeInstaller`" /quiet /norestart" -Wait -NoNewWindow
    Remove-Item -LiteralPath $nodeInstaller -Force -ErrorAction SilentlyContinue

    Refresh-PathEnv
    $nodeCheck = Get-Command node -ErrorAction SilentlyContinue
    if (-not $nodeCheck) {
        Write-Host "[Endpoint Support Agent] Node.js installation failed. The agent will still work, but advanced MCP companion tools will be unavailable." -ForegroundColor Yellow
        return
    }
    Write-Step "Node.js installed successfully."
}

# ─── Install prerequisites ───
Install-PythonIfMissing
Install-NodeIfMissing

# ─── Main installation ───
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSource = Join-Path $packageRoot "app"

if (-not (Test-Path -LiteralPath $appSource)) {
    throw "The setup package is missing the 'app' folder. Extract the full ZIP package and run this script again."
}

Write-Step "Installing to $InstallPath"
New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
Copy-Item -Path (Join-Path $appSource "*") -Destination $InstallPath -Recurse -Force

Push-Location $InstallPath
try {
    if (-not (Test-Path -LiteralPath ".env") -and (Test-Path -LiteralPath ".env.example")) {
        Copy-Item -LiteralPath ".env.example" -Destination ".env"
        Write-Step "Created .env from .env.example."
    }

    if (-not $SkipPythonDependencies) {
        Write-Step "Creating Python virtual environment"
        & python -m venv ".venv"
        $venvPython = Join-Path $InstallPath ".venv\Scripts\python.exe"
        Write-Step "Installing Python dependencies"
        & $venvPython -m pip install --upgrade pip
        & $venvPython -m pip install -r "requirements.txt"
    }

    if (-not $SkipNodeBuild -and (Test-Path -LiteralPath "servers\package.json")) {
        $npmCommand = Get-Command npm -ErrorAction SilentlyContinue
        if ($npmCommand) {
            Write-Step "Installing and building MCP companion servers"
            Push-Location "servers"
            try {
                & npm install
                & npm run build
            }
            finally {
                Pop-Location
            }
        }
        else {
            Write-Host "[Endpoint Support Agent] npm was not found. MCP companion servers were not built." -ForegroundColor Yellow
        }
    }

    $launcherPath = Join-Path $InstallPath "Start-EndpointSupportAgent.ps1"
    $launcherContent = @"
`$ErrorActionPreference = "Stop"
Set-Location "$InstallPath"
`$python = Join-Path "$InstallPath" ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath `$python)) {
    `$python = "python"
}
& `$python "agent.py"
"@
    Set-Content -LiteralPath $launcherPath -Value $launcherContent -Encoding UTF8

    $shell = New-Object -ComObject WScript.Shell
    $iconPath = Join-Path $InstallPath "app.ico"

    # Create Start Menu shortcut (Run as Administrator)
    $startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    if (Test-Path -LiteralPath $startMenu) {
        $shortcutPath = Join-Path $startMenu "Endpoint Support Agent.lnk"
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = "powershell.exe"
        $shortcut.Arguments = "-ExecutionPolicy Bypass -NoExit -File `"$launcherPath`""
        $shortcut.WorkingDirectory = $InstallPath
        if (Test-Path -LiteralPath $iconPath) {
            $shortcut.IconLocation = $iconPath
        }
        $shortcut.Save()

        # Set "Run as Administrator" flag in the shortcut binary
        $bytes = [System.IO.File]::ReadAllBytes($shortcutPath)
        $bytes[0x15] = $bytes[0x15] -bor 0x20
        [System.IO.File]::WriteAllBytes($shortcutPath, $bytes)

        Write-Step "Created Start Menu shortcut (Run as Administrator)"
    }

    # Create Desktop shortcut (Run as Administrator)
    $desktop = [Environment]::GetFolderPath("Desktop")
    if (Test-Path -LiteralPath $desktop) {
        $desktopShortcutPath = Join-Path $desktop "Endpoint Support Agent.lnk"
        $desktopShortcut = $shell.CreateShortcut($desktopShortcutPath)
        $desktopShortcut.TargetPath = "powershell.exe"
        $desktopShortcut.Arguments = "-ExecutionPolicy Bypass -NoExit -File `"$launcherPath`""
        $desktopShortcut.WorkingDirectory = $InstallPath
        if (Test-Path -LiteralPath $iconPath) {
            $desktopShortcut.IconLocation = $iconPath
        }
        $desktopShortcut.Save()

        # Set "Run as Administrator" flag in the shortcut binary
        $bytes = [System.IO.File]::ReadAllBytes($desktopShortcutPath)
        $bytes[0x15] = $bytes[0x15] -bor 0x20
        [System.IO.File]::WriteAllBytes($desktopShortcutPath, $bytes)

        Write-Step "Created Desktop shortcut (Run as Administrator)"
    }

    Write-Step "Setup complete"
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Green
    Write-Host "1. Launch Endpoint Support Agent from your Desktop or Start Menu."
    Write-Host "2. Paste your API key when prompted on first launch."
    Write-Host "3. The agent will request Administrator privileges automatically."
}
finally {
    Pop-Location
}
