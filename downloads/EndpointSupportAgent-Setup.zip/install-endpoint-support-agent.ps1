param(
    [string]$InstallPath = "$env:ProgramFiles\EndpointSupportAgent",
    [switch]$SkipPythonDependencies,
    [switch]$SkipNodeBuild
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "Continue"
$AppVersion = "1.0.0"
$AppPublisher = "Imran Shaikh"

# ─── Helper Functions ───

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "  [Endpoint Support Agent] $Message" -ForegroundColor Cyan
}

function Write-SubStep {
    param([string]$Message)
    Write-Host "    > $Message" -ForegroundColor Gray
}

function Write-Success {
    param([string]$Message)
    Write-Host "    [OK] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "    [!] $Message" -ForegroundColor Yellow
}

function Refresh-PathEnv {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Find-Python {
    # Check PATH first
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    # Check common install locations
    $commonPaths = @(
        "$env:ProgramFiles\Python314\python.exe",
        "$env:ProgramFiles\Python313\python.exe",
        "$env:ProgramFiles\Python312\python.exe",
        "$env:ProgramFiles\Python311\python.exe",
        "$env:ProgramFiles\Python310\python.exe",
        "${env:ProgramFiles(x86)}\Python314\python.exe",
        "${env:ProgramFiles(x86)}\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe"
    )
    foreach ($p in $commonPaths) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Find-Node {
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $commonPaths = @(
        "$env:ProgramFiles\nodejs\node.exe",
        "${env:ProgramFiles(x86)}\nodejs\node.exe"
    )
    foreach ($p in $commonPaths) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Download-FileWithProgress {
    param(
        [string]$Url,
        [string]$Destination,
        [string]$Description
    )
    Write-SubStep "Downloading $Description..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try {
        $webClient = New-Object System.Net.WebClient
        $webClient.DownloadFile($Url, $Destination)
        $webClient.Dispose()
        if (Test-Path -LiteralPath $Destination) {
            $sizeMB = [Math]::Round((Get-Item $Destination).Length / 1MB, 1)
            Write-SubStep "Downloaded ${sizeMB} MB"
            return $true
        }
    }
    catch {
        Write-Warn "Download failed from $Url : $($_.Exception.Message)"
    }
    return $false
}

# ─── Python Installation ───

function Install-PythonIfMissing {
    Write-Step "Checking for Python..."

    $pythonPath = Find-Python
    if ($pythonPath) {
        Write-Success "Python found: $pythonPath"
        return
    }

    Write-Warn "Python not found. Installing Python automatically..."

    # Attempt 1: winget
    $installed = $false
    $wingetCmd = Get-Command winget -ErrorAction SilentlyContinue
    if ($wingetCmd) {
        Write-SubStep "Attempting install via winget..."
        try {
            $wingetOutput = & winget install -e --id Python.Python.3.13 --accept-source-agreements --accept-package-agreements --silent 2>&1
            Write-SubStep ($wingetOutput | Out-String).Trim()
            Refresh-PathEnv
            if (Find-Python) {
                Write-Success "Python installed successfully via winget."
                $installed = $true
            }
        }
        catch {
            Write-Warn "winget install attempt failed: $($_.Exception.Message)"
        }
    }

    # Attempt 2: Direct download (primary URL)
    if (-not $installed) {
        $pythonInstaller = Join-Path $env:TEMP "python-installer.exe"
        $pythonUrls = @(
            "https://www.python.org/ftp/python/3.13.4/python-3.13.4-amd64.exe",
            "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe",
            "https://www.python.org/ftp/python/3.11.12/python-3.11.12-amd64.exe"
        )

        foreach ($url in $pythonUrls) {
            Write-SubStep "Trying: $url"
            $downloaded = Download-FileWithProgress -Url $url -Destination $pythonInstaller -Description "Python installer"
            if ($downloaded) {
                Write-SubStep "Running Python installer (this may take a few minutes)..."
                try {
                    $process = Start-Process -FilePath $pythonInstaller `
                        -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1 Include_test=0" `
                        -Wait -NoNewWindow -PassThru
                    Write-SubStep "Installer exited with code: $($process.ExitCode)"
                }
                catch {
                    Write-Warn "Installer execution failed: $($_.Exception.Message)"
                }
                Remove-Item -LiteralPath $pythonInstaller -Force -ErrorAction SilentlyContinue

                Refresh-PathEnv
                if (Find-Python) {
                    Write-Success "Python installed successfully."
                    $installed = $true
                    break
                }
                else {
                    Write-Warn "Python not detected after running installer from $url. Trying next..."
                }
            }
        }
    }

    # Attempt 3: Microsoft Store Python via winget (fallback)
    if (-not $installed -and $wingetCmd) {
        Write-SubStep "Attempting Microsoft Store Python via winget..."
        try {
            & winget install -e --id "9PNRBTZXMB4Z" --accept-source-agreements --accept-package-agreements --silent 2>&1 | Out-Null
            Refresh-PathEnv
            if (Find-Python) {
                Write-Success "Python installed via Microsoft Store."
                $installed = $true
            }
        }
        catch {
            Write-Warn "Microsoft Store Python install failed."
        }
    }

    if (-not $installed) {
        Write-Host ""
        Write-Host "  ============================================================" -ForegroundColor Red
        Write-Host "  ERROR: Python could not be installed automatically." -ForegroundColor Red
        Write-Host "  Please install Python manually from https://python.org" -ForegroundColor Red
        Write-Host "  IMPORTANT: Check 'Add Python to PATH' during installation." -ForegroundColor Red
        Write-Host "  Then re-run this setup." -ForegroundColor Red
        Write-Host "  ============================================================" -ForegroundColor Red
        throw "Python installation failed after all attempts."
    }
}

# ─── Node.js Installation ───

function Install-NodeIfMissing {
    Write-Step "Checking for Node.js..."

    $nodePath = Find-Node
    if ($nodePath) {
        Write-Success "Node.js found: $nodePath"
        return
    }

    Write-Warn "Node.js not found. Installing Node.js automatically..."

    $installed = $false

    # Attempt 1: winget
    $wingetCmd = Get-Command winget -ErrorAction SilentlyContinue
    if ($wingetCmd) {
        Write-SubStep "Attempting install via winget..."
        try {
            $wingetOutput = & winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements --silent 2>&1
            Write-SubStep ($wingetOutput | Out-String).Trim()
            Refresh-PathEnv
            if (Find-Node) {
                Write-Success "Node.js installed successfully via winget."
                $installed = $true
            }
        }
        catch {
            Write-Warn "winget install attempt failed: $($_.Exception.Message)"
        }
    }

    # Attempt 2: Direct download (multiple fallback URLs)
    if (-not $installed) {
        $nodeInstaller = Join-Path $env:TEMP "node-installer.msi"
        $nodeUrls = @(
            "https://nodejs.org/dist/v22.16.0/node-v22.16.0-x64.msi",
            "https://nodejs.org/dist/v20.19.2/node-v20.19.2-x64.msi",
            "https://nodejs.org/dist/v18.20.8/node-v18.20.8-x64.msi"
        )

        foreach ($url in $nodeUrls) {
            Write-SubStep "Trying: $url"
            $downloaded = Download-FileWithProgress -Url $url -Destination $nodeInstaller -Description "Node.js installer"
            if ($downloaded) {
                Write-SubStep "Running Node.js installer (this may take a few minutes)..."
                try {
                    $process = Start-Process -FilePath "msiexec.exe" `
                        -ArgumentList "/i `"$nodeInstaller`" /quiet /norestart" `
                        -Wait -NoNewWindow -PassThru
                    Write-SubStep "Installer exited with code: $($process.ExitCode)"
                }
                catch {
                    Write-Warn "Installer execution failed: $($_.Exception.Message)"
                }
                Remove-Item -LiteralPath $nodeInstaller -Force -ErrorAction SilentlyContinue

                Refresh-PathEnv
                if (Find-Node) {
                    Write-Success "Node.js installed successfully."
                    $installed = $true
                    break
                }
                else {
                    Write-Warn "Node.js not detected after installer from $url. Trying next..."
                }
            }
        }
    }

    if (-not $installed) {
        Write-Host ""
        Write-Host "  ============================================================" -ForegroundColor Red
        Write-Host "  ERROR: Node.js could not be installed automatically." -ForegroundColor Red
        Write-Host "  Please install Node.js manually from https://nodejs.org" -ForegroundColor Red
        Write-Host "  Then re-run this setup." -ForegroundColor Red
        Write-Host "  ============================================================" -ForegroundColor Red
        throw "Node.js installation failed after all attempts."
    }
}

# ═══════════════════════════════════════════════════════════════
#  MAIN INSTALLATION
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ╔═══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║       Endpoint Support Agent - Setup Wizard          ║" -ForegroundColor Cyan
Write-Host "  ║       Version $AppVersion                                  ║" -ForegroundColor Cyan
Write-Host "  ╚═══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ─── Step 1: Prerequisites ───
Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Step 1 of 6: Checking prerequisites..." -PercentComplete 0
Install-PythonIfMissing
Install-NodeIfMissing

# ─── Step 2: Copy application files ───
Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Step 2 of 6: Copying application files..." -PercentComplete 20

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSource = Join-Path $packageRoot "app"

if (-not (Test-Path -LiteralPath $appSource)) {
    throw "The setup package is missing the 'app' folder. Extract the full ZIP package and run this script again."
}

Write-Step "Installing to $InstallPath"
New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
Copy-Item -Path (Join-Path $appSource "*") -Destination $InstallPath -Recurse -Force
Write-Success "Application files copied."

Push-Location $InstallPath
try {
    if (-not (Test-Path -LiteralPath ".env") -and (Test-Path -LiteralPath ".env.example")) {
        Copy-Item -LiteralPath ".env.example" -Destination ".env"
        Write-SubStep "Created .env configuration file."
    }

    # ─── Step 3: Python virtual environment ───
    Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Step 3 of 6: Setting up Python environment..." -PercentComplete 35

    if (-not $SkipPythonDependencies) {
        $pythonExe = Find-Python
        if (-not $pythonExe) { $pythonExe = "python" }

        Write-Step "Creating Python virtual environment..."
        & $pythonExe -m venv ".venv"
        $venvPython = Join-Path $InstallPath ".venv\Scripts\python.exe"

        Write-Step "Installing Python dependencies (this may take a minute)..."
        & $venvPython -m pip install --upgrade pip --quiet 2>&1 | Out-Null
        & $venvPython -m pip install -r "requirements.txt" --quiet 2>&1 | Out-Null
        Write-Success "Python dependencies installed."
    }

    # ─── Step 4: Node.js companion servers ───
    Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Step 4 of 6: Building companion servers..." -PercentComplete 55

    if (-not $SkipNodeBuild -and (Test-Path -LiteralPath "servers\package.json")) {
        $npmCommand = Get-Command npm -ErrorAction SilentlyContinue
        if ($npmCommand) {
            Write-Step "Installing and building MCP companion servers..."
            Push-Location "servers"
            try {
                & npm install --silent 2>&1 | Out-Null
                & npm run build --silent 2>&1 | Out-Null
                Write-Success "MCP companion servers built."
            }
            catch {
                Write-Warn "Companion server build had issues but setup will continue."
            }
            finally {
                Pop-Location
            }
        }
        else {
            Write-Warn "npm not found. Companion servers skipped."
        }
    }

    # ─── Step 5: Create shortcuts and launcher ───
    Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Step 5 of 6: Creating shortcuts..." -PercentComplete 75

    # Copy uninstall script into the install directory
    $uninstallSource = Join-Path $packageRoot "uninstall-endpoint-support-agent.ps1"
    if (Test-Path -LiteralPath $uninstallSource) {
        Copy-Item -LiteralPath $uninstallSource -Destination $InstallPath -Force
    }

    $launcherPath = Join-Path $InstallPath "Start-EndpointSupportAgent.ps1"
    $launcherContent = @"
`$ErrorActionPreference = "Stop"
Set-Location "$InstallPath"
`$python = Join-Path "$InstallPath" ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath `$python)) {
    `$python = "python"
}
& `$python "agent.py"
"@
    Set-Content -LiteralPath $launcherPath -Value $launcherContent -Encoding UTF8

    $shell = New-Object -ComObject WScript.Shell
    $iconPath = Join-Path $InstallPath "app.ico"

    # Start Menu shortcut (Run as Administrator)
    Write-Step "Creating shortcuts..."
    $startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    if (Test-Path -LiteralPath $startMenu) {
        $shortcutPath = Join-Path $startMenu "Endpoint Support Agent.lnk"
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = "powershell.exe"
        $shortcut.Arguments = "-ExecutionPolicy Bypass -NoExit -File `"$launcherPath`""
        $shortcut.WorkingDirectory = $InstallPath
        if (Test-Path -LiteralPath $iconPath) {
            $shortcut.IconLocation = $iconPath
        }
        $shortcut.Save()
        # Set "Run as Administrator" flag
        $bytes = [System.IO.File]::ReadAllBytes($shortcutPath)
        $bytes[0x15] = $bytes[0x15] -bor 0x20
        [System.IO.File]::WriteAllBytes($shortcutPath, $bytes)
        Write-Success "Start Menu shortcut created."
    }

    # Desktop shortcut (Run as Administrator)
    $desktop = [Environment]::GetFolderPath("Desktop")
    if (Test-Path -LiteralPath $desktop) {
        $desktopShortcutPath = Join-Path $desktop "Endpoint Support Agent.lnk"
        $desktopShortcut = $shell.CreateShortcut($desktopShortcutPath)
        $desktopShortcut.TargetPath = "powershell.exe"
        $desktopShortcut.Arguments = "-ExecutionPolicy Bypass -NoExit -File `"$launcherPath`""
        $desktopShortcut.WorkingDirectory = $InstallPath
        if (Test-Path -LiteralPath $iconPath) {
            $desktopShortcut.IconLocation = $iconPath
        }
        $desktopShortcut.Save()
        # Set "Run as Administrator" flag
        $bytes = [System.IO.File]::ReadAllBytes($desktopShortcutPath)
        $bytes[0x15] = $bytes[0x15] -bor 0x20
        [System.IO.File]::WriteAllBytes($desktopShortcutPath, $bytes)
        Write-Success "Desktop shortcut created."
    }

    # ─── Step 6: Register in Programs and Features ───
    Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Step 6 of 6: Registering application..." -PercentComplete 90

    Write-Step "Registering in Programs and Features..."
    $uninstallRegKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EndpointSupportAgent"
    $uninstallScript = Join-Path $InstallPath "uninstall-endpoint-support-agent.ps1"
    $uninstallCmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$uninstallScript`""

    New-Item -Path $uninstallRegKey -Force | Out-Null
    Set-ItemProperty -Path $uninstallRegKey -Name "DisplayName" -Value "Endpoint Support Agent"
    Set-ItemProperty -Path $uninstallRegKey -Name "DisplayVersion" -Value $AppVersion
    Set-ItemProperty -Path $uninstallRegKey -Name "Publisher" -Value $AppPublisher
    Set-ItemProperty -Path $uninstallRegKey -Name "InstallLocation" -Value $InstallPath
    Set-ItemProperty -Path $uninstallRegKey -Name "UninstallString" -Value $uninstallCmd
    if (Test-Path -LiteralPath $iconPath) {
        Set-ItemProperty -Path $uninstallRegKey -Name "DisplayIcon" -Value "$iconPath,0"
    }
    Set-ItemProperty -Path $uninstallRegKey -Name "NoModify" -Value 1 -Type DWord
    Set-ItemProperty -Path $uninstallRegKey -Name "NoRepair" -Value 1 -Type DWord
    Set-ItemProperty -Path $uninstallRegKey -Name "EstimatedSize" -Value 50000 -Type DWord
    Write-Success "Registered in Programs and Features."

    # ─── Done ───
    Write-Progress -Activity "Endpoint Support Agent Setup" -Status "Complete!" -PercentComplete 100 -Completed

    Write-Host ""
    Write-Host "  ╔═══════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║          Setup Complete!                             ║" -ForegroundColor Green
    Write-Host "  ╚═══════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Installed to: $InstallPath" -ForegroundColor White
    Write-Host ""
    Write-Host "  Next steps:" -ForegroundColor Green
    Write-Host "  1. Launch Endpoint Support Agent from your Desktop or Start Menu."
    Write-Host "  2. Paste your API key when prompted on first launch."
    Write-Host ""
    Write-Host "  To uninstall: Control Panel > Programs and Features > Endpoint Support Agent"
    Write-Host ""
}
finally {
    Pop-Location
}
