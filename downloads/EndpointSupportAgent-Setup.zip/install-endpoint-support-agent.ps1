param(
    [string]$InstallPath = "$env:LOCALAPPDATA\EndpointSupportAgent",
    [switch]$SkipPythonDependencies,
    [switch]$SkipNodeBuild
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "[Endpoint Support Agent] $Message" -ForegroundColor Cyan
}

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSource = Join-Path $packageRoot "app"

if (-not (Test-Path -LiteralPath $appSource)) {
    throw "The setup package is missing the 'app' folder. Extract the full ZIP package and run this script again."
}

$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCommand) {
    throw "Python was not found. Install Python 3.10 or newer, then run this setup script again."
}

Write-Step "Installing to $InstallPath"
New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
Copy-Item -Path (Join-Path $appSource "*") -Destination $InstallPath -Recurse -Force

Push-Location $InstallPath
try {
    if (-not (Test-Path -LiteralPath ".env") -and (Test-Path -LiteralPath ".env.example")) {
        Copy-Item -LiteralPath ".env.example" -Destination ".env"
        Write-Step "Created .env from .env.example. Add your OpenRouter API key before first use."
    }

    if (-not $SkipPythonDependencies) {
        Write-Step "Creating Python virtual environment"
        & python -m venv ".venv"
        $venvPython = Join-Path $InstallPath ".venv\Scripts\python.exe"
        Write-Step "Installing Python dependencies"
        & $venvPython -m pip install --upgrade pip
        & $venvPython -m pip install -r "requirements.txt"
    }

    if (-not $SkipNodeBuild -and (Test-Path -LiteralPath "servers\package.json")) {
        $npmCommand = Get-Command npm -ErrorAction SilentlyContinue
        if ($npmCommand) {
            Write-Step "Installing and building optional MCP companion servers"
            Push-Location "servers"
            try {
                & npm install
                & npm run build
            }
            finally {
                Pop-Location
            }
        }
        else {
            Write-Host "[Endpoint Support Agent] npm was not found. Optional Node MCP companion servers were not built." -ForegroundColor Yellow
        }
    }

    $launcherPath = Join-Path $InstallPath "Start-EndpointSupportAgent.ps1"
    $launcherContent = @"
`$ErrorActionPreference = "Stop"
Set-Location "$InstallPath"
`$python = Join-Path "$InstallPath" ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath `$python)) {
    `$python = "python"
}
& `$python "agent.py"
"@
    Set-Content -LiteralPath $launcherPath -Value $launcherContent -Encoding UTF8

    $startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    if (Test-Path -LiteralPath $startMenu) {
        $shortcutPath = Join-Path $startMenu "Endpoint Support Agent.lnk"
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = "powershell.exe"
        $shortcut.Arguments = "-ExecutionPolicy Bypass -NoExit -File `"$launcherPath`""
        $shortcut.WorkingDirectory = $InstallPath
        $shortcut.Save()
        Write-Step "Created Start Menu shortcut"
    }

    Write-Step "Setup complete"
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Green
    Write-Host "1. Edit $InstallPath\.env and add OPENROUTER_API_KEY."
    Write-Host "2. Run $launcherPath"
    Write-Host "3. For OEM driver remediation, launch PowerShell as Administrator."
}
finally {
    Pop-Location
}
