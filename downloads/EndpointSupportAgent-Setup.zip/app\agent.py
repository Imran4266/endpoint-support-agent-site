import json
import os
import re
import sys
import uuid
from dataclasses import replace
from datetime import datetime
from typing import Callable, Dict, List, Optional

import requests
from rich import box
from rich.align import Align
from rich.console import Console
from rich.live import Live
from rich.markup import escape
from rich.panel import Panel
from rich.prompt import Confirm, Prompt

from config import Settings, load_settings
from mcp_client import MultiMCPClient
from tools.diagnose import get_tool
from tools.endpoint_skills import list_endpoint_skills
from tools.oem_support import oem_driver_utility_install_plan

MAX_TOOL_ITERATIONS = 15
APP_TITLE = "Endpoint Support Agent"
MODEL_PAGE_SIZE = 7
OPENROUTER_MODELS_URL = "https://openrouter.ai/api/v1/models"
MIN_PANEL_WIDTH = 42
MAX_COMPACT_PANEL_WIDTH = 96


class AuditLogger:
    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or load_settings()
        self.settings.audit_log_path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, session_id: str, action: str, approved: bool, status: str) -> None:
        log_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "session_id": session_id,
            "user": "Helpdesk_Admin",
            "action": action,
            "approved": approved,
            "status": status,
        }
        with self.settings.audit_log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(log_entry) + "\n")


SYSTEM_PROMPT = (
    "You are an Endpoint Support Agent. Your primary goal is to resolve the user's IT issues.\n"
    "CRITICAL INSTRUCTIONS:\n"
    "1. When the user reports a NEW problem (e.g., 'PC is slow', 'VPN disconnected'), "
    "you MUST IMMEDIATELY call the `legacy__resolve_issue` tool using their input as the "
    "issue description. Do NOT ask clarifying questions before calling this tool.\n"
    "2. Present the findings and troubleshooting steps returned by `legacy__resolve_issue` clearly to the user.\n"
    "3. If the user asks to run a read-only diagnostic tool returned by `legacy__resolve_issue`, "
    "call `legacy__execute_diagnostic` with the EXACT diagnostic tool name. Do NOT call "
    "`legacy__execute_remediation` for diagnostic tools such as `Get-HealthReport`.\n"
    "4. If `legacy__resolve_issue` returns a recommended remediation action, ask the user "
    "if they would like to proceed. When the user confirms (e.g., 'yes', 'go ahead', 'do it'), "
    "you MUST call the `legacy__execute_remediation` tool with the EXACT action name from "
    "the resolve_issue result (e.g., 'Run-PerformanceCleanup', 'Flush-DNS'). "
    "Do NOT make up action names.\n"
    "5. If the user says 'yes', 'ok', 'go ahead', 'sure', 'do it', or similar in response to a "
    "remediation offer, that means they want you to execute the remediation. Do NOT call "
    "`legacy__resolve_issue` again; call `legacy__execute_remediation` instead.\n"
    "6. If the user asks to disable or remove an application from Windows startup, call "
    "`legacy__disable_startup_app` with the exact app name and request approval before changes.\n"
    "7. If the user asks you to perform an endpoint action such as restart a service, clear an app cache, "
    "sync Intune, repair Windows Update, refresh policy, restart audio/camera/search, install/update/reinstall a device driver, or similar, call "
    "`legacy__plan_endpoint_action` first. If it returns a supported remediation, present the plan and wait "
    "for user approval before calling `legacy__execute_parameterized_remediation` with the exact intent and target. "
    "If it returns unsupported, explain that safely and do not invent commands.\n"
    "8. You may call `legacy__search_endpoint_capabilities` when you need to discover what actions are supported, "
    "`legacy__search_endpoint_skills` when you need skill-level troubleshooting guidance, "
    "`legacy__get_oem_device_profile` and `legacy__search_oem_guidance` for OEM-backed driver, BIOS, firmware, camera, dock, or hardware guidance questions only, "
    "`legacy__scan_oem_driver_updates` to check trusted OEM driver updates, `legacy__install_oem_driver_updates` only after explicit approval when the OEM utility is already present, "
    "and `legacy__install_oem_driver_utility_and_updates` only after explicit approval when a supported OEM utility must be installed first, "
    "and `legacy__verify_endpoint_action` after remediation to run read-only verification diagnostics.\n"
    "9. Only use other tools (filesystem, memory, sequentialthinking) if you need to "
    "gather specific logs, track context, or if the legacy resolver doesn't have the answer.\n"
    "10. Speak in plain English for non-technical employees. Prefer simple words such as check, fix, app, "
    "device, and approval. Avoid showing internal tool names unless the user asks for technical details."
)


class EndpointSupportAgent:
    """Agent that delegates issue resolution to multiple MCP servers via LLM.

    Maintains conversation history across turns so the LLM has full context
    when the user replies with follow-ups like 'yes' or 'no'.
    """

    def __init__(
        self,
        mcp_client: MultiMCPClient,
        llm_client,
        settings: Settings,
        audit_logger: Optional[AuditLogger] = None,
    ):
        self.mcp_client = mcp_client
        self.llm_client = llm_client
        self.settings = settings
        self.audit_logger = audit_logger
        self.session_id = _session_id()
        self._messages: List[Dict] = [{"role": "system", "content": SYSTEM_PROMPT}]
        self._openai_tools: Optional[List[Dict]] = None
        self._last_resolution: Optional[Dict] = None
        self._last_diagnostic: Optional[Dict] = None
        self._last_technical_details: Optional[str] = None
        self._last_remediation: Optional[Dict] = None
        self._last_oem_guidance: Optional[Dict] = None
        self._last_oem_driver_install_blocked = False
        self._pending_remediation: Optional[Dict] = None
        self._pending_endpoint_action: Optional[Dict] = None

    def _get_openai_tools(self) -> List[Dict]:
        """Build OpenAI-format tool schemas once and cache them."""
        if self._openai_tools is None:
            tools = self.mcp_client.list_tools()
            self._openai_tools = [
                {
                    "type": "function",
                    "function": {
                        "name": t["name"],
                        "description": t.get("description", ""),
                        "parameters": t.get("inputSchema", {"type": "object", "properties": {}}),
                    },
                }
                for t in tools
                if not t["name"].endswith("__set_model")
            ]
        return self._openai_tools

    def handle_issue(
        self,
        user_input: str,
        approval_provider: Callable[[Dict], bool],
    ) -> str:
        # Append the new user message to the persistent conversation history
        self._messages.append({"role": "user", "content": user_input})

        follow_up = self._handle_known_follow_up(user_input, approval_provider)
        if follow_up is not None:
            self._messages.append({"role": "assistant", "content": follow_up})
            return f"Agent: {follow_up}"

        if not self.llm_client:
            return "Agent: LLM client is required for multi-MCP tool routing."

        openai_tools = self._get_openai_tools()

        for _iteration in range(MAX_TOOL_ITERATIONS):
            try:
                response = self.llm_client.chat.completions.create(
                    model=self.settings.model,
                    messages=self._messages,
                    tools=openai_tools if openai_tools else None,
                )
            except Exception as exc:
                return f"Agent: LLM error: {exc}"

            msg = response.choices[0].message
            msg_dict = msg.model_dump(exclude_none=True)
            self._messages.append(msg_dict)

            if not msg.tool_calls:
                return f"Agent: {_safe_llm_content(msg.content)}"

            for tool_call in msg.tool_calls:
                name = tool_call.function.name
                try:
                    arguments = json.loads(tool_call.function.arguments)
                except json.JSONDecodeError:
                    arguments = {}

                # Check for approval if it's remediation
                if name.endswith("execute_remediation"):
                    action_name = arguments.get("action", "unknown")
                    approval_action = self._action_metadata(action_name)
                    if not approval_provider(approval_action):
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": json.dumps({"error": "User declined approval."}),
                        })
                        self._write_audit(self.session_id, name, False, "Declined")
                        declined = "Remediation declined. No endpoint changes were made."
                        self._messages.append({"role": "assistant", "content": declined})
                        return f"Agent: {declined}"
                    # Sync CLI approval into arguments so diagnose.py honours it
                    arguments["approved"] = True
                elif name.endswith("disable_startup_app"):
                    app_name = str(arguments.get("app", "")).strip()
                    if not _clean_requested_app_name(app_name):
                        message = "Please specify which startup app you want to disable."
                        self._messages.append({"role": "assistant", "content": message})
                        return f"Agent: {message}"
                    approval_action = self._startup_action_metadata(app_name)
                    if not approval_provider(approval_action):
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": json.dumps({"error": "User declined approval."}),
                        })
                        self._write_audit(self.session_id, name, False, "Declined")
                        declined = "Startup app remediation declined. No endpoint changes were made."
                        self._messages.append({"role": "assistant", "content": declined})
                        return f"Agent: {declined}"
                    arguments["approved"] = True
                elif name.endswith("execute_parameterized_remediation"):
                    approval_action = self._endpoint_action_metadata(arguments)
                    if not approval_provider(approval_action):
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": json.dumps({"error": "User declined approval."}),
                        })
                        self._write_audit(self.session_id, name, False, "Declined")
                        declined = "Endpoint action declined. No endpoint changes were made."
                        self._messages.append({"role": "assistant", "content": declined})
                        return f"Agent: {declined}"
                    arguments["approved"] = True
                elif name.endswith("install_oem_driver_utility_and_updates"):
                    approval_action = self._oem_driver_action_metadata(include_utility=True)
                    if not approval_provider(approval_action):
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": json.dumps({"error": "User declined approval."}),
                        })
                        self._write_audit(self.session_id, name, False, "Declined")
                        declined = "OEM driver installation declined. No endpoint changes were made."
                        self._messages.append({"role": "assistant", "content": declined})
                        return f"Agent: {declined}"
                    arguments["approved"] = True
                elif name.endswith("install_oem_driver_updates"):
                    approval_action = self._oem_driver_action_metadata()
                    if not approval_provider(approval_action):
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": json.dumps({"error": "User declined approval."}),
                        })
                        self._write_audit(self.session_id, name, False, "Declined")
                        declined = "OEM driver installation declined. No endpoint changes were made."
                        self._messages.append({"role": "assistant", "content": declined})
                        return f"Agent: {declined}"
                    arguments["approved"] = True

                try:
                    result = self.mcp_client.call_tool(name, arguments)
                    self._write_audit(self.session_id, name, True, "Success")
                except Exception as exc:
                    result = {"error": str(exc)}
                    self._write_audit(self.session_id, name, False, "Failed")

                self._messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": json.dumps(result),
                })

                rendered = self._render_tool_result(name, result)
                if rendered is not None:
                    self._messages.append({"role": "assistant", "content": rendered})
                    return f"Agent: {rendered}"

        return "Agent: I've reached the maximum number of steps. Please try rephrasing your issue."

    def _handle_known_follow_up(
        self,
        user_input: str,
        approval_provider: Callable[[Dict], bool],
    ) -> Optional[str]:
        text = user_input.strip()
        if not text:
            return None

        lower_text = text.lower()
        if lower_text in {"details", "show details", "technical details", "raw output", "show raw output"}:
            return self._last_technical_details or "I do not have technical details to show yet."

        if _is_skill_list_request(lower_text):
            return _render_skill_catalog(list_endpoint_skills())

        if _is_oem_profile_request(lower_text):
            result = self._call_tool_with_audit("legacy__get_oem_device_profile", {}, approved=True)
            return self._render_oem_device_profile(result)

        cleanup_details = self._cleanup_details_follow_up(lower_text)
        if cleanup_details:
            return cleanup_details

        if self._last_oem_driver_install_blocked and _is_blocked_oem_driver_follow_up(lower_text):
            return (
                "There is no OEM driver installation ready to run because I did not detect a supported OEM update utility on this endpoint. "
                "Install or configure Dell Command Update, HP Image Assistant, Lenovo System Update, or use your managed Intune/SCCM driver deployment, then ask me again."
            )

        if self._pending_endpoint_action and _is_endpoint_action_confirmation(lower_text) and not _mentions_step(lower_text):
            return self._execute_pending_endpoint_action(approval_provider)

        if _is_oem_driver_install_request(lower_text):
            return self._plan_oem_driver_install(text)

        if _is_oem_driver_install_follow_up(lower_text, self._last_oem_guidance):
            request = str((self._last_oem_guidance or {}).get("query") or "install OEM driver updates")
            return self._plan_oem_driver_install(request)

        if _is_startup_list_request(lower_text):
            return self._execute_diagnostic(
                {
                    "name": "Get-StartupPrograms",
                    "description": "List startup programs that may affect login or performance.",
                }
            )

        if _is_generic_startup_disable_request(lower_text):
            startup_list = self._execute_diagnostic(
                {
                    "name": "Get-StartupPrograms",
                    "description": "List startup programs that may affect login or performance.",
                }
            )
            return (
                f"{startup_list}\n\n"
                "Tell me the exact startup item name you want to disable, for example: disable AnyDesk from startup."
            )

        startup_app = _startup_app_name_from_disable_request(text, self._last_diagnostic)
        if startup_app:
            return self._execute_startup_app_disable(startup_app, approval_provider)

        startup_selection = _startup_app_selection(text, self._last_diagnostic)
        if startup_selection:
            return self._plan_startup_app_disable(startup_selection)

        if not self._last_resolution:
            return None

        if self._pending_remediation and _is_affirmative(lower_text) and not _mentions_step(lower_text):
            return self._execute_pending_remediation(approval_provider)

        option_number = _option_number(lower_text)
        if option_number is not None:
            diagnostic_tools = self._last_resolution.get("diagnostic_tools") or []
            if 1 <= option_number <= len(diagnostic_tools):
                return self._execute_diagnostic(diagnostic_tools[option_number - 1])
            if self._pending_remediation and option_number == len(diagnostic_tools) + 1:
                return self._execute_pending_remediation(approval_provider)
            return self._valid_option_message()

        step_number = _step_number(lower_text)
        if step_number is not None:
            steps = self._last_resolution.get("steps") or []
            if 1 <= step_number <= len(steps):
                diagnostic_tool = self._diagnostic_from_text(steps[step_number - 1])
                if diagnostic_tool:
                    return self._execute_diagnostic(diagnostic_tool)
                return (
                    f"Step {step_number} is a manual review step. "
                    "I can run one of the read-only diagnostics listed above, or you can approve the recommended remediation."
                )
            return self._valid_option_message()

        diagnostic_tool = self._diagnostic_from_text(text)
        if diagnostic_tool:
            return self._execute_diagnostic(diagnostic_tool)

        if self._pending_remediation and _mentions_remediation(lower_text, self._pending_remediation):
            return self._execute_pending_remediation(approval_provider)

        return None

    def _execute_pending_remediation(self, approval_provider: Callable[[Dict], bool]) -> str:
        action = self._pending_remediation
        if not action:
            return "There is no remediation action pending right now."

        action_name = str(action.get("name", "")).strip()
        if not action_name:
            return "The pending remediation action is missing a tool name."

        if not approval_provider(action):
            self._write_audit(self.session_id, "legacy__execute_remediation", False, "Declined")
            return "Remediation declined. No endpoint changes were made."

        result = self._call_tool_with_audit(
            "legacy__execute_remediation",
            {"action": action_name, "approved": True},
            approved=True,
        )
        return self._render_remediation_result(result)

    def _execute_startup_app_disable(self, app_name: str, approval_provider: Callable[[Dict], bool]) -> str:
        action = self._startup_action_metadata(app_name)
        if not action["app"]:
            return "Please specify which startup app you want to disable."
        if not approval_provider(action):
            self._write_audit(self.session_id, "legacy__disable_startup_app", False, "Declined")
            return "Startup app remediation declined. No endpoint changes were made."

        result = self._call_tool_with_audit(
            "legacy__disable_startup_app",
            {"app": action["app"], "approved": True},
            approved=True,
        )
        return self._render_remediation_result(result)

    def _plan_startup_app_disable(self, app_name: str) -> str:
        target = _clean_requested_app_name(app_name)
        if not target:
            return "Please specify which startup app you want to disable."

        return self._plan_endpoint_action(f"disable {target} from startup")

    def _plan_endpoint_action(self, request: str) -> str:
        result = self._call_tool_with_audit(
            "legacy__plan_endpoint_action",
            {"request": request},
            approved=True,
        )
        return self._render_endpoint_action_plan(result)

    def _plan_oem_driver_install(self, request: str) -> str:
        profile_result = self._call_tool_with_audit("legacy__get_oem_device_profile", {}, approved=True)
        if profile_result.get("error"):
            self._pending_endpoint_action = None
            return f"OEM check failed: {profile_result['error']}"

        profile = profile_result.get("profile") or {}
        supported_tools = _supported_oem_driver_tools(profile)
        utility_plan = oem_driver_utility_install_plan(profile)
        context = _oem_driver_context_summary(profile_result, supported_tools, utility_plan)
        if not supported_tools:
            if utility_plan:
                plan = self._call_tool_with_audit(
                    "legacy__plan_endpoint_action",
                    {"request": "install OEM driver utility and driver updates"},
                    approved=True,
                )
                self._last_oem_driver_install_blocked = False
                if not plan.get("error") and plan.get("intent") == "driver.oem_bootstrap_update":
                    plan["oem_guidance"] = profile_result.get("guidance") or plan.get("oem_guidance") or []
                    method = utility_plan.get("install_method") or "the OEM-supported package path"
                    package = utility_plan.get("package_id") or "the OEM utility package"
                    plan["message"] = (
                        f"I did not detect {utility_plan.get('name', 'the OEM driver utility')}. "
                        f"With approval, I can install it using {method} ({package}), then run OEM driver updates through that utility."
                    )
                rendered_plan = self._render_endpoint_action_plan(plan)
                return f"{context}\n\n{rendered_plan}"

            self._last_oem_driver_install_blocked = True
            self._pending_endpoint_action = None
            self._pending_remediation = None
            return (
                f"{context}\n\n"
                "I cannot start OEM driver installation automatically because I did not detect a supported OEM driver update utility installer for this endpoint.\n\n"
                "Supported bootstrap utilities for this workflow are Dell Command Update, HP Image Assistant, and Lenovo System Update. "
                "For other OEMs, use Windows Update, Intune/SCCM, or the vendor's managed driver deployment path."
            )

        plan = self._call_tool_with_audit(
            "legacy__plan_endpoint_action",
            {"request": request},
            approved=True,
        )
        self._last_oem_driver_install_blocked = False
        if not plan.get("error") and plan.get("intent") == "driver.oem_update":
            plan["oem_guidance"] = profile_result.get("guidance") or plan.get("oem_guidance") or []
            plan["message"] = (
                f"I detected {supported_tools[0]}. Approval is required before installing OEM driver updates."
            )
        rendered_plan = self._render_endpoint_action_plan(plan)
        return f"{context}\n\n{rendered_plan}"

    def _execute_pending_endpoint_action(self, approval_provider: Callable[[Dict], bool]) -> str:
        plan = self._pending_endpoint_action
        if not plan:
            return "There is no endpoint action pending right now."

        remediation = plan.get("remediation") or {}
        approval_action = self._endpoint_action_metadata(
            {
                "intent": plan.get("intent"),
                "target": plan.get("target"),
                "parameters": {"plan": plan},
            }
        )
        if not remediation:
            return "The pending endpoint action does not have an executable remediation."
        if not approval_provider(approval_action):
            self._write_audit(self.session_id, "legacy__execute_parameterized_remediation", False, "Declined")
            return "Endpoint action declined. No endpoint changes were made."

        result = self._call_tool_with_audit(
            "legacy__execute_parameterized_remediation",
            {
                "intent": plan.get("intent"),
                "target": plan.get("target"),
                "parameters": {"plan": plan},
                "approved": True,
            },
            approved=True,
        )
        return self._render_remediation_result(result)

    def _execute_diagnostic(self, diagnostic_tool: Dict) -> str:
        tool_name = str(diagnostic_tool.get("name", "")).strip()
        if not tool_name:
            return "That diagnostic option is missing a tool name."

        result = self._call_tool_with_audit(
            "legacy__execute_diagnostic",
            {"tool": tool_name},
            approved=True,
        )
        return self._render_diagnostic_result(result)

    def _call_tool_with_audit(self, name: str, arguments: Dict, approved: bool) -> Dict:
        try:
            result = self.mcp_client.call_tool(name, arguments)
            self._write_audit(self.session_id, name, approved, "Success")
            return result
        except Exception as exc:
            self._write_audit(self.session_id, name, False, "Failed")
            return {"error": str(exc)}

    def _render_tool_result(self, tool_name: str, result: Dict) -> Optional[str]:
        if result.get("error"):
            return f"Tool call failed: {result['error']}"
        if tool_name.endswith("resolve_issue"):
            resolution = result.get("resolution") or {}
            self._last_resolution = resolution
            self._pending_remediation = resolution.get("recommended_action")
            return self._render_resolution(resolution)
        if tool_name.endswith("execute_diagnostic"):
            return self._render_diagnostic_result(result)
        if tool_name.endswith("execute_remediation"):
            return self._render_remediation_result(result)
        if tool_name.endswith("disable_startup_app"):
            return self._render_remediation_result(result)
        if tool_name.endswith("plan_endpoint_action"):
            return self._render_endpoint_action_plan(result)
        if tool_name.endswith("search_endpoint_capabilities"):
            return self._render_endpoint_capability_search(result)
        if tool_name.endswith("search_endpoint_skills"):
            return _render_skill_catalog(result.get("skills") or [])
        if tool_name.endswith("list_endpoint_skills"):
            return _render_skill_catalog(result.get("skills") or [])
        if tool_name.endswith("get_oem_device_profile"):
            return self._render_oem_device_profile(result)
        if tool_name.endswith("search_oem_guidance"):
            return self._render_oem_guidance(result)
        if tool_name.endswith("scan_oem_driver_updates"):
            return self._render_oem_driver_scan(result)
        if tool_name.endswith("install_oem_driver_utility_and_updates"):
            return self._render_oem_driver_install(result)
        if tool_name.endswith("install_oem_driver_updates"):
            return self._render_oem_driver_install(result)
        if tool_name.endswith("execute_parameterized_remediation"):
            return self._render_remediation_result(result)
        if tool_name.endswith("verify_endpoint_action"):
            return self._render_endpoint_verification(result)
        return None

    def _render_resolution(self, resolution: Dict) -> str:
        title = resolution.get("title", "Endpoint troubleshooting")
        findings = resolution.get("findings", "I found a matching endpoint support runbook.")
        confidence = resolution.get("confidence")
        steps = resolution.get("steps") or []
        external_steps = resolution.get("external_steps") or []
        diagnostic_tools = resolution.get("diagnostic_tools") or []
        recommended_action = resolution.get("recommended_action")
        skills = resolution.get("skills") or []

        lines = [str(title)]
        if isinstance(confidence, (int, float)) and confidence:
            lines.append(f"Match confidence: {confidence:.0%}")
        lines.extend(["", f"What I found: {findings}"])

        if skills:
            lines.extend(["", "Skill applied:"])
            lines.extend(_skill_summary_lines(skills, limit=2))

        if steps:
            lines.extend(["", "What I will do:"])
            lines.extend(f"- {_plain_step(step)}" for step in steps)

        if external_steps:
            lines.extend(["", "Extra notes:"])
            lines.extend(f"- {step}" for step in external_steps)

        if diagnostic_tools:
            lines.extend(["", "Checks I can run now:"])
            for index, tool in enumerate(diagnostic_tools, start=1):
                lines.append(
                    f"{index}. {_friendly_tool_name(tool.get('name'))} - {_plain_description(tool.get('description'))}"
                )

        if recommended_action:
            remediation_index = len(diagnostic_tools) + 1
            lines.extend(
                [
                    "",
                    "Recommended fix:",
                    (
                        f"{remediation_index}. {_friendly_tool_name(recommended_action.get('name'))} - "
                        f"{_plain_description(recommended_action.get('description'))}"
                    ),
                    "Reply with a number to run a check, or say yes if you want me to ask for approval to apply the fix.",
                ]
            )

        return "\n".join(lines)

    def _render_endpoint_action_plan(self, plan: Dict) -> str:
        status = str(plan.get("status") or "unknown")
        title = plan.get("title") or "Endpoint action plan"
        confidence = plan.get("confidence")
        target = plan.get("target")
        diagnostics = plan.get("diagnostic_tools") or []
        verification = plan.get("verification_tools") or []
        remediation = plan.get("remediation")
        skills = plan.get("skills") or []
        oem_guidance = plan.get("oem_guidance") or []

        if status == "ready" and remediation:
            self._pending_endpoint_action = plan
            self._pending_remediation = None
        else:
            self._pending_endpoint_action = None

        lines = [str(title)]
        if isinstance(confidence, (int, float)):
            lines.append(f"Match confidence: {confidence:.0%}")
        lines.append(f"Status: {_friendly_plan_status(status)}")
        if target:
            lines.append(f"Target: {target}")

        if skills:
            lines.extend(["", "Skill used:"])
            lines.extend(_skill_summary_lines(skills, limit=2))

        message = plan.get("message")
        if message:
            lines.extend(["", str(message)])

        if oem_guidance:
            lines.extend(["", "OEM guidance:"])
            lines.extend(_oem_guidance_lines(oem_guidance, limit=2))

        if diagnostics:
            lines.extend(["", "Checks available:"])
            lines.extend(f"- {_friendly_tool_name(tool)}" for tool in diagnostics)

        if remediation:
            lines.extend(
                [
                    "",
                    "Recommended action:",
                    f"- {_friendly_tool_name(remediation.get('name'))} - {_plain_description(remediation.get('description'))}",
                    "Reply yes to request the approval prompt, or ask me to run a check first.",
                ]
            )
        elif status == "unsupported":
            lines.extend(["", "I can help diagnose this, but I do not have a safe automatic fix for it yet."])

        if verification:
            lines.extend(["", "After the fix, I can verify with:"])
            lines.extend(f"- {_friendly_tool_name(tool)}" for tool in verification)

        return "\n".join(lines)

    def _render_endpoint_capability_search(self, result: Dict) -> str:
        capabilities = result.get("capabilities") or []
        if not capabilities:
            return "No matching endpoint capabilities were found."

        lines = ["Things I can help with:"]
        for capability in capabilities:
            supported = "can fix with approval" if capability.get("supported") else "can diagnose only"
            skills = capability.get("skills") or []
            skill_suffix = ""
            if skills:
                skill_suffix = f" | Skill: {skills[0].get('title')}"
            lines.append(
                f"- {capability.get('title')} ({supported}){skill_suffix}"
            )
        return "\n".join(lines)

    def _render_oem_device_profile(self, result: Dict) -> str:
        if result.get("error"):
            return f"OEM check failed: {result['error']}"

        profile = result.get("profile") or {}
        guidance = result.get("guidance") or []
        installed_tools = profile.get("installed_tools") or []
        installed_packages = profile.get("installed_packages") or []

        lines = ["OEM device profile"]
        vendor = profile.get("oem_vendor") or "Unknown"
        manufacturer = profile.get("manufacturer") or "Unknown manufacturer"
        model = profile.get("model") or "Unknown model"
        lines.append(f"OEM: {vendor}")
        lines.append(f"Device: {manufacturer} {model}".strip())
        if profile.get("system_sku"):
            lines.append(f"SKU: {profile.get('system_sku')}")
        if profile.get("bios_version"):
            lines.append(f"BIOS: {profile.get('bios_version')}")

        if installed_tools:
            lines.extend(["", "OEM tools found:"])
            for tool in installed_tools[:5]:
                name = tool.get("name") or "OEM update tool"
                command = tool.get("command") or ""
                lines.append(f"- {name}" + (f" ({command})" if command else ""))
        elif installed_packages:
            lines.extend(["", "OEM apps found:"])
            for package in installed_packages[:5]:
                lines.append(f"- {package.get('name')} {package.get('version', '')}".rstrip())
        else:
            lines.extend(["", "OEM tools found: none detected in common locations."])

        if guidance:
            lines.extend(["", "Trusted update path:"])
            lines.extend(_oem_guidance_lines(guidance, limit=2))

        return "\n".join(lines)

    def _render_oem_guidance(self, result: Dict) -> str:
        if result.get("error"):
            return f"OEM guidance lookup failed: {result['error']}"
        self._last_oem_guidance = {
            "query": result.get("query") or "",
            "manufacturer": result.get("manufacturer") or "",
            "model": result.get("model") or "",
            "guidance": result.get("guidance") or [],
        }
        guidance = result.get("guidance") or []
        if not guidance:
            return "I could not find OEM guidance for that request."
        lines = ["OEM guidance:"]
        lines.extend(_oem_guidance_lines(guidance, limit=4))
        return "\n".join(lines)

    def _render_oem_driver_scan(self, result: Dict) -> str:
        if result.get("error"):
            return f"OEM driver scan failed: {result['error']}"

        installer = result.get("installer") or {}
        command_result = result.get("result") or {}
        if not result.get("supported"):
            message = result.get("message") or "No supported OEM driver update utility was detected."
            return f"OEM driver scan could not run.\n\n{message}"

        self._last_technical_details = (
            "OEM driver scan completed.\n\n"
            f"Tool: {installer.get('name', 'OEM update utility')}\n\n"
            f"Output:\n{command_result.get('stdout') or ''}\n\n"
            f"Error:\n{command_result.get('stderr') or ''}"
        )
        if command_result.get("ok"):
            return (
                f"OEM driver scan completed using {installer.get('name', 'the OEM update utility')}.\n\n"
                f"{_shorten(command_result.get('stdout') or 'The OEM tool completed the scan.', limit=500)}\n\n"
                "You can type details if you want the technical output."
            )
        return (
            f"OEM driver scan could not complete using {installer.get('name', 'the OEM update utility')}.\n\n"
            f"What happened: {_shorten(command_result.get('stderr') or command_result.get('stdout') or 'No output was returned.')}"
        )

    def _render_oem_driver_install(self, result: Dict) -> str:
        if result.get("error"):
            self._pending_remediation = None
            self._pending_endpoint_action = None
            return f"OEM driver installation failed: {result['error']}"

        installer = result.get("installer") or {}
        command_result = result.get("result") or {}
        action = result.get("action") or {}
        action_name = action.get("name") or "Install-OEMDriverUpdates"
        utility_was_installed = bool(result.get("utility_was_installed"))
        self._last_technical_details = (
            "OEM driver installation completed.\n\n"
            f"Tool: {installer.get('name', 'OEM update utility')}\n\n"
            f"Output:\n{command_result.get('stdout') or ''}\n\n"
            f"Error:\n{command_result.get('stderr') or ''}"
        )
        self._last_remediation = {
            "name": action_name,
            "ok": bool(command_result.get("ok")),
            "stdout": command_result.get("stdout") or "",
            "stderr": command_result.get("stderr") or "",
        }
        self._pending_remediation = None
        self._pending_endpoint_action = None

        if command_result.get("ok"):
            if action_name == "Install-OEMDriverUtilityAndUpdates" and utility_was_installed:
                return (
                    f"{installer.get('name', 'The OEM update utility')} was installed, then OEM driver updates were run through it.\n\n"
                    "Only the OEM utility path was used. A restart may still be required if the OEM tool reports it.\n\n"
                    "You can type details if you want the technical output."
                )
            return (
                f"OEM driver updates were installed using {installer.get('name', 'the OEM update utility')}.\n\n"
                "Only the detected OEM update utility was used. A restart may still be required if the OEM tool reports it.\n\n"
                "You can type details if you want the technical output."
            )
        return (
            f"OEM driver installation could not complete using {installer.get('name', 'the OEM update utility')}.\n\n"
            f"What happened: {_shorten(command_result.get('stderr') or command_result.get('stdout') or 'No output was returned.')}"
        )

    def _render_endpoint_verification(self, result: Dict) -> str:
        diagnostics = result.get("diagnostics") or []
        if not diagnostics:
            return "No verification diagnostics are available for that endpoint action."

        lines = ["Verification result:"]
        for item in diagnostics:
            diagnostic = item.get("diagnostic") or {}
            command_result = item.get("result") or {}
            name = diagnostic.get("name", "Diagnostic")
            if command_result.get("ok", False):
                stdout = command_result.get("stdout") or "completed with no output"
                lines.append(f"- {_friendly_tool_name(name)}: {_shorten(stdout)}")
            else:
                stderr = command_result.get("stderr") or "failed with no output"
                lines.append(f"- {_friendly_tool_name(name)} failed: {_shorten(stderr)}")
        return "\n".join(lines)

    def _render_diagnostic_result(self, result: Dict) -> str:
        if result.get("error"):
            return f"Diagnostic failed: {result['error']}"

        diagnostic = result.get("diagnostic") or {}
        self._last_diagnostic = diagnostic
        command_result = result.get("result") or {}
        name = diagnostic.get("name", "Diagnostic")
        friendly_name = _friendly_tool_name(name)
        if not command_result.get("ok", False):
            stderr = command_result.get("stderr") or "No diagnostic output was returned."
            self._last_technical_details = f"{name} failed.\n\nError:\n{stderr}"
            return f"{friendly_name} could not complete.\n\nWhat happened: {_shorten(stderr)}"

        stdout = command_result.get("stdout") or "The diagnostic completed successfully but returned no output."
        self._last_technical_details = f"{name} completed.\n\nOutput:\n{stdout}"
        summary = _friendly_diagnostic_summary(name, stdout)
        return (
            f"{friendly_name} completed.\n\n"
            f"{summary}\n\n"
            "You can type details if you want the technical output."
        )

    def _render_remediation_result(self, result: Dict) -> str:
        if result.get("error"):
            self._pending_remediation = None
            self._pending_endpoint_action = None
            return f"Remediation failed: {result['error']}"

        action = result.get("action") or {}
        command_result = result.get("result") or {}
        name = action.get("name", "Remediation")
        friendly_name = _friendly_tool_name(name)
        if not command_result.get("ok", False):
            stderr = command_result.get("stderr") or "No remediation output was returned."
            self._last_technical_details = f"{name} failed.\n\nError:\n{stderr}"
            self._last_remediation = {
                "name": name,
                "ok": False,
                "stdout": command_result.get("stdout") or "",
                "stderr": stderr,
            }
            return f"{friendly_name} could not complete.\n\nWhat happened: {_shorten(stderr)}"

        stdout = command_result.get("stdout") or "The remediation completed successfully."
        self._last_technical_details = f"{name} completed.\n\nOutput:\n{stdout}"
        self._last_remediation = {
            "name": name,
            "ok": True,
            "stdout": stdout,
            "stderr": command_result.get("stderr") or "",
        }
        self._pending_remediation = None
        self._pending_endpoint_action = None
        return (
            f"{friendly_name} completed.\n\n"
            f"{_friendly_remediation_summary(name, stdout)}\n\n"
            "You can type details if you want the technical output."
        )

    def _diagnostic_from_text(self, text: str) -> Optional[Dict]:
        diagnostic_tools = self._last_resolution.get("diagnostic_tools") if self._last_resolution else []
        if not diagnostic_tools:
            return None

        lower_text = text.lower()
        for tool in diagnostic_tools:
            if str(tool.get("name", "")).lower() in lower_text:
                return tool

        text_tokens = _tokens(text)
        best_tool = None
        best_score = 0
        for tool in diagnostic_tools:
            searchable = f"{tool.get('name', '')} {tool.get('description', '')}"
            score = len(text_tokens.intersection(_tokens(searchable)))
            if score > best_score:
                best_tool = tool
                best_score = score

        return best_tool if best_score >= 2 else None

    def _valid_option_message(self) -> str:
        diagnostic_tools = self._last_resolution.get("diagnostic_tools") if self._last_resolution else []
        max_option = len(diagnostic_tools or [])
        if self._pending_remediation:
            max_option += 1
        if max_option:
            return f"Please choose one of the listed options, from 1 to {max_option}."
        return "There are no runnable options for the current issue."

    def _cleanup_details_follow_up(self, lower_text: str) -> Optional[str]:
        last_remediation = self._last_remediation or {}
        name = str(last_remediation.get("name") or "")
        if name not in {"Run-PerformanceCleanup", "Clear-TempFiles"}:
            return None
        if not _asks_about_cleanup_details(lower_text):
            return None

        stdout = str(last_remediation.get("stdout") or "").strip()
        if not stdout:
            return (
                "The cleanup already ran, but it did not return a file list. "
                "You can type details to see the technical result I received."
            )

        if _has_cleanup_report(stdout):
            return (
                "The cleanup already ran. Here is what it reported:\n\n"
                f"{_cleanup_report(stdout)}\n\n"
                "Some files can be locked by Windows or active apps, so they may remain after cleanup. "
                "You can type details if you want the full technical output."
            )

        return (
            "The cleanup already ran, but that run did not record individual file names. "
            "It only reported:\n\n"
            f"{_shorten(stdout)}\n\n"
            "You can type details to see the exact technical output I received."
        )

    def _action_metadata(self, action_name: str) -> Dict:
        if self._pending_remediation and self._pending_remediation.get("name") == action_name:
            return self._pending_remediation
        return get_tool(action_name) or {
            "name": action_name,
            "description": "Remediation action",
            "tier": "?",
            "requires_approval": True,
        }

    def _startup_action_metadata(self, app_name: str) -> Dict:
        cleaned = _clean_requested_app_name(app_name)
        return {
            "name": "Disable-StartupApp",
            "app": cleaned,
            "description": f"Disable '{cleaned}' from Windows startup without removing its Startup Apps entry where supported.",
            "tier": 2,
            "type": "action",
            "requires_approval": True,
        }

    def _endpoint_action_metadata(self, arguments: Dict) -> Dict:
        intent = str(arguments.get("intent") or "").strip()
        target = _clean_requested_app_name(str(arguments.get("target") or ""))
        plan = (arguments.get("parameters") or {}).get("plan") if isinstance(arguments.get("parameters"), dict) else None
        remediation = plan.get("remediation") if isinstance(plan, dict) else None
        if isinstance(remediation, dict) and remediation.get("name"):
            action = dict(remediation)
            action.setdefault("intent", intent)
            action.setdefault("target", target)
            return action
        return {
            "name": intent or "Endpoint action",
            "intent": intent,
            "target": target,
            "description": f"Execute endpoint action '{intent}'" + (f" for '{target}'." if target else "."),
            "tier": "?",
            "type": "action",
            "requires_approval": True,
        }

    def _oem_driver_action_metadata(self, include_utility: bool = False) -> Dict:
        if include_utility:
            return {
                "name": "Install-OEMDriverUtilityAndUpdates",
                "description": "Install the approved OEM update utility when missing, then install available driver updates through that utility.",
                "tier": 3,
                "type": "action",
                "requires_approval": True,
            }
        return {
            "name": "Install-OEMDriverUpdates",
            "description": "Install available driver updates only through a detected trusted OEM update utility.",
            "tier": 3,
            "type": "action",
            "requires_approval": True,
        }

    def reset_conversation(self) -> None:
        """Clear conversation history and start a fresh session."""
        self.session_id = _session_id()
        self._messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self._last_resolution = None
        self._last_diagnostic = None
        self._last_technical_details = None
        self._last_remediation = None
        self._last_oem_guidance = None
        self._last_oem_driver_install_blocked = False
        self._pending_remediation = None
        self._pending_endpoint_action = None

    def _write_audit(self, session_id: str, action: str, approved: bool, status: str) -> None:
        if not self.audit_logger:
            return
        try:
            self.audit_logger.write(session_id, action, approved, status)
        except OSError:
            return


def create_llm_client(settings: Settings):
    if not settings.openrouter_api_key:
        return None
    try:
        from openai import OpenAI
    except ImportError:
        return None
    return OpenAI(api_key=settings.openrouter_api_key, base_url=settings.openrouter_base_url)


def run_cli() -> None:
    settings = load_settings()
    console = Console()
    _display_header(console)
    settings = _choose_model(console, settings)
    os.environ["OPENROUTER_MODEL"] = settings.model
    llm_client = create_llm_client(settings)

    _display_runtime(console, settings, llm_client)

    servers = {"legacy": settings.mcp_server_command}
    servers.update(settings.additional_mcp_servers)

    client = MultiMCPClient(
        servers,
        timeout=settings.mcp_timeout_seconds,
        long_timeout=settings.mcp_long_timeout_seconds,
    )
    with console.status("[bold cyan]Starting MCP servers...[/bold cyan]", spinner="dots"):
        client.start()

    try:
        agent = EndpointSupportAgent(
            mcp_client=client,
            llm_client=llm_client,
            settings=settings,
            audit_logger=AuditLogger(settings),
        )

        def approval_provider(action: Dict) -> bool:
            description = str(action.get("description", "")).rstrip(" .?!")
            raw_name = str(action.get("name", "Unknown action"))
            action_name = escape(_friendly_tool_name(raw_name))
            technical_name = escape(raw_name)
            risk = escape(_risk_label(action.get("tier")))
            console.print(
                Panel(
                    (
                        f"[bold]{action_name}[/bold]\n"
                        f"Risk: {risk}\n"
                        f"[dim]Technical action: {technical_name}[/dim]\n\n"
                        f"{escape(description)}\n\n"
                        "This needs your approval before I make changes."
                    ),
                    title="Remediation Approval",
                    border_style="yellow",
                    box=box.ROUNDED,
                    padding=(1, 2),
                    width=_compact_panel_width(
                        f"{_friendly_tool_name(raw_name)}\n"
                        f"Risk: {_risk_label(action.get('tier'))}\n"
                        f"Technical action: {raw_name}\n\n"
                        f"{description}\n\n"
                        "This needs your approval before I make changes."
                    ),
                )
            )
            return Confirm.ask("[bold yellow]Approve[/bold yellow]", default=False)

        while True:
            try:
                issue = _read_chat_input(console)
                if issue.lower() in {"exit", "quit"}:
                    _display_system_message(console, "Session closed.")
                    break
                if issue.lower() in {"reset", "new"}:
                    agent.reset_conversation()
                    _display_system_message(console, "Conversation reset. What can I help you with?")
                    continue
                if issue.lower() in {"model", "models", "change model", "switch model", "/model", "/models"}:
                    if not settings.openrouter_api_key:
                        _display_system_message(console, "Set OPENROUTER_API_KEY to fetch and change models.")
                        continue
                    previous_model = settings.model
                    settings = _choose_model(console, settings)
                    os.environ["OPENROUTER_MODEL"] = settings.model
                    llm_client = create_llm_client(settings)
                    agent.settings = settings
                    agent.llm_client = llm_client
                    resolver_synced = _sync_resolver_model(client, settings.model)
                    if settings.model == previous_model:
                        _display_system_message(console, f"Active model remains {settings.model}.")
                    elif resolver_synced:
                        _display_system_message(console, f"Active model changed to {settings.model}.")
                    else:
                        _display_system_message(
                            console,
                            f"Active model changed to {settings.model}. Local resolver classifier could not be updated.",
                        )
                    continue
                if not issue:
                    continue
                _display_user_message(console, issue)
                response = agent.handle_issue(issue, approval_provider)
                _display_agent_message(console, response)
            except EOFError:
                break
    finally:
        client.close()


def _display_header(console: Console) -> None:
    console.clear()
    header = Align.center(
        f"[bold white]{APP_TITLE}[/bold white]\n"
        "[cyan]MCP Hybrid Helpdesk Console[/cyan]"
    )
    console.print(
        Panel(
            header,
            subtitle="[dim]Type exit to close | reset for new chat | model to switch LLM[/dim]",
            border_style="cyan",
            box=box.DOUBLE,
            padding=(1, 2),
        )
    )


def _display_runtime(console: Console, settings: Settings, llm_client) -> None:
    status_lines = ["[green]Multi-MCP router:[/green] enabled"]
    if settings.github_knowledge_file:
        status_lines.append(f"[green]GitHub knowledge export:[/green] {escape(settings.github_knowledge_file)}")
    if llm_client:
        status_lines.append(f"[green]Issue understanding model:[/green] {escape(settings.model)}")
    else:
        status_lines.append("[yellow]LLM client not configured. Multi-MCP routing requires an LLM.[/yellow]")

    console.print(
        Panel(
            "\n".join(status_lines),
            title="Runtime",
            border_style="blue",
            box=box.ROUNDED,
            padding=(0, 2),
        )
    )


def _sync_resolver_model(client: MultiMCPClient, model: str) -> bool:
    try:
        client.call_tool("legacy__set_model", {"model": model})
    except Exception:
        return False
    return True


def _choose_model(console: Console, settings: Settings) -> Settings:
    if not settings.openrouter_api_key:
        return settings

    with console.status("[bold cyan]Fetching available OpenRouter models...[/bold cyan]", spinner="dots"):
        models, error = _fetch_openrouter_models(settings)

    if not models:
        fallback_message = (
            "Could not fetch the live model list.\n\n"
            f"Reason: {escape(error or 'No models were returned.')}\n\n"
            f"Using default model: [bold]{escape(settings.model)}[/bold]"
        )
        console.print(
            Panel(
                fallback_message,
                title="Choose Model",
                border_style="yellow",
                box=box.ROUNDED,
                padding=(1, 2),
                width=_compact_panel_width(fallback_message),
            )
        )
        return settings

    selected_model = _browse_model_list(console, models, settings.model)
    return replace(settings, model=selected_model) if selected_model else settings


def _fetch_openrouter_models(settings: Settings) -> tuple:
    headers = {"Authorization": f"Bearer {settings.openrouter_api_key}"}
    params = {
        "output_modalities": "text",
        "supported_parameters": "tools",
        "sort": "most-popular",
    }

    try:
        response = requests.get(
            OPENROUTER_MODELS_URL,
            headers=headers,
            params=params,
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
    except requests.RequestException as exc:
        return [], str(exc)
    except ValueError as exc:
        return [], f"Invalid model list response: {exc}"

    raw_models = payload.get("data", [])
    if not isinstance(raw_models, list):
        return [], "Unexpected model list response."

    models = [_model_summary(model) for model in raw_models if isinstance(model, dict) and model.get("id")]
    return _group_models_by_pricing(models), ""


def _model_summary(model: Dict) -> Dict:
    pricing = model.get("pricing") if isinstance(model.get("pricing"), dict) else {}
    return {
        "id": str(model.get("id", "")),
        "name": str(model.get("name") or model.get("id", "")),
        "context_length": model.get("context_length"),
        "prompt_price": pricing.get("prompt"),
        "completion_price": pricing.get("completion"),
        "is_free": _is_free_pricing(pricing),
    }


def _group_models_by_pricing(models: List[Dict]) -> List[Dict]:
    openrouter_models = [model for model in models if _is_openrouter_model(model)]
    free_models = [model for model in models if not _is_openrouter_model(model) and model.get("is_free")]
    paid_models = [model for model in models if not _is_openrouter_model(model) and not model.get("is_free")]
    return openrouter_models + free_models + paid_models


def _is_free_pricing(pricing: Dict) -> bool:
    return _price_value(pricing.get("prompt")) == 0 and _price_value(pricing.get("completion")) == 0


def _browse_model_list(console: Console, models: List[Dict], default_model: str) -> Optional[str]:
    if _supports_arrow_model_picker():
        return _browse_model_list_with_arrows(console, models, default_model)
    return _browse_model_list_with_prompts(console, models, default_model)


def _browse_model_list_with_arrows(console: Console, models: List[Dict], default_model: str) -> Optional[str]:
    filtered_models = list(models)
    selected_index = _default_model_index(filtered_models, default_model)
    query = ""

    with Live(
        _model_picker_panel(filtered_models, selected_index, default_model, query),
        console=console,
        refresh_per_second=12,
        transient=False,
    ) as live:
        while True:
            key = _read_model_picker_key()
            if key == "up":
                selected_index = max(0, selected_index - 1)
            elif key == "down":
                selected_index = min(max(0, len(filtered_models) - 1), selected_index + 1)
            elif key == "page_up":
                selected_index = max(0, selected_index - MODEL_PAGE_SIZE)
            elif key == "page_down":
                selected_index = min(max(0, len(filtered_models) - 1), selected_index + MODEL_PAGE_SIZE)
            elif key == "home":
                selected_index = 0
            elif key == "end":
                selected_index = max(0, len(filtered_models) - 1)
            elif key == "enter":
                if filtered_models:
                    return filtered_models[selected_index]["id"]
                return default_model
            elif key in {"q", "cancel"}:
                return default_model
            elif key == "c":
                live.stop()
                custom_model = Prompt.ask("[bold cyan]Enter OpenRouter model ID[/bold cyan]").strip()
                console.print()
                return custom_model or default_model
            elif key == "/":
                live.stop()
                query = Prompt.ask("[bold cyan]Search models[/bold cyan]", default=query, show_default=False).strip().lower()
                filtered_models = _filter_models(models, query)
                selected_index = _default_model_index(filtered_models, default_model)
                live.start()
            elif key == "f":
                query = "free only"
                filtered_models = _filter_free_models(models)
                selected_index = _default_model_index(filtered_models, default_model)
            elif key == "d":
                query = "paid only"
                filtered_models = _filter_paid_models(models)
                selected_index = _default_model_index(filtered_models, default_model)
            elif key == "o":
                query = "OpenRouter only"
                filtered_models = _filter_openrouter_models(models)
                selected_index = _default_model_index(filtered_models, default_model)
            elif key in {"a", "clear"}:
                query = ""
                filtered_models = list(models)
                selected_index = _default_model_index(filtered_models, default_model)

            live.update(_model_picker_panel(filtered_models, selected_index, default_model, query))


def _browse_model_list_with_prompts(console: Console, models: List[Dict], default_model: str) -> Optional[str]:
    filtered_models = list(models)
    page = 0
    query = ""

    while True:
        total_pages = max(1, (len(filtered_models) + MODEL_PAGE_SIZE - 1) // MODEL_PAGE_SIZE)
        page = min(page, total_pages - 1)
        start = page * MODEL_PAGE_SIZE
        page_models = filtered_models[start:start + MODEL_PAGE_SIZE]

        _display_model_page(console, page_models, page, total_pages, len(filtered_models), default_model, query)
        selection = Prompt.ask("[bold cyan]Model choice[/bold cyan]", default="").strip()
        console.print()

        if not selection:
            return default_model

        lower_selection = selection.lower()
        if lower_selection in {"n", "next"}:
            if page < total_pages - 1:
                page += 1
            continue
        if lower_selection in {"p", "prev", "previous"}:
            if page > 0:
                page -= 1
            continue
        if lower_selection in {"c", "custom"}:
            custom_model = Prompt.ask("[bold cyan]Enter OpenRouter model ID[/bold cyan]").strip()
            console.print()
            return custom_model or default_model
        if lower_selection in {"q", "quit"}:
            return default_model
        if lower_selection.startswith("/"):
            query = lower_selection[1:].strip()
            filtered_models = _filter_models(models, query)
            page = 0
            continue
        if lower_selection in {"f", "free"}:
            query = "free only"
            filtered_models = _filter_free_models(models)
            page = 0
            continue
        if lower_selection in {"d", "paid"}:
            query = "paid only"
            filtered_models = _filter_paid_models(models)
            page = 0
            continue
        if lower_selection in {"o", "openrouter"}:
            query = "OpenRouter only"
            filtered_models = _filter_openrouter_models(models)
            page = 0
            continue
        if lower_selection in {"clear", "all"}:
            query = ""
            filtered_models = list(models)
            page = 0
            continue
        if selection.isdigit():
            selected_index = int(selection)
            if 1 <= selected_index <= len(page_models):
                return page_models[selected_index - 1]["id"]

        invalid_choice_message = (
            "Choose a listed number, use n/p for pages, o for OpenRouter, f for free, d for paid, "
            "/search to filter, c for custom, or Enter for the default."
        )
        console.print(
            Panel(
                invalid_choice_message,
                title="Invalid Choice",
                border_style="yellow",
                box=box.ROUNDED,
                padding=(0, 2),
                width=_compact_panel_width(invalid_choice_message),
            )
        )


def _supports_arrow_model_picker() -> bool:
    return os.name == "nt" and sys.stdin.isatty() and sys.stdout.isatty()


def _read_model_picker_key() -> str:
    import msvcrt

    key = msvcrt.getwch()
    if key in {"\x00", "\xe0"}:
        second = msvcrt.getwch()
        return {
            "H": "up",
            "P": "down",
            "I": "page_up",
            "Q": "page_down",
            "G": "home",
            "O": "end",
        }.get(second, "")
    if key in {"\r", "\n"}:
        return "enter"
    if key == "\x1b":
        return "cancel"
    if key == "\x03":
        raise KeyboardInterrupt
    return key.lower()


def _model_picker_panel(
    models: List[Dict],
    selected_index: int,
    default_model: str,
    query: str,
) -> Panel:
    total_pages = max(1, (len(models) + MODEL_PAGE_SIZE - 1) // MODEL_PAGE_SIZE)
    page = min(total_pages - 1, selected_index // MODEL_PAGE_SIZE if models else 0)
    start = page * MODEL_PAGE_SIZE
    page_models = models[start:start + MODEL_PAGE_SIZE]

    lines = []
    for offset, model in enumerate(page_models):
        model_index = start + offset
        context = _format_context(model.get("context_length"))
        pricing = _format_pricing(model)
        name = escape(model["name"])
        model_id = escape(model["id"])
        row = f"{name}  [dim]{model_id} | ctx {context} | {pricing}[/dim]"
        selected_row = f"[black on cyan]{name}  {model_id} | ctx {context} | {pricing}[/black on cyan]"
        heading = None
        if offset == 0 or _model_group_name(models[model_index - 1]) != _model_group_name(model):
            heading = _model_group_name(model)
        if heading:
            lines.append(f"[bold cyan]{heading}[/bold cyan]")
        if model_index == selected_index:
            lines.append(selected_row)
        else:
            lines.append(row)

    if not lines:
        lines.append("[yellow]No models matched your search. Press / to search again, a for all, or q to use the default.[/yellow]")

    footer = [
        "",
        f"[dim]{_model_pricing_counts(models)} | Page {page + 1}/{total_pages} | Up/Down move | Enter select | o OpenRouter | f free | d paid | / search | c custom | q default[/dim]",
    ]
    if query:
        footer.insert(0, f"[dim]Search: {escape(query)}[/dim]")

    return Panel(
        "\n".join(lines + footer),
        title="Choose Model",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(0, 1),
    )


def _default_model_index(models: List[Dict], default_model: str) -> int:
    for index, model in enumerate(models):
        if model.get("id") == default_model:
            return index
    return 0


def _display_model_page(
    console: Console,
    page_models: List[Dict],
    page: int,
    total_pages: int,
    total_models: int,
    default_model: str,
    query: str,
) -> None:
    lines = []
    for index, model in enumerate(page_models, start=1):
        context = _format_context(model.get("context_length"))
        pricing = _format_pricing(model)
        heading = None
        if index == 1 or _model_group_name(page_models[index - 2]) != _model_group_name(model):
            heading = _model_group_name(model)
        if heading:
            lines.append(f"[bold cyan]{heading}[/bold cyan]")
        lines.append(
            f"{index}. [bold]{escape(model['name'])}[/bold]  "
            f"[dim]{escape(model['id'])} | ctx {context} | {pricing}[/dim]"
        )

    if not lines:
        lines.append("[yellow]No models matched your search.[/yellow]")

    footer = [
        "",
        f"[dim]{_model_pricing_counts(page_models)} on page | {total_models} total | Page {page + 1}/{total_pages}[/dim]",
        f"[dim]Enter = {escape(default_model)} | n/p page | o OpenRouter | f free | d paid | /text search | clear all | c custom[/dim]",
    ]
    if query:
        footer.insert(0, f"[dim]Search: {escape(query)}[/dim]")

    console.print(
        Panel(
            "\n".join(lines + footer),
            title="Choose Model",
            border_style="cyan",
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )


def _filter_models(models: List[Dict], query: str) -> List[Dict]:
    if not query:
        return list(models)
    return [
        model for model in models
        if query in model["id"].lower() or query in model["name"].lower()
    ]


def _filter_free_models(models: List[Dict]) -> List[Dict]:
    return [model for model in models if not _is_openrouter_model(model) and model.get("is_free")]


def _filter_paid_models(models: List[Dict]) -> List[Dict]:
    return [model for model in models if not _is_openrouter_model(model) and not model.get("is_free")]


def _filter_openrouter_models(models: List[Dict]) -> List[Dict]:
    return [model for model in models if _is_openrouter_model(model)]


def _is_openrouter_model(model: Dict) -> bool:
    return str(model.get("id", "")).startswith("openrouter/")


def _model_group_name(model: Dict) -> str:
    if _is_openrouter_model(model):
        return "OpenRouter models"
    if model.get("is_free"):
        return "Free models"
    return "Paid models"


def _format_context(context_length) -> str:
    if not isinstance(context_length, int):
        return "?"
    if context_length >= 1000:
        return f"{context_length // 1000}k"
    return str(context_length)


def _format_pricing(model: Dict) -> str:
    if model.get("is_free"):
        return "free"

    prompt = _price_per_million(model.get("prompt_price"))
    completion = _price_per_million(model.get("completion_price"))
    if prompt is None and completion is None:
        return "price n/a"
    if prompt is None:
        return f"completion ${completion:g}/M"
    if completion is None:
        return f"prompt ${prompt:g}/M"
    return f"${prompt:g}/M in, ${completion:g}/M out"


def _price_per_million(value) -> Optional[float]:
    try:
        price = float(value)
    except (TypeError, ValueError):
        return None
    if price < 0:
        return None
    return price * 1_000_000


def _price_value(value) -> Optional[float]:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _model_pricing_counts(models: List[Dict]) -> str:
    openrouter_count = sum(1 for model in models if _is_openrouter_model(model))
    free_count = sum(1 for model in models if not _is_openrouter_model(model) and model.get("is_free"))
    paid_count = len(models) - openrouter_count - free_count
    return f"{openrouter_count} OpenRouter, {free_count} free, {paid_count} paid"


def _read_chat_input(console: Console) -> str:
    console.print()
    prompt_text = "Describe the problem in your own words, or type details for technical output."
    console.print(
        Panel(
            f"[dim]{prompt_text}[/dim]",
            title="Message",
            border_style="cyan",
            box=box.ROUNDED,
            padding=(0, 2),
            width=_compact_panel_width(prompt_text),
        )
    )
    message = console.input("[bold cyan]You[/bold cyan] > ").strip()
    console.print()
    return message


def _display_user_message(console: Console, message: str) -> None:
    console.print(
        Panel(
            escape(message),
            title="You",
            title_align="left",
            border_style="cyan",
            box=box.ROUNDED,
            padding=(1, 2),
            width=_compact_panel_width(message),
        )
    )


def _display_agent_message(console: Console, message: str) -> None:
    console.print(f"[bold green]{APP_TITLE}[/bold green]")
    console.print(escape(_strip_agent_prefix(message)))


def _display_system_message(console: Console, message: str) -> None:
    console.print(f"[bold magenta]System[/bold magenta] {escape(message)}")


def _compact_panel_width(text: str) -> int:
    visible_lines = [_strip_markup(line) for line in str(text).splitlines()] or [""]
    longest_line = max(len(line) for line in visible_lines)
    width = longest_line + 8
    return max(MIN_PANEL_WIDTH, min(MAX_COMPACT_PANEL_WIDTH, width))


def _strip_markup(text: str) -> str:
    return re.sub(r"\[[/?][^\]]*\]", "", text)


def _strip_agent_prefix(message: str) -> str:
    return re.sub(r"^Agent:\s*", "", message, count=1).strip()


def _is_affirmative(text: str) -> bool:
    return text.strip().lower() in {"y", "yes", "ok", "okay", "sure", "go ahead", "do it", "proceed"} or (
        text.strip().lower().startswith(("yes ", "ok ", "okay ", "sure "))
    )


def _is_endpoint_action_confirmation(text: str) -> bool:
    cleaned = text.strip().lower()
    return _is_affirmative(cleaned) or cleaned in {"install", "install it", "apply", "apply it", "run", "run it"}


def _is_oem_driver_install_request(text: str) -> bool:
    has_driver_context = bool(
        re.search(r"\b(driver|drivers|camera|webcam|dock|docking|display|monitor|usb|peripheral|device)\b", text)
    )
    has_install_intent = bool(re.search(r"\b(install|update|reinstall)\b", text))
    blocked_intent = bool(re.search(r"\b(rollback|roll back|downgrade)\b", text))
    return has_driver_context and has_install_intent and not blocked_intent


def _is_oem_driver_install_follow_up(text: str, last_oem_guidance: Optional[Dict]) -> bool:
    if text.strip().lower() not in {"install", "install it", "apply", "apply it"}:
        return False
    query = str((last_oem_guidance or {}).get("query") or "").lower()
    return bool(query and _is_oem_driver_install_request(query))


def _is_blocked_oem_driver_follow_up(text: str) -> bool:
    cleaned = text.strip().lower()
    if _is_endpoint_action_confirmation(cleaned):
        return True
    return bool(
        re.search(r"\b(web|browse|browser|search|download|install|driver|camera|oem|vendor|lenovo|dell|hp)\b", cleaned)
        or re.search(r"\b(you\s+do|from\s+your\s+side|do\s+from|do\s+it)\b", cleaned)
    )


def _supported_oem_driver_tools(profile: Dict) -> List[str]:
    vendor = str(profile.get("oem_vendor_id") or profile.get("oem_vendor") or "").lower()
    supported = []
    for tool in profile.get("installed_tools") or []:
        name = str(tool.get("name") or "")
        name_lower = name.lower()
        if vendor in {"dell", "dell inc."} and "dell command update" in name_lower:
            supported.append(name)
        elif vendor == "hp" and "hp image assistant" in name_lower:
            supported.append(name)
        elif vendor == "lenovo" and "lenovo system update" in name_lower:
            supported.append(name)
    return supported


def _oem_driver_context_summary(
    profile_result: Dict,
    supported_tools: List[str],
    utility_plan: Optional[Dict] = None,
) -> str:
    profile = profile_result.get("profile") or {}
    guidance = profile_result.get("guidance") or []
    lines = ["OEM driver install pre-check"]
    vendor = profile.get("oem_vendor") or "Unknown"
    manufacturer = profile.get("manufacturer") or "Unknown manufacturer"
    model = profile.get("model") or "Unknown model"
    lines.append(f"OEM: {vendor}")
    lines.append(f"Device: {manufacturer} {model}".strip())
    if profile.get("bios_version"):
        lines.append(f"BIOS: {profile.get('bios_version')}")
    if supported_tools:
        lines.append(f"Supported OEM driver tool detected: {supported_tools[0]}")
    else:
        installed = [str(tool.get("name")) for tool in profile.get("installed_tools") or [] if tool.get("name")]
        if installed:
            lines.append("OEM tools found, but none are supported for automatic driver install: " + ", ".join(installed[:5]))
        else:
            lines.append("Supported OEM driver tool detected: none")
        if utility_plan:
            method = utility_plan.get("install_method") or "OEM-supported package path"
            package = utility_plan.get("package_id")
            suffix = f" ({package})" if package else ""
            lines.append(f"OEM utility install available: {utility_plan.get('name', 'OEM utility')} via {method}{suffix}")
    if guidance:
        lines.extend(["", "Trusted update path:"])
        lines.extend(_oem_guidance_lines(guidance, limit=1))
    return "\n".join(lines)


def _mentions_step(text: str) -> bool:
    return bool(re.search(r"\b(step|diagnostic|option|first|second|third|fourth|fifth)\b", text))


def _option_number(text: str) -> Optional[int]:
    match = re.fullmatch(r"(?:option\s+|diagnostic\s+|run\s+diagnostic\s+)?(\d+)", text.strip())
    if not match:
        return None
    return int(match.group(1))


def _step_number(text: str) -> Optional[int]:
    match = re.search(r"\bstep\s+(\d+)\b", text)
    if match:
        return int(match.group(1))

    ordinals = {
        "first": 1,
        "second": 2,
        "third": 3,
        "fourth": 4,
        "fifth": 5,
    }
    for word, number in ordinals.items():
        if re.search(rf"\b{word}\b", text):
            return number
    return None


def _mentions_remediation(text: str, remediation: Dict) -> bool:
    action_name = str(remediation.get("name", "")).lower()
    description = str(remediation.get("description", "")).lower()
    if action_name and action_name in text:
        return True
    if "remediation" in text or "cleanup" in text or "fix" in text:
        return bool(set(_tokens(text)).intersection(_tokens(f"{action_name} {description}")))
    return False


def _is_skill_list_request(text: str) -> bool:
    return bool(
        re.search(r"\b(skill|skills|capabilities|smart|expertise)\b", text)
        and re.search(r"\b(list|show|what|which|have|available|support|do|handle)\b", text)
    )


def _is_oem_profile_request(text: str) -> bool:
    return bool(
        re.search(r"\b(oem|vendor|manufacturer|make|model|bios|firmware|driver source|trusted driver|device profile)\b", text)
        and re.search(r"\b(check|show|get|detect|what|which|find|identify|profile|guidance|source)\b", text)
    )


def _render_skill_catalog(skills: List[Dict]) -> str:
    if not skills:
        return "I do not have any endpoint skills loaded yet."

    lines = ["Endpoint skills I can use:"]
    for skill in skills:
        title = skill.get("title") or skill.get("id") or "Endpoint skill"
        description = _plain_description(skill.get("description"))
        lines.append(f"- {title}: {description}")
    lines.append("")
    lines.append("Tell me the issue in normal words and I will choose the right skill, checks, and safe fix path.")
    return "\n".join(lines)


def _skill_summary_lines(skills: List[Dict], limit: int = 2) -> List[str]:
    lines = []
    for skill in skills[: max(1, limit)]:
        title = skill.get("title") or skill.get("id") or "Endpoint skill"
        strategy = _plain_description(skill.get("diagnostic_strategy"))
        safety = _plain_description(skill.get("safety_note"))
        detail = strategy or _plain_description(skill.get("description"))
        if detail and safety:
            detail = f"{detail} Safety: {safety}"
        if detail:
            lines.append(f"- {title}: {detail}")
        else:
            lines.append(f"- {title}")
    return lines


def _oem_guidance_lines(guidance: List[Dict], limit: int = 2) -> List[str]:
    lines = []
    for item in guidance[: max(1, limit)]:
        vendor = item.get("vendor") or "OEM"
        tools = ", ".join(item.get("official_tools") or [])
        strategy = _plain_description(item.get("update_strategy"))
        safety = _plain_description(item.get("safety_note"))
        support_url = item.get("support_url") or item.get("enterprise_url") or ""
        line = f"- {vendor}"
        if tools:
            line += f" via {tools}"
        if strategy:
            line += f": {strategy}"
        if safety:
            line += f" Safety: {safety}"
        if support_url:
            line += f" Source: {support_url}"
        lines.append(line)
    return lines


FRIENDLY_TOOL_NAMES = {
    "Get-HealthReport": "Check what is using the processor",
    "Get-MemoryUsage": "Check memory usage",
    "Get-StartupPrograms": "List startup apps",
    "Get-SystemInfo": "Check Windows version",
    "Get-DiskUsage": "Check disk space",
    "Get-TempFolderSize": "Check temporary files",
    "Get-NetworkConfig": "Check network settings",
    "Test-Internet": "Test internet connection",
    "Check-DNSResolution": "Check website name lookup",
    "Test-PortConnection": "Check secure web connection",
    "Get-PrinterStatus": "Check printers",
    "Get-PrintQueue": "Check print queue",
    "Get-OutlookStatus": "Check Outlook",
    "Get-TeamsStatus": "Check Teams",
    "Get-OneDriveStatus": "Check OneDrive sync",
    "Get-BrowserStatus": "Check browsers",
    "Get-AudioDeviceStatus": "Check sound and microphone",
    "Get-CameraDeviceStatus": "Check camera",
    "Get-BluetoothStatus": "Check Bluetooth",
    "Get-OEMDeviceProfile": "Check device manufacturer and OEM tools",
    "Get-DriverProblemDevices": "Check driver problem devices",
    "Get-WindowsUpdateStatus": "Check Windows Update",
    "Get-DefenderStatus": "Check security protection",
    "Run-PerformanceCleanup": "Clean temporary files",
    "Clear-TempFiles": "Clear temporary files",
    "Flush-DNS": "Refresh website lookup cache",
    "Restart-NetAdapter": "Restart network adapter",
    "Renew-DHCPLease": "Renew network address",
    "Reset-OutlookClientState": "Reset Outlook app state",
    "Clear-TeamsCache": "Clear Teams cache",
    "Restart-PrintSpooler": "Restart printing service",
    "Clear-BrowserCache": "Clear browser cache",
    "Reset-OneDriveSync": "Reset OneDrive sync",
    "Clear-OfficeDocumentCache": "Clear Office document cache",
    "Restart-AudioServices": "Restart sound services",
    "Restart-CameraFrameServer": "Restart camera service",
    "Restart-BluetoothService": "Restart Bluetooth service",
    "Restart-WindowsUpdateServices": "Restart Windows Update services",
    "Reset-WindowsUpdateCache": "Reset Windows Update cache",
    "Update-DefenderSignatures": "Update security definitions",
    "Sync-IntuneDevice": "Sync work device management",
    "Restart-SCCMClient": "Restart Software Center client",
    "Refresh-GroupPolicy": "Refresh company policies",
    "Restart-ExplorerShell": "Restart desktop and taskbar",
    "Restart-WindowsSearchService": "Restart Windows Search",
    "Disable-StartupApp": "Disable startup app",
    "Repair-SystemFiles": "Repair Windows system files",
    "Rescan-PnPDevices": "Rescan connected devices",
    "Set-BalancedPowerPlan": "Set balanced power mode",
    "Clear-UserShellCache": "Clear desktop icon cache",
    "Restart-WorkstationService": "Restart file sharing service",
    "Restart-OfflineFilesService": "Restart offline files service",
    "Restart-RemoteSupportTools": "Restart remote support tools",
    "Restart-CitrixWorkspace": "Restart Citrix Workspace",
    "Scan-OEMDriverUpdates": "Scan OEM driver updates",
    "Install-OEMDriverUpdates": "Install OEM driver updates",
    "Install-OEMDriverUtilityAndUpdates": "Install OEM driver utility and driver updates",
}


def _friendly_tool_name(name) -> str:
    raw = str(name or "")
    return FRIENDLY_TOOL_NAMES.get(raw, raw.replace("-", " "))


def _plain_description(description) -> str:
    text = str(description or "").strip()
    replacements = {
        "remediation": "fix",
        "diagnostic": "check",
        "Kerberos tickets": "sign-in tickets",
        "endpoint": "device",
        "PnP": "device detection",
        "CIM": "system",
    }
    for old, new in replacements.items():
        text = re.sub(re.escape(old), new, text, flags=re.IGNORECASE)
    return text


def _plain_step(step) -> str:
    return _plain_description(step)


def _friendly_plan_status(status: str) -> str:
    return {
        "ready": "I can do this with your approval",
        "unsupported": "I can diagnose this, but cannot safely fix it automatically",
        "needs_target": "I need one more detail",
        "unknown": "I am not sure yet",
    }.get(status, status)


def _risk_label(tier) -> str:
    try:
        tier_number = int(tier)
    except (TypeError, ValueError):
        return "Needs review"
    if tier_number <= 1:
        return "Very low risk"
    if tier_number == 2:
        return "Low risk"
    return "Higher impact"


def _friendly_diagnostic_summary(name, stdout: str) -> str:
    tool_name = str(name or "")
    text = str(stdout or "").strip()
    if not text:
        return "The check finished, but there was nothing important to report."

    if tool_name == "Get-StartupPrograms":
        return _startup_summary(text)
    if tool_name == "Get-HealthReport":
        return _process_summary(text)
    if tool_name == "Get-DiskUsage":
        return _disk_summary(text)
    if tool_name == "Get-MemoryUsage":
        return _memory_summary(text)
    if tool_name.endswith("Status") or "Service" in tool_name:
        return _status_summary(text)
    return f"I collected the information successfully. Summary: {_shorten(text)}"


def _friendly_remediation_summary(name, stdout: str) -> str:
    text = str(stdout or "").strip()
    tool_name = str(name or "")
    if tool_name == "Disable-StartupApp":
        return _shorten(text) if text else "The startup app setting was updated."
    if tool_name in {"Run-PerformanceCleanup", "Clear-TempFiles"}:
        if _has_cleanup_report(text):
            return _cleanup_summary(text)
        return "Temporary files were cleared. This can help free space and reduce slowdowns."
    if tool_name.startswith("Restart-"):
        return "The related Windows service or app component was restarted."
    if tool_name.startswith("Clear-") or tool_name.startswith("Reset-"):
        return "The local app cache/state was refreshed. Reopen the app and try again."
    if tool_name.startswith("Sync-"):
        return "A sync was requested. It may take a few minutes to show in company systems."
    if tool_name == "Install-OEMDriverUpdates":
        return "OEM-approved driver updates were requested through the detected OEM update utility. A restart may still be required if the OEM tool reports it."
    if tool_name == "Install-OEMDriverUtilityAndUpdates":
        return "The OEM driver utility was installed or verified first, then OEM-approved driver updates were requested through it. A restart may still be required."
    return _shorten(text) if text else "The requested fix completed successfully."


def _startup_summary(text: str) -> str:
    names = _startup_names(text)
    if not names:
        return "I checked startup apps, but I could not identify individual app names from the output."
    shown = ", ".join(names[:8])
    more = f" and {len(names) - 8} more" if len(names) > 8 else ""
    return (
        f"I found {len(names)} startup item{'s' if len(names) != 1 else ''}: {shown}{more}. "
        "Tell me the name of any item you want to disable."
    )


def _startup_names(text: str) -> List[str]:
    names = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("Name") or line.startswith("----"):
            continue
        match = re.match(r"^([A-Za-z0-9][A-Za-z0-9_. @()+-]*?)(?:\s{2,}|\s+[A-Za-z]:\\|\s+%|\t|$)", line)
        if match:
            name = match.group(1).strip()
            if name and name not in names:
                names.append(name)
    return names


def _process_summary(text: str) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith("---") and not line.startswith("Name")]
    names = []
    for line in lines:
        label_match = re.search(r"\b(?:top\s+cpu|process|name)\s*:\s*([A-Za-z0-9_.-]+)", line, flags=re.IGNORECASE)
        if label_match:
            candidate = label_match.group(1)
            if candidate not in names:
                names.append(candidate)
            continue
        match = re.match(r"^([A-Za-z0-9_.-]+)", line)
        if match:
            candidate = match.group(1)
            if candidate not in {"CPU", "Top"} and candidate not in names:
                names.append(candidate)
    if names:
        return f"The top processor users appear to include: {', '.join(names[:5])}."
    return f"I checked processor usage. Summary: {_shorten(text)}"


def _disk_summary(text: str) -> str:
    drive_matches = re.findall(r"(?m)^([A-Z])\s+(\d+)\s+(\d+)", text)
    if drive_matches:
        parts = []
        for name, free, used in drive_matches[:4]:
            try:
                free_gb = int(free) / (1024 ** 3)
                used_gb = int(used) / (1024 ** 3)
                parts.append(f"{name}: {free_gb:.1f} GB free, {used_gb:.1f} GB used")
            except ValueError:
                continue
        if parts:
            return "Disk space checked: " + "; ".join(parts) + "."
    return f"I checked disk space. Summary: {_shorten(text)}"


def _memory_summary(text: str) -> str:
    numbers = re.findall(r"(\d+(?:\.\d+)?)", text)
    if len(numbers) >= 2:
        return f"Memory checked. Total memory is about {numbers[0]} GB and free memory is about {numbers[1]} GB."
    return f"I checked memory usage. Summary: {_shorten(text)}"


def _status_summary(text: str) -> str:
    stopped = re.findall(r"\bStopped\b", text, flags=re.IGNORECASE)
    running = re.findall(r"\bRunning\b", text, flags=re.IGNORECASE)
    if stopped or running:
        return f"I found {len(running)} running item(s) and {len(stopped)} stopped item(s)."
    return f"I checked the status. Summary: {_shorten(text)}"


def _asks_about_cleanup_details(text: str) -> bool:
    has_detail_word = bool(re.search(r"\b(which|what|list|show|files?|folders?|items?|cleared|removed|deleted|cleaned)\b", text))
    has_cleanup_word = bool(
        re.search(r"\b(file|files|folder|folders|item|items|clear|cleared|remove|removed|delete|deleted|cleanup|cleaned|temp|temporary)\b", text)
    )
    return has_detail_word and has_cleanup_word


def _has_cleanup_report(text: str) -> bool:
    return "Cleanup path:" in str(text or "") and "Top-level temporary items found:" in str(text or "")


def _cleanup_summary(text: str) -> str:
    path = _cleanup_report_value(text, "Cleanup path")
    found = _cleanup_report_value(text, "Top-level temporary items found")
    remaining = _cleanup_report_value(text, "Top-level temporary items remaining after cleanup")

    parts = []
    if path:
        parts.append(f"I cleaned the temporary folder: {path}.")
    if found:
        parts.append(f"It found {found} top-level temporary item(s).")
    if remaining:
        parts.append(f"{remaining} top-level item(s) were still present afterward, usually because Windows or an app was using them.")
    if parts:
        return " ".join(parts)
    return "Temporary files were checked and cleanup was attempted."


def _cleanup_report(text: str) -> str:
    report_lines = []
    path = _cleanup_report_value(text, "Cleanup path")
    found = _cleanup_report_value(text, "Top-level temporary items found")
    remaining = _cleanup_report_value(text, "Top-level temporary items remaining after cleanup")
    sample = _cleanup_report_sample(text)

    if path:
        report_lines.append(f"Temporary folder: {path}")
    if found:
        report_lines.append(f"Items found before cleanup: {found}")
    if remaining:
        report_lines.append(f"Items still present after cleanup: {remaining}")
    if sample:
        report_lines.append("")
        report_lines.append("Sample of targeted items:")
        report_lines.extend(f"- {item}" for item in sample[:20])

    return "\n".join(report_lines) if report_lines else _shorten(text, limit=800)


def _cleanup_report_value(text: str, label: str) -> str:
    match = re.search(rf"(?im)^{re.escape(label)}:\s*(.+)$", str(text or ""))
    return match.group(1).strip() if match else ""


def _cleanup_report_sample(text: str) -> List[str]:
    sample = []
    in_sample = False
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip()
        if line.lower() == "sample of items targeted:":
            in_sample = True
            continue
        if in_sample:
            if not line.startswith("- "):
                break
            item = line[2:].strip()
            if item:
                sample.append(item)
    return sample


def _shorten(text: str, limit: int = 320) -> str:
    compact = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3].rstrip() + "..."


def _is_startup_list_request(text: str) -> bool:
    if text.strip() in {"startup", "startup items", "start-up items", "startup programs", "startup apps"}:
        return True
    return bool(
        re.search(r"\b(list|show|display|view|check|get)\b", text)
        and re.search(r"\b(startup|start-up|autostart|login|logon)\b", text)
        and not re.search(r"\b(disable|remove|turn\s+off|stop|prevent)\b", text)
    )


def _is_generic_startup_disable_request(text: str) -> bool:
    if not re.search(r"\b(disable|remove|turn\s+off|stop|prevent)\b", text):
        return False
    if not re.search(r"\b(startup|start-up|autostart|login|logon|boot)\b", text):
        return False
    target = _startup_app_name_from_disable_request(text, None)
    return not target


def _startup_app_name_from_disable_request(text: str, last_diagnostic: Optional[Dict]) -> Optional[str]:
    lower_text = text.lower()
    wants_disable = bool(re.search(r"\b(disable|remove|turn\s+off|stop|prevent)\b", lower_text))
    if not wants_disable:
        return None

    has_startup_context = bool(
        re.search(r"\b(startup|start-up|auto\s*start|autostart|boot|login|logon|launch)\b", lower_text)
    )
    last_diagnostic_name = str((last_diagnostic or {}).get("name", "")).lower()
    if last_diagnostic_name == "get-startupprograms":
        has_startup_context = True

    if not has_startup_context:
        return None

    patterns = [
        r"\b(?:disable|remove|turn\s+off|stop|prevent)\s+(.+?)\s+(?:from|at|during|on)\s+(?:startup|start-up|boot|login|logon|launch)\b",
        r"\b(?:disable|remove|turn\s+off|stop|prevent)\s+(.+?)\s*$",
        r"\bstartup\s+(?:for|entry\s+for)\s+(.+?)\s*$",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            app_name = _clean_requested_app_name(match.group(1))
            if app_name and app_name.lower() not in {"it", "this", "that", "startup"}:
                return app_name

    return None


def _startup_app_selection(text: str, last_diagnostic: Optional[Dict]) -> Optional[str]:
    last_diagnostic_name = str((last_diagnostic or {}).get("name", "")).lower()
    if last_diagnostic_name != "get-startupprograms":
        return None

    cleaned = _clean_requested_app_name(text)
    if not cleaned:
        return None
    if len(cleaned.split()) > 4:
        return None
    if _is_affirmative(cleaned.lower()) or _option_number(cleaned.lower()) is not None:
        return None
    if re.search(r"\b(how|what|why|when|where|list|show|display|check|disable|remove)\b", cleaned, re.IGNORECASE):
        return None
    return cleaned


def _clean_requested_app_name(app_name: str) -> str:
    cleaned = re.sub(r"\s+", " ", str(app_name or "")).strip(" .\"'")
    cleaned = re.sub(
        r"\b(app|application|program|process|startup|start-up|entry|entries|item|items)\b",
        " ",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .\"'")
    if len(cleaned) > 80:
        cleaned = cleaned[:80].strip()
    if re.search(r"[\r\n;&|`$<>]", cleaned):
        return ""
    if cleaned.lower() in {"my", "mine", "all", "everything", "these", "those"}:
        return ""
    return cleaned


def _safe_llm_content(content) -> str:
    text = str(content or "").strip()
    if text and text.strip("*").strip():
        return text
    return "I could not produce a useful response for that request. Please rephrase it or choose one of the listed options."


def _tokens(text: str) -> set:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def _session_id() -> str:
    return f"ESA-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:4].upper()}"


if __name__ == "__main__":
    run_cli()
