import re
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional

from tools.diagnose import get_tool


READONLY_TOOLS = {
    "resolve_issue",
    "execute_diagnostic",
    "search_endpoint_capabilities",
    "search_endpoint_skills",
    "list_endpoint_skills",
    "get_oem_device_profile",
    "search_oem_guidance",
    "scan_oem_driver_updates",
    "plan_endpoint_action",
    "verify_endpoint_action",
    "get_endpoint_telemetry_summary",
    "assess_endpoint_guardrails",
    "set_model",
}
OEM_DRIVER_INTENTS = {"driver.oem_update", "driver.oem_bootstrap_update"}
BLOCKED_TERMS = (
    "format",
    "wipe",
    "factory reset",
    "delete user",
    "remove user",
    "disable defender",
    "turn off defender",
    "remove bitlocker",
    "disable bitlocker",
    "reg delete",
    "bcdedit",
    "cipher /w",
)
GENERIC_TARGETS = {
    "",
    "my",
    "mine",
    "all",
    "everything",
    "these",
    "those",
    "startup",
    "startup items",
    "unnecessary",
    "unneeded",
    "unused",
    "unnecessary apps",
    "unneeded apps",
    "unused apps",
}


@dataclass(frozen=True)
class GuardrailDecision:
    allowed: bool
    severity: str
    reason: str
    requires_approval: bool = False
    verification_required: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def assess_tool_call(tool_name: str, arguments: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Assess whether an MCP tool call is allowed by endpoint safety rules."""

    arguments = arguments or {}
    local_name = _local_tool_name(tool_name)
    if local_name in READONLY_TOOLS:
        return GuardrailDecision(
            allowed=True,
            severity="read-only",
            reason="Read-only planning or diagnostic tool.",
        ).to_dict()

    if local_name == "execute_remediation":
        return assess_endpoint_action(
            arguments.get("action"),
            approved=bool(arguments.get("approved")),
            intent=str(arguments.get("intent") or ""),
        )

    if local_name == "disable_startup_app":
        return assess_endpoint_action(
            "Disable-StartupApp",
            approved=bool(arguments.get("approved")),
            target=str(arguments.get("app") or arguments.get("target") or ""),
        )

    if local_name == "execute_parameterized_remediation":
        return assess_endpoint_action(
            str(arguments.get("action") or arguments.get("intent") or ""),
            approved=bool(arguments.get("approved")),
            intent=str(arguments.get("intent") or ""),
            target=str(arguments.get("target") or ""),
        )

    if local_name == "install_oem_driver_updates":
        return assess_endpoint_action(
            "Install-OEMDriverUpdates",
            approved=bool(arguments.get("approved")),
            intent="driver.oem_update",
        )

    if local_name == "install_oem_driver_utility_and_updates":
        return assess_endpoint_action(
            "Install-OEMDriverUtilityAndUpdates",
            approved=bool(arguments.get("approved")),
            intent="driver.oem_bootstrap_update",
        )

    return GuardrailDecision(
        allowed=False,
        severity="blocked",
        reason=f"Unknown or unclassified tool call: {local_name}",
        requires_approval=True,
    ).to_dict()


def assess_endpoint_action(
    action: Any,
    *,
    approved: bool = False,
    intent: str = "",
    target: str = "",
) -> Dict[str, Any]:
    """Assess a proposed endpoint-changing action before execution."""

    action_name = _action_name(action)
    intent = str(intent or _action_intent(action) or "")
    target = str(target or _action_target(action) or "").strip()
    searchable = f"{action_name} {intent} {target}".lower()

    if not action_name and not intent:
        return GuardrailDecision(False, "blocked", "No endpoint action was specified.", True).to_dict()

    if any(term in searchable for term in BLOCKED_TERMS):
        return GuardrailDecision(
            False,
            "blocked",
            "This request is outside the autonomous remediation safety boundary.",
            True,
        ).to_dict()

    if _looks_readonly(action_name):
        return GuardrailDecision(True, "read-only", "Read-only diagnostic action.").to_dict()

    if "startup" in searchable and _is_generic_target(target):
        return GuardrailDecision(
            False,
            "blocked",
            "Startup remediation needs the exact app or entry name.",
            True,
        ).to_dict()

    if ("driver" in searchable or "firmware" in searchable or "bios" in searchable) and intent not in OEM_DRIVER_INTENTS:
        return GuardrailDecision(
            False,
            "blocked",
            "Driver, BIOS, and firmware changes must use a trusted OEM or managed deployment workflow.",
            True,
            True,
        ).to_dict()

    tool = get_tool(action_name)
    requires_approval = bool(tool.get("requires_approval")) if tool else True
    tier = int(tool.get("tier", 3)) if tool and str(tool.get("tier", "")).isdigit() else 3
    if requires_approval and not approved:
        return GuardrailDecision(
            False,
            "approval-required",
            f"{action_name or intent} requires explicit user approval.",
            True,
            tier >= 3,
        ).to_dict()

    severity = "higher-impact" if tier >= 3 or intent in OEM_DRIVER_INTENTS else "standard"
    return GuardrailDecision(
        True,
        severity,
        "Action is within the approved endpoint remediation boundary.",
        requires_approval,
        tier >= 3 or intent in OEM_DRIVER_INTENTS,
    ).to_dict()


def _local_tool_name(tool_name: str) -> str:
    return str(tool_name or "").split("__")[-1]


def _action_name(action: Any) -> str:
    if isinstance(action, dict):
        return str(action.get("name") or action.get("action") or "").strip()
    return str(action or "").strip()


def _action_intent(action: Any) -> str:
    if isinstance(action, dict):
        return str(action.get("intent") or "")
    return ""


def _action_target(action: Any) -> str:
    if isinstance(action, dict):
        return str(action.get("target") or action.get("app") or "")
    return ""


def _looks_readonly(name: str) -> bool:
    return bool(re.match(r"^(Get|Test|Check)-", str(name or ""), flags=re.IGNORECASE))


def _is_generic_target(target: str) -> bool:
    cleaned = re.sub(r"\s+", " ", str(target or "").strip().lower())
    return cleaned in GENERIC_TARGETS
