import json
import queue
import subprocess
import threading
from itertools import count
from pathlib import Path
from typing import Dict, Iterable, Optional

from config import BASE_DIR, load_settings


class MCPClientError(RuntimeError):
    pass


class MCPClient:
    """Small stdio JSON-RPC client for the local MCP runtime server."""

    def __init__(
        self,
        command: Optional[Iterable[str]] = None,
        timeout: Optional[float] = None,
        long_timeout: Optional[float] = None,
        cwd: Optional[Path] = None,
    ):
        settings = load_settings()
        self.command = list(command or settings.mcp_server_command)
        self.timeout = timeout if timeout is not None else settings.mcp_timeout_seconds
        configured_long_timeout = long_timeout if long_timeout is not None else settings.mcp_long_timeout_seconds
        self.long_timeout = max(self.timeout, configured_long_timeout)
        self.cwd = Path(cwd or BASE_DIR)
        self._process: Optional[subprocess.Popen] = None
        self._responses: "queue.Queue[str]" = queue.Queue()
        self._ids = count(1)
        self._stdout_thread: Optional[threading.Thread] = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()

    def start(self) -> None:
        if self._process:
            return

        self._process = subprocess.Popen(
            self.command,
            cwd=str(self.cwd),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        self._stdout_thread = threading.Thread(target=self._read_stdout, daemon=True)
        self._stdout_thread.start()
        
        self._request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "endpoint-support-agent",
                "version": "1.0.0"
            }
        })
        self._notify("notifications/initialized", {})

    def _notify(self, method: str, params: Dict) -> None:
        if not self._process or not self._process.stdin:
            raise MCPClientError("MCP server is not running")
        request = {"jsonrpc": "2.0", "method": method, "params": params}
        self._process.stdin.write(json.dumps(request) + "\n")
        self._process.stdin.flush()

    def close(self) -> None:
        if not self._process:
            return

        process = self._process
        if process.stdin and not process.stdin.closed:
            process.stdin.close()

        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=3)

        for stream in (process.stdout, process.stderr):
            if stream and not stream.closed:
                stream.close()

        if self._stdout_thread and self._stdout_thread.is_alive():
            self._stdout_thread.join(timeout=1)
        self._process = None
        self._stdout_thread = None

    def call_tool(self, name: str, arguments: Optional[Dict] = None) -> Dict:
        return self._request(
            "tools/call",
            {"name": name, "arguments": arguments or {}},
            timeout=_tool_timeout_seconds(name, arguments or {}, self.timeout, self.long_timeout),
        )

    def resolve_issue(self, issue: str, context: Optional[Dict] = None) -> Dict:
        return self.call_tool("resolve_issue", {"issue": issue, "context": context or {}})

    def execute_remediation(self, action: str, approved: bool) -> Dict:
        return self.call_tool(
            "execute_remediation",
            {"action": action, "approved": bool(approved)},
        )

    def execute_diagnostic(self, tool: str) -> Dict:
        return self.call_tool("execute_diagnostic", {"tool": tool})

    def _read_stdout(self) -> None:
        assert self._process and self._process.stdout
        for line in self._process.stdout:
            line = line.strip()
            if not line:
                continue
            # Some MCP servers print non-JSON logs to stdout. Skip them.
            if not line.startswith("{"):
                continue
            self._responses.put(line)

    def _request(self, method: str, params: Dict, timeout: Optional[float] = None) -> Dict:
        if not self._process or not self._process.stdin:
            raise MCPClientError("MCP server is not running")

        request_id = next(self._ids)
        request = {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}
        self._process.stdin.write(json.dumps(request) + "\n")
        self._process.stdin.flush()

        # Drain responses until we find the one matching our request_id.
        # This handles out-of-order notifications or stale responses safely.
        deadline = timeout if timeout is not None else self.timeout
        while True:
            try:
                raw_response = self._responses.get(timeout=deadline)
            except queue.Empty as exc:
                raise MCPClientError(f"Timed out waiting for MCP response to {method}") from exc

            try:
                response = json.loads(raw_response)
            except json.JSONDecodeError as exc:
                raise MCPClientError(f"Invalid MCP response: {raw_response!r}") from exc

            # Skip responses that don't match our request (e.g. late notifications)
            if response.get("id") != request_id:
                continue

            if "error" in response:
                message = response["error"].get("message", "Unknown MCP server error")
                raise MCPClientError(message)
            return response.get("result", {})


class MultiMCPClient:
    """Aggregates multiple MCP clients and namespaces their tools."""

    def __init__(
        self,
        servers: Dict[str, Iterable[str]],
        timeout: Optional[float] = None,
        long_timeout: Optional[float] = None,
    ):
        self.clients: Dict[str, MCPClient] = {}
        for name, command in servers.items():
            self.clients[name] = MCPClient(command=command, timeout=timeout, long_timeout=long_timeout)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()

    def start(self) -> None:
        for client in self.clients.values():
            client.start()

    def close(self) -> None:
        for client in self.clients.values():
            client.close()

    def list_tools(self) -> list:
        tools = []
        for server_name, client in self.clients.items():
            try:
                result = client._request("tools/list", {})
                server_tools = result.get("tools", [])
                for tool in server_tools:
                    tool_copy = dict(tool)
                    tool_copy["name"] = f"{server_name}__{tool['name']}"
                    tools.append(tool_copy)
            except MCPClientError:
                continue
        return tools

    def call_tool(self, name: str, arguments: Optional[Dict] = None) -> Dict:
        if "__" not in name:
            raise ValueError(f"Invalid tool name format: {name}")
        server_name, tool_name = name.split("__", 1)
        if server_name not in self.clients:
            raise ValueError(f"Unknown server: {server_name}")
        return self.clients[server_name].call_tool(tool_name, arguments)


def _tool_timeout_seconds(name: str, arguments: Dict, default_timeout: float, long_timeout: float) -> float:
    tool_name = str(name or "")
    args = arguments or {}

    if tool_name in {"install_oem_driver_updates", "install_oem_driver_utility_and_updates", "scan_oem_driver_updates"}:
        return long_timeout

    if tool_name == "execute_parameterized_remediation":
        intent = str(args.get("intent") or "")
        if intent in {"driver.oem_update", "driver.oem_bootstrap_update"}:
            return long_timeout

    if tool_name == "execute_remediation":
        action = str(args.get("action") or "")
        if action in {"Repair-SystemFiles", "Reset-WindowsUpdateCache"}:
            return long_timeout

    return default_timeout
