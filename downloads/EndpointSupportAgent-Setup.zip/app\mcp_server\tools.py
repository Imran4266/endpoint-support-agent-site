from typing import Dict, Optional

from config import Settings, load_settings
from mcp_server.issue_database import ISSUE_DATABASE
from mcp_server.knowledge_base import (
    GitHubKnowledgeFileProvider,
    GitHubMCPKnowledgeProvider,
    KnowledgeBase,
)
from tools.diagnose import disable_startup_app, execute_diagnostic_tool, execute_tool
from tools.endpoint_actions import (
    execute_parameterized_remediation,
    plan_endpoint_action,
    search_endpoint_capabilities,
    verify_endpoint_action,
)
from tools.endpoint_skills import list_endpoint_skills, search_endpoint_skills
from tools.guardrails import assess_endpoint_action, assess_tool_call
from tools.oem_support import (
    get_oem_device_profile,
    install_oem_driver_updates,
    install_oem_driver_utility_and_updates,
    scan_oem_driver_updates,
    search_oem_guidance,
)
from tools.telemetry import summarize_telemetry


def build_knowledge_base(settings: Optional[Settings] = None) -> KnowledgeBase:
    settings = settings or load_settings()
    providers = []
    if settings.github_knowledge_file:
        providers.append(GitHubKnowledgeFileProvider(settings.github_knowledge_file))
    if settings.github_mcp_command:
        providers.append(
            GitHubMCPKnowledgeProvider(
                command=settings.github_mcp_command,
                tool_name=settings.github_mcp_tool,
                repository=settings.github_repository,
                timeout=settings.mcp_timeout_seconds,
            )
        )
        
    llm_client = None
    if settings.openrouter_api_key and settings.resolver_llm_classifier_enabled:
        try:
            from openai import OpenAI
            llm_client = OpenAI(
                api_key=settings.openrouter_api_key,
                base_url=settings.openrouter_base_url
            )
        except ImportError:
            pass

    return KnowledgeBase(
        ISSUE_DATABASE,
        external_providers=providers,
        llm_client=llm_client,
        model=settings.model
    )


class MCPToolRegistry:
    def __init__(
        self,
        knowledge_base: Optional[KnowledgeBase] = None,
        command_executor=None,
    ):
        self.knowledge_base = knowledge_base or build_knowledge_base()
        self.command_executor = command_executor

    def list_tools(self) -> list:
        return [
            {
                "name": "resolve_issue",
                "description": "Return endpoint troubleshooting steps for a user issue and context.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "issue": {"type": "string"},
                        "context": {"type": "object"},
                    },
                    "required": ["issue"],
                },
            },
            {
                "name": "execute_remediation",
                "description": "Execute an approved endpoint remediation action.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "description": "The EXACT name of the recommended action returned by resolve_issue (e.g., 'Run-PerformanceCleanup'). Do not make up actions."
                        },
                        "approved": {"type": "boolean"},
                    },
                    "required": ["action", "approved"],
                },
            },
            {
                "name": "execute_diagnostic",
                "description": "Execute a read-only endpoint diagnostic tool.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "tool": {
                            "type": "string",
                            "description": "The EXACT diagnostic tool name returned by resolve_issue (e.g., 'Get-HealthReport').",
                        },
                    },
                    "required": ["tool"],
                },
            },
            {
                "name": "disable_startup_app",
                "description": "Disable an approved Windows startup application entry by app/display name.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "app": {
                            "type": "string",
                            "description": "The app/display name to disable from Windows startup, e.g. 'AnyDesk'.",
                        },
                        "approved": {"type": "boolean"},
                    },
                    "required": ["app", "approved"],
                },
            },
            {
                "name": "search_endpoint_capabilities",
                "description": "Search safe endpoint diagnostics and remediation capabilities by natural language.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "limit": {"type": "integer"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "search_endpoint_skills",
                "description": "Search the endpoint support skill catalog for smart troubleshooting guidance.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "limit": {"type": "integer"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "list_endpoint_skills",
                "description": "List the endpoint support skill catalog.",
                "inputSchema": {
                    "type": "object",
                    "properties": {},
                },
            },
            {
                "name": "get_oem_device_profile",
                "description": "Detect endpoint OEM manufacturer, model, BIOS, and installed OEM update tools.",
                "inputSchema": {
                    "type": "object",
                    "properties": {},
                },
            },
            {
                "name": "search_oem_guidance",
                "description": "Search trusted OEM/vendor driver, BIOS, firmware, and update guidance.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "manufacturer": {"type": "string"},
                        "model": {"type": "string"},
                        "limit": {"type": "integer"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "scan_oem_driver_updates",
                "description": "Scan for available OEM driver updates using a detected trusted OEM update utility.",
                "inputSchema": {
                    "type": "object",
                    "properties": {},
                },
            },
            {
                "name": "install_oem_driver_updates",
                "description": "Install available driver updates only through a detected trusted OEM update utility after approval.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "approved": {"type": "boolean"},
                    },
                    "required": ["approved"],
                },
            },
            {
                "name": "install_oem_driver_utility_and_updates",
                "description": "Install the approved OEM driver utility when missing, then install available driver updates through that OEM utility after approval.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "approved": {"type": "boolean"},
                    },
                    "required": ["approved"],
                },
            },
            {
                "name": "plan_endpoint_action",
                "description": "Convert a natural endpoint action request into a safe executable plan, if supported.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "request": {"type": "string"},
                        "context": {"type": "object"},
                    },
                    "required": ["request"],
                },
            },
            {
                "name": "execute_parameterized_remediation",
                "description": "Execute an approved endpoint action plan by intent and optional target.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "intent": {
                            "type": "string",
                            "description": "The exact intent returned by plan_endpoint_action.",
                        },
                        "target": {
                            "type": "string",
                            "description": "Optional target returned by plan_endpoint_action, such as an app name.",
                        },
                        "parameters": {"type": "object"},
                        "approved": {"type": "boolean"},
                    },
                    "required": ["intent", "approved"],
                },
            },
            {
                "name": "verify_endpoint_action",
                "description": "Run read-only verification diagnostics for an endpoint action intent.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "intent": {
                            "type": "string",
                            "description": "The exact intent returned by plan_endpoint_action.",
                        },
                        "target": {"type": "string"},
                    },
                    "required": ["intent"],
                },
            },
            {
                "name": "get_endpoint_telemetry_summary",
                "description": "Summarize recent Endpoint Support Agent telemetry and action history.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "limit": {"type": "integer"},
                    },
                },
            },
            {
                "name": "assess_endpoint_guardrails",
                "description": "Assess whether a proposed endpoint tool call or action is allowed by safety guardrails.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "tool_name": {"type": "string"},
                        "arguments": {"type": "object"},
                        "action": {"type": "object"},
                        "approved": {"type": "boolean"},
                        "intent": {"type": "string"},
                        "target": {"type": "string"},
                    },
                },
            },
            {
                "name": "set_model",
                "description": "Internal control tool that updates the local resolver classifier model.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "model": {"type": "string"},
                    },
                    "required": ["model"],
                },
            },
        ]

    def call_tool(self, name: str, arguments: Optional[Dict] = None) -> Dict:
        if name == "resolve_issue":
            return self._resolve_issue(arguments or {})
        if name == "execute_remediation":
            return self._execute_remediation(arguments or {})
        if name == "execute_diagnostic":
            return self._execute_diagnostic(arguments or {})
        if name == "disable_startup_app":
            return self._disable_startup_app(arguments or {})
        if name == "search_endpoint_capabilities":
            return self._search_endpoint_capabilities(arguments or {})
        if name == "search_endpoint_skills":
            return self._search_endpoint_skills(arguments or {})
        if name == "list_endpoint_skills":
            return self._list_endpoint_skills()
        if name == "get_oem_device_profile":
            return self._get_oem_device_profile()
        if name == "search_oem_guidance":
            return self._search_oem_guidance(arguments or {})
        if name == "scan_oem_driver_updates":
            return self._scan_oem_driver_updates()
        if name == "install_oem_driver_updates":
            return self._install_oem_driver_updates(arguments or {})
        if name == "install_oem_driver_utility_and_updates":
            return self._install_oem_driver_utility_and_updates(arguments or {})
        if name == "plan_endpoint_action":
            return self._plan_endpoint_action(arguments or {})
        if name == "execute_parameterized_remediation":
            return self._execute_parameterized_remediation(arguments or {})
        if name == "verify_endpoint_action":
            return self._verify_endpoint_action(arguments or {})
        if name == "get_endpoint_telemetry_summary":
            return self._get_endpoint_telemetry_summary(arguments or {})
        if name == "assess_endpoint_guardrails":
            return self._assess_endpoint_guardrails(arguments or {})
        if name == "set_model":
            return self._set_model(arguments or {})
        raise ValueError(f"Unknown MCP tool: {name}")

    def _resolve_issue(self, arguments: Dict) -> Dict:
        issue = str(arguments.get("issue", "")).strip()
        if not issue:
            raise ValueError("resolve_issue requires a non-empty issue")

        resolution = self.knowledge_base.resolve(issue, arguments.get("context") or {})
        return {"tool": "resolve_issue", "resolution": resolution.to_dict()}

    def _execute_remediation(self, arguments: Dict) -> Dict:
        action = str(arguments.get("action", "")).strip()
        if not action:
            raise ValueError("execute_remediation requires a non-empty action")
        self._enforce_guardrails("execute_remediation", arguments)

        remediation = execute_tool(
            action,
            approved=bool(arguments.get("approved")),
            executor=self.command_executor,
        )
        return {
            "tool": "execute_remediation",
            "action": remediation["action"],
            "result": remediation["result"],
        }

    def _execute_diagnostic(self, arguments: Dict) -> Dict:
        tool_name = str(arguments.get("tool") or arguments.get("name") or "").strip()
        if not tool_name:
            raise ValueError("execute_diagnostic requires a non-empty tool")

        diagnostic = execute_diagnostic_tool(
            tool_name,
            executor=self.command_executor,
        )
        return {
            "tool": "execute_diagnostic",
            "diagnostic": diagnostic["diagnostic"],
            "result": diagnostic["result"],
        }

    def _disable_startup_app(self, arguments: Dict) -> Dict:
        app = str(arguments.get("app", "")).strip()
        if not app:
            raise ValueError("disable_startup_app requires a non-empty app")
        self._enforce_guardrails("disable_startup_app", arguments)

        remediation = disable_startup_app(
            app,
            approved=bool(arguments.get("approved")),
            executor=self.command_executor,
        )
        return {
            "tool": "disable_startup_app",
            "action": remediation["action"],
            "result": remediation["result"],
        }

    def _search_endpoint_capabilities(self, arguments: Dict) -> Dict:
        query = str(arguments.get("query", "")).strip()
        if not query:
            raise ValueError("search_endpoint_capabilities requires a non-empty query")
        limit = int(arguments.get("limit") or 8)
        return search_endpoint_capabilities(query, limit=limit)

    def _search_endpoint_skills(self, arguments: Dict) -> Dict:
        query = str(arguments.get("query", "")).strip()
        if not query:
            raise ValueError("search_endpoint_skills requires a non-empty query")
        limit = int(arguments.get("limit") or 5)
        return search_endpoint_skills(query, limit=limit)

    def _list_endpoint_skills(self) -> Dict:
        return {
            "tool": "list_endpoint_skills",
            "skills": list_endpoint_skills(),
        }

    def _get_oem_device_profile(self) -> Dict:
        return get_oem_device_profile(executor=self.command_executor)

    def _search_oem_guidance(self, arguments: Dict) -> Dict:
        query = str(arguments.get("query", "")).strip()
        if not query:
            raise ValueError("search_oem_guidance requires a non-empty query")
        return search_oem_guidance(
            query,
            manufacturer=str(arguments.get("manufacturer") or ""),
            model=str(arguments.get("model") or ""),
            limit=int(arguments.get("limit") or 4),
        )

    def _scan_oem_driver_updates(self) -> Dict:
        return scan_oem_driver_updates(executor=self.command_executor)

    def _install_oem_driver_updates(self, arguments: Dict) -> Dict:
        self._enforce_guardrails("install_oem_driver_updates", arguments)
        return install_oem_driver_updates(
            approved=bool(arguments.get("approved")),
            executor=self.command_executor,
        )

    def _install_oem_driver_utility_and_updates(self, arguments: Dict) -> Dict:
        self._enforce_guardrails("install_oem_driver_utility_and_updates", arguments)
        return install_oem_driver_utility_and_updates(
            approved=bool(arguments.get("approved")),
            executor=self.command_executor,
        )

    def _plan_endpoint_action(self, arguments: Dict) -> Dict:
        request = str(arguments.get("request", "")).strip()
        if not request:
            raise ValueError("plan_endpoint_action requires a non-empty request")
        return plan_endpoint_action(request, arguments.get("context") or {})

    def _execute_parameterized_remediation(self, arguments: Dict) -> Dict:
        intent = str(arguments.get("intent", "")).strip()
        if not intent:
            raise ValueError("execute_parameterized_remediation requires a non-empty intent")
        self._enforce_guardrails("execute_parameterized_remediation", arguments)
        return execute_parameterized_remediation(
            intent=intent,
            target=arguments.get("target"),
            approved=bool(arguments.get("approved")),
            parameters=arguments.get("parameters") or {},
            executor=self.command_executor,
        )

    def _verify_endpoint_action(self, arguments: Dict) -> Dict:
        intent = str(arguments.get("intent", "")).strip()
        if not intent:
            raise ValueError("verify_endpoint_action requires a non-empty intent")
        return verify_endpoint_action(
            intent=intent,
            target=arguments.get("target"),
            executor=self.command_executor,
        )

    def _get_endpoint_telemetry_summary(self, arguments: Dict) -> Dict:
        return summarize_telemetry(limit=int(arguments.get("limit") or 20))

    def _assess_endpoint_guardrails(self, arguments: Dict) -> Dict:
        tool_name = str(arguments.get("tool_name") or "").strip()
        if tool_name:
            decision = assess_tool_call(tool_name, arguments.get("arguments") or {})
        else:
            decision = assess_endpoint_action(
                arguments.get("action") or {},
                approved=bool(arguments.get("approved")),
                intent=str(arguments.get("intent") or ""),
                target=str(arguments.get("target") or ""),
            )
        return {"tool": "assess_endpoint_guardrails", "decision": decision}

    def _enforce_guardrails(self, tool_name: str, arguments: Dict) -> None:
        decision = assess_tool_call(tool_name, arguments)
        if not decision.get("allowed", False):
            raise ValueError(decision.get("reason") or "Endpoint guardrail blocked this action")

    def _set_model(self, arguments: Dict) -> Dict:
        model = str(arguments.get("model", "")).strip()
        if not model:
            raise ValueError("set_model requires a non-empty model")

        self.knowledge_base.model = model
        return {
            "tool": "set_model",
            "model": self.knowledge_base.model,
        }
