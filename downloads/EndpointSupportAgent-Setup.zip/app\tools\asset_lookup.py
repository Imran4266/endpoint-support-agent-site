from typing import Dict


def extract_context(issue: str) -> Dict[str, str]:
    """Infer lightweight endpoint context from the user's text."""

    text = issue.lower()
    context: Dict[str, str] = {}

    if "windows 11" in text:
        context["os"] = "Windows 11"
    elif "windows 10" in text:
        context["os"] = "Windows 10"
    elif "windows" in text:
        context["os"] = "Windows"

    for device in ("laptop", "desktop", "workstation", "server", "vm"):
        if device in text:
            context["device"] = device
            break

    for application in ("outlook", "teams", "onedrive", "vpn", "chrome", "edge"):
        if application in text:
            context["application"] = application
            break

    if any(word in text for word in ("urgent", "down", "blocked", "cannot work")):
        context["urgency"] = "high"

    return context
