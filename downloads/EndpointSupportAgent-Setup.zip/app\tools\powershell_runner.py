from tools.diagnose import run_powershell


def run_function(function_name):
    command = f"Import-Module .\\modules\\EndpointSupportTools.psm1; {function_name}"
    result = run_powershell(command)
    if result["ok"]:
        return result["stdout"]
    return result["stderr"] or result["stdout"]
