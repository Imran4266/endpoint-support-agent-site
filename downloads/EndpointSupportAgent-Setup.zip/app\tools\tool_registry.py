from tools.diagnose import TOOLS as SUPPORT_TOOLS


# Backward-compatible description map for older imports.
TOOLS = {name: tool.description for name, tool in SUPPORT_TOOLS.items()}
