from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass(frozen=True)
class IssueRecord:
    id: str
    title: str
    category: str
    keywords: List[str]
    findings: str
    steps: List[str]
    diagnostic_tool_names: List[str]
    recommended_action_name: Optional[str] = None
    confidence: float = 0.7


@dataclass
class Resolution:
    title: str
    category: str
    confidence: float
    findings: str
    steps: List[str]
    diagnostic_tools: List[Dict]
    recommended_action: Optional[Dict]
    sources: List[Dict]
    external_steps: List[str] = field(default_factory=list)
    skills: List[Dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "category": self.category,
            "confidence": self.confidence,
            "findings": self.findings,
            "steps": self.steps,
            "external_steps": self.external_steps,
            "diagnostic_tools": self.diagnostic_tools,
            "recommended_action": self.recommended_action,
            "sources": self.sources,
            "skills": self.skills,
        }
