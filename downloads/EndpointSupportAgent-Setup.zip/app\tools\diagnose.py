import re
import subprocess
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from tools.oem_support import OEM_DEVICE_PROFILE_COMMAND


CLEAN_TEMP_COMMAND = (
    "$path=$env:TEMP; "
    "$items=@(Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue); "
    "$sample=@($items | Select-Object -First 20 -ExpandProperty FullName); "
    "foreach ($item in $items) { "
    "Remove-Item -LiteralPath $item.FullName -Recurse -Force -Confirm:$false -ErrorAction SilentlyContinue "
    "}; "
    "$remaining=@(Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue); "
    "Write-Output \"Cleanup path: $path\"; "
    "Write-Output \"Top-level temporary items found: $($items.Count)\"; "
    "Write-Output \"Top-level temporary items remaining after cleanup: $($remaining.Count)\"; "
    "if ($sample.Count -gt 0) { "
    "Write-Output 'Sample of items targeted:'; "
    "$sample | ForEach-Object { Write-Output \"- $_\" } "
    "} else { "
    "Write-Output 'No temporary items were found.' "
    "}"
)


@dataclass(frozen=True)
class SupportTool:
    name: str
    tier: int
    type: str
    description: str
    command: str
    requires_approval: bool

    def to_dict(self, include_command: bool = False) -> dict:
        data = {
            "name": self.name,
            "tier": self.tier,
            "type": self.type,
            "description": self.description,
            "requires_approval": self.requires_approval,
        }
        if include_command:
            data["command"] = self.command
        return data


TOOLS: Dict[str, SupportTool] = {
    "No-Op": SupportTool(
        name="No-Op",
        tier=1,
        type="action",
        description="Safe remediation smoke-test action that performs no endpoint change.",
        command="Write-Output 'No remediation changes were made.'",
        requires_approval=True,
    ),
    "Get-SystemInfo": SupportTool(
        name="Get-SystemInfo",
        tier=1,
        type="readonly",
        description="Fetch OS version and product name.",
        command="Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion",
        requires_approval=False,
    ),
    "Get-DiskUsage": SupportTool(
        name="Get-DiskUsage",
        tier=1,
        type="readonly",
        description="Check drive storage capacity.",
        command="Get-PSDrive -PSProvider FileSystem | Select-Object Name, Free, Used",
        requires_approval=False,
    ),
    "Get-HealthReport": SupportTool(
        name="Get-HealthReport",
        tier=1,
        type="readonly",
        description="List top CPU consuming processes.",
        command="Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 Name, CPU",
        requires_approval=False,
    ),
    "Get-NetworkConfig": SupportTool(
        name="Get-NetworkConfig",
        tier=1,
        type="readonly",
        description="Check IP address, gateway, and DNS servers.",
        command=(
            "Get-NetIPConfiguration | Select-Object InterfaceAlias, IPv4Address, "
            "IPv4DefaultGateway, DNSServer | Format-List"
        ),
        requires_approval=False,
    ),
    "Test-Internet": SupportTool(
        name="Test-Internet",
        tier=1,
        type="readonly",
        description="Ping 8.8.8.8 to verify outside connectivity.",
        command="Test-Connection -ComputerName 8.8.8.8 -Count 3 | Select-Object Address, Status, ResponseTime",
        requires_approval=False,
    ),
    "Test-PortConnection": SupportTool(
        name="Test-PortConnection",
        tier=1,
        type="readonly",
        description="Check whether HTTPS connectivity is blocked.",
        command="Test-NetConnection -ComputerName google.com -Port 443 | Select-Object ComputerName, RemoteAddress, TcpTestSucceeded",
        requires_approval=False,
    ),
    "Get-ActiveConnections": SupportTool(
        name="Get-ActiveConnections",
        tier=1,
        type="readonly",
        description="List active network connections and listening ports.",
        command="Get-NetTCPConnection -State Established | Select-Object -First 10 LocalAddress, LocalPort, RemoteAddress, RemotePort",
        requires_approval=False,
    ),
    "Check-DNSResolution": SupportTool(
        name="Check-DNSResolution",
        tier=1,
        type="readonly",
        description="Resolve a known domain to validate DNS behavior.",
        command="Resolve-DnsName -Name microsoft.com -Type A -ErrorAction SilentlyContinue | Select-Object Name, Type, IPAddress",
        requires_approval=False,
    ),
    "Test-InternetSpeed": SupportTool(
        name="Test-InternetSpeed",
        tier=1,
        type="readonly",
        description="Estimate download speed in Mbps.",
        command=(
            "$start = Get-Date; Invoke-WebRequest -Uri "
            "'https://speed.cloudflare.com/__down?bytes=10485760' "
            "-OutFile \"$env:TEMP\\speedtest.dat\" -UseBasicParsing; "
            "$time = (Get-Date) - $start; $speed = (10 / $time.TotalSeconds) * 8; "
            "Remove-Item \"$env:TEMP\\speedtest.dat\" -ErrorAction SilentlyContinue; "
            "Write-Output \"Estimated Download Speed: $([math]::Round($speed, 2)) Mbps\""
        ),
        requires_approval=False,
    ),
    "Get-NetworkAdapterStatus": SupportTool(
        name="Get-NetworkAdapterStatus",
        tier=1,
        type="readonly",
        description="List network adapter status and link speed.",
        command="Get-NetAdapter | Select-Object Name, InterfaceDescription, Status, LinkSpeed",
        requires_approval=False,
    ),
    "Get-TempFolderSize": SupportTool(
        name="Get-TempFolderSize",
        tier=1,
        type="readonly",
        description="Estimate current user temporary folder size.",
        command=(
            "$path=$env:TEMP; "
            "$bytes=(Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue | "
            "Measure-Object -Property Length -Sum).Sum; "
            "[PSCustomObject]@{Path=$path; SizeMB=[math]::Round(($bytes/1MB),2)}"
        ),
        requires_approval=False,
    ),
    "Get-MemoryUsage": SupportTool(
        name="Get-MemoryUsage",
        tier=1,
        type="readonly",
        description="Show total and free physical memory.",
        command=(
            "Get-CimInstance Win32_OperatingSystem | Select-Object "
            "@{Name='TotalMemoryGB';Expression={[math]::Round($_.TotalVisibleMemorySize/1MB,2)}}, "
            "@{Name='FreeMemoryGB';Expression={[math]::Round($_.FreePhysicalMemory/1MB,2)}}"
        ),
        requires_approval=False,
    ),
    "Get-StartupPrograms": SupportTool(
        name="Get-StartupPrograms",
        tier=1,
        type="readonly",
        description="List startup programs that may affect login or performance.",
        command="Get-CimInstance Win32_StartupCommand | Select-Object -First 20 Name, Command, Location, User",
        requires_approval=False,
    ),
    "Get-RecentSystemErrors": SupportTool(
        name="Get-RecentSystemErrors",
        tier=1,
        type="readonly",
        description="Collect recent critical system event log errors.",
        command=(
            "Get-WinEvent -FilterHashtable @{LogName='System'; Level=2; StartTime=(Get-Date).AddDays(-3)} "
            "-MaxEvents 10 -ErrorAction SilentlyContinue | Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, Message"
        ),
        requires_approval=False,
    ),
    "Get-PendingRebootStatus": SupportTool(
        name="Get-PendingRebootStatus",
        tier=1,
        type="readonly",
        description="Check whether Windows Update has marked the device for reboot.",
        command=(
            "$pending=Test-Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update\\RebootRequired'; "
            "[PSCustomObject]@{PendingReboot=$pending}"
        ),
        requires_approval=False,
    ),
    "Get-OutlookStatus": SupportTool(
        name="Get-OutlookStatus",
        tier=1,
        type="readonly",
        description="Check Outlook process state and RoamCache item count.",
        command=(
            "Get-Process OUTLOOK -ErrorAction SilentlyContinue | Select-Object Name, Id, CPU, StartTime; "
            "Get-ChildItem \"$env:LOCALAPPDATA\\Microsoft\\Outlook\\RoamCache\" -ErrorAction SilentlyContinue | "
            "Measure-Object | Select-Object Count"
        ),
        requires_approval=False,
    ),
    "Get-TeamsStatus": SupportTool(
        name="Get-TeamsStatus",
        tier=1,
        type="readonly",
        description="Check Teams process state and common cache folder presence.",
        command=(
            "Get-Process Teams,ms-teams -ErrorAction SilentlyContinue | Select-Object Name, Id, CPU, StartTime; "
            "$paths=@(\"$env:APPDATA\\Microsoft\\Teams\\Cache\","
            "\"$env:LOCALAPPDATA\\Packages\\MSTeams_8wekyb3d8bbwe\\LocalCache\\Microsoft\\MSTeams\"); "
            "$paths | ForEach-Object { [PSCustomObject]@{Path=$_; Exists=(Test-Path $_)} }"
        ),
        requires_approval=False,
    ),
    "Get-PrinterStatus": SupportTool(
        name="Get-PrinterStatus",
        tier=1,
        type="readonly",
        description="List installed printers with status, queue count, driver, and port.",
        command="Get-Printer -ErrorAction SilentlyContinue | Select-Object Name, PrinterStatus, JobCount, DriverName, PortName",
        requires_approval=False,
    ),
    "Get-PrintQueue": SupportTool(
        name="Get-PrintQueue",
        tier=1,
        type="readonly",
        description="List current print jobs and queue status.",
        command="Get-PrintJob -ErrorAction SilentlyContinue | Select-Object PrinterName, ID, DocumentName, JobStatus, SubmittedTime",
        requires_approval=False,
    ),
    "Get-VPNConnectionStatus": SupportTool(
        name="Get-VPNConnectionStatus",
        tier=1,
        type="readonly",
        description="List configured Windows VPN connections and connection status.",
        command=(
            "Get-VpnConnection -AllUserConnection -ErrorAction SilentlyContinue | "
            "Select-Object Name, ServerAddress, ConnectionStatus, TunnelType; "
            "Get-VpnConnection -ErrorAction SilentlyContinue | Select-Object Name, ServerAddress, ConnectionStatus, TunnelType"
        ),
        requires_approval=False,
    ),
    "Get-BitLockerStatus": SupportTool(
        name="Get-BitLockerStatus",
        tier=1,
        type="readonly",
        description="Check BitLocker volume, encryption, and protection status.",
        command=(
            "Get-BitLockerVolume -ErrorAction SilentlyContinue | "
            "Select-Object MountPoint, VolumeStatus, ProtectionStatus, EncryptionPercentage"
        ),
        requires_approval=False,
    ),
    "Get-IdentityTicketStatus": SupportTool(
        name="Get-IdentityTicketStatus",
        tier=1,
        type="readonly",
        description="Show current user identity and Kerberos ticket status.",
        command="whoami /user; whoami /upn 2>$null; klist 2>$null",
        requires_approval=False,
    ),
    "Get-IntuneEnrollmentStatus": SupportTool(
        name="Get-IntuneEnrollmentStatus",
        tier=1,
        type="readonly",
        description="List Intune EnterpriseMgmt scheduled tasks and state.",
        command=(
            "Get-ScheduledTask -ErrorAction SilentlyContinue | "
            "Where-Object { $_.TaskPath -like '*EnterpriseMgmt*' } | Select-Object TaskName, TaskPath, State"
        ),
        requires_approval=False,
    ),
    "Get-CompanyPortalStatus": SupportTool(
        name="Get-CompanyPortalStatus",
        tier=1,
        type="readonly",
        description="Check whether Company Portal is installed and report its version.",
        command="Get-AppxPackage -Name Microsoft.CompanyPortal -ErrorAction SilentlyContinue | Select-Object Name, Version, InstallLocation",
        requires_approval=False,
    ),
    "Get-InstalledApps": SupportTool(
        name="Get-InstalledApps",
        tier=1,
        type="readonly",
        description="List recently discoverable installed desktop applications.",
        command=(
            "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "-ErrorAction SilentlyContinue | Where-Object DisplayName | "
            "Select-Object -First 20 DisplayName, DisplayVersion, Publisher, InstallDate"
        ),
        requires_approval=False,
    ),
    "Get-RecentInstallEvents": SupportTool(
        name="Get-RecentInstallEvents",
        tier=1,
        type="readonly",
        description="Collect recent Windows Installer events for application install failures.",
        command=(
            "Get-WinEvent -FilterHashtable @{LogName='Application'; ProviderName='MsiInstaller'; StartTime=(Get-Date).AddDays(-7)} "
            "-MaxEvents 10 -ErrorAction SilentlyContinue | Select-Object TimeCreated, Id, LevelDisplayName, Message"
        ),
        requires_approval=False,
    ),
    "Get-WindowsUpdateStatus": SupportTool(
        name="Get-WindowsUpdateStatus",
        tier=1,
        type="readonly",
        description="Check Windows Update related service status.",
        command="Get-Service wuauserv,bits,cryptsvc -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType",
        requires_approval=False,
    ),
    "Get-RecentUpdateEvents": SupportTool(
        name="Get-RecentUpdateEvents",
        tier=1,
        type="readonly",
        description="Collect recent Windows Update client events.",
        command=(
            "Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-WindowsUpdateClient'; StartTime=(Get-Date).AddDays(-7)} "
            "-MaxEvents 10 -ErrorAction SilentlyContinue | Select-Object TimeCreated, Id, LevelDisplayName, Message"
        ),
        requires_approval=False,
    ),
    "Get-BrowserStatus": SupportTool(
        name="Get-BrowserStatus",
        tier=1,
        type="readonly",
        description="Check common browser processes and installed versions.",
        command=(
            "Get-Process msedge,chrome,firefox -ErrorAction SilentlyContinue | "
            "Select-Object Name, Id, CPU, StartTime; "
            "$paths=@("
            "\"$env:ProgramFiles\\Google\\Chrome\\Application\\chrome.exe\","
            "\"${env:ProgramFiles(x86)}\\Google\\Chrome\\Application\\chrome.exe\","
            "\"$env:ProgramFiles\\Microsoft\\Edge\\Application\\msedge.exe\","
            "\"${env:ProgramFiles(x86)}\\Microsoft\\Edge\\Application\\msedge.exe\","
            "\"$env:ProgramFiles\\Mozilla Firefox\\firefox.exe\","
            "\"${env:ProgramFiles(x86)}\\Mozilla Firefox\\firefox.exe\"); "
            "$paths | Where-Object { Test-Path $_ } | ForEach-Object { "
            "[PSCustomObject]@{Path=$_; Version=(Get-Item $_).VersionInfo.ProductVersion} }"
        ),
        requires_approval=False,
    ),
    "Get-OneDriveStatus": SupportTool(
        name="Get-OneDriveStatus",
        tier=1,
        type="readonly",
        description="Check OneDrive process, executable presence, and sync client state hints.",
        command=(
            "Get-Process OneDrive -ErrorAction SilentlyContinue | Select-Object Name, Id, CPU, StartTime; "
            "$paths=@(\"$env:LOCALAPPDATA\\Microsoft\\OneDrive\\OneDrive.exe\","
            "\"$env:ProgramFiles\\Microsoft OneDrive\\OneDrive.exe\","
            "\"${env:ProgramFiles(x86)}\\Microsoft OneDrive\\OneDrive.exe\"); "
            "$paths | ForEach-Object { [PSCustomObject]@{Path=$_; Exists=(Test-Path $_)} }; "
            "Get-ChildItem \"$env:LOCALAPPDATA\\Microsoft\\OneDrive\\logs\" -ErrorAction SilentlyContinue | "
            "Sort-Object LastWriteTime -Descending | Select-Object -First 5 Name, LastWriteTime, Length"
        ),
        requires_approval=False,
    ),
    "Get-OfficeAppStatus": SupportTool(
        name="Get-OfficeAppStatus",
        tier=1,
        type="readonly",
        description="Check Microsoft Office app processes and installed Office product entries.",
        command=(
            "Get-Process WINWORD,EXCEL,POWERPNT,ONENOTE,MSACCESS,MSPUB -ErrorAction SilentlyContinue | "
            "Select-Object Name, Id, CPU, StartTime; "
            "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "-ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'Microsoft 365|Microsoft Office' } | "
            "Select-Object -First 5 DisplayName, DisplayVersion, Publisher"
        ),
        requires_approval=False,
    ),
    "Get-AdobeReaderStatus": SupportTool(
        name="Get-AdobeReaderStatus",
        tier=1,
        type="readonly",
        description="Check Adobe Reader/Acrobat process state and installed product entries.",
        command=(
            "Get-Process AcroRd32,Acrobat -ErrorAction SilentlyContinue | Select-Object Name, Id, CPU, StartTime; "
            "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "-ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'Adobe Acrobat|Adobe Reader' } | "
            "Select-Object -First 5 DisplayName, DisplayVersion, Publisher"
        ),
        requires_approval=False,
    ),
    "Get-CollaborationAppStatus": SupportTool(
        name="Get-CollaborationAppStatus",
        tier=1,
        type="readonly",
        description="Check Zoom, Webex, Slack, and common collaboration client state.",
        command=(
            "Get-Process Zoom,Webex,ptoneclk,Slack,CiscoCollabHost -ErrorAction SilentlyContinue | "
            "Select-Object Name, Id, CPU, StartTime; "
            "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "-ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'Zoom|Webex|Slack' } | "
            "Select-Object -First 10 DisplayName, DisplayVersion, Publisher"
        ),
        requires_approval=False,
    ),
    "Get-AudioDeviceStatus": SupportTool(
        name="Get-AudioDeviceStatus",
        tier=1,
        type="readonly",
        description="List audio devices and Windows audio service state.",
        command=(
            "Get-CimInstance Win32_SoundDevice -ErrorAction SilentlyContinue | Select-Object Name, Status, Manufacturer; "
            "Get-Service Audiosrv,AudioEndpointBuilder -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType"
        ),
        requires_approval=False,
    ),
    "Get-CameraDeviceStatus": SupportTool(
        name="Get-CameraDeviceStatus",
        tier=1,
        type="readonly",
        description="List camera/webcam devices detected by Windows.",
        command=(
            "Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | "
            "Where-Object { $_.PNPClass -eq 'Camera' -or $_.Name -match 'camera|webcam' } | "
            "Select-Object Name, Status, PNPClass, Manufacturer"
        ),
        requires_approval=False,
    ),
    "Get-BluetoothStatus": SupportTool(
        name="Get-BluetoothStatus",
        tier=1,
        type="readonly",
        description="Check Bluetooth service and Bluetooth device state.",
        command=(
            "Get-Service bthserv -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; "
            "Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | "
            "Where-Object { $_.PNPClass -eq 'Bluetooth' -or $_.Name -match 'Bluetooth' } | "
            "Select-Object -First 20 Name, Status, Manufacturer"
        ),
        requires_approval=False,
    ),
    "Get-RemoteDesktopStatus": SupportTool(
        name="Get-RemoteDesktopStatus",
        tier=1,
        type="readonly",
        description="Check Remote Desktop service and local RDP enablement flag.",
        command=(
            "Get-Service TermService -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; "
            "Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server' -ErrorAction SilentlyContinue | "
            "Select-Object fDenyTSConnections"
        ),
        requires_approval=False,
    ),
    "Get-TimeSyncStatus": SupportTool(
        name="Get-TimeSyncStatus",
        tier=1,
        type="readonly",
        description="Check Windows Time service and time synchronization status.",
        command="Get-Service w32time -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; w32tm /query /status 2>$null",
        requires_approval=False,
    ),
    "Get-DefenderStatus": SupportTool(
        name="Get-DefenderStatus",
        tier=1,
        type="readonly",
        description="Check Microsoft Defender protection and signature status.",
        command=(
            "Get-MpComputerStatus -ErrorAction SilentlyContinue | Select-Object "
            "AMServiceEnabled, AntivirusEnabled, RealTimeProtectionEnabled, "
            "AntivirusSignatureLastUpdated, QuickScanAge, FullScanAge"
        ),
        requires_approval=False,
    ),
    "Get-FirewallProxyStatus": SupportTool(
        name="Get-FirewallProxyStatus",
        tier=1,
        type="readonly",
        description="Check Windows firewall profiles and user/WinHTTP proxy settings.",
        command=(
            "Get-NetFirewallProfile -ErrorAction SilentlyContinue | Select-Object Name, Enabled; "
            "netsh winhttp show proxy; "
            "Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings' "
            "-ErrorAction SilentlyContinue | Select-Object ProxyEnable, ProxyServer, AutoConfigURL"
        ),
        requires_approval=False,
    ),
    "Get-CertificateStoreHealth": SupportTool(
        name="Get-CertificateStoreHealth",
        tier=1,
        type="readonly",
        description="List current user certificates nearing expiration.",
        command=(
            "$threshold=(Get-Date).AddDays(30); "
            "Get-ChildItem Cert:\\CurrentUser\\My -ErrorAction SilentlyContinue | "
            "Where-Object { $_.NotAfter -lt $threshold } | Select-Object -First 10 Subject, NotAfter, Thumbprint"
        ),
        requires_approval=False,
    ),
    "Get-SCCMClientStatus": SupportTool(
        name="Get-SCCMClientStatus",
        tier=1,
        type="readonly",
        description="Check Configuration Manager/SCCM client service and client version.",
        command=(
            "Get-Service CcmExec -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; "
            "Get-CimInstance -Namespace root\\ccm -ClassName SMS_Client -ErrorAction SilentlyContinue | "
            "Select-Object ClientVersion, ClientType"
        ),
        requires_approval=False,
    ),
    "Get-GroupPolicyStatus": SupportTool(
        name="Get-GroupPolicyStatus",
        tier=1,
        type="readonly",
        description="Collect applied user and computer Group Policy summary.",
        command="gpresult /r /scope user; gpresult /r /scope computer",
        requires_approval=False,
    ),
    "Get-ExplorerShellStatus": SupportTool(
        name="Get-ExplorerShellStatus",
        tier=1,
        type="readonly",
        description="Check Explorer, Start menu, and Search shell process state.",
        command=(
            "Get-Process explorer,StartMenuExperienceHost,SearchHost -ErrorAction SilentlyContinue | "
            "Select-Object Name, Id, CPU, StartTime"
        ),
        requires_approval=False,
    ),
    "Get-WindowsSearchStatus": SupportTool(
        name="Get-WindowsSearchStatus",
        tier=1,
        type="readonly",
        description="Check Windows Search service and indexer process state.",
        command=(
            "Get-Service WSearch -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; "
            "Get-Process SearchIndexer,SearchHost -ErrorAction SilentlyContinue | Select-Object Name, Id, CPU, StartTime"
        ),
        requires_approval=False,
    ),
    "Get-WindowsStoreStatus": SupportTool(
        name="Get-WindowsStoreStatus",
        tier=1,
        type="readonly",
        description="Check Microsoft Store app package and related services.",
        command=(
            "Get-AppxPackage Microsoft.WindowsStore -ErrorAction SilentlyContinue | Select-Object Name, Version, InstallLocation; "
            "Get-Service InstallService,ClipSVC -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType"
        ),
        requires_approval=False,
    ),
    "Get-PowerBatteryStatus": SupportTool(
        name="Get-PowerBatteryStatus",
        tier=1,
        type="readonly",
        description="Check battery, AC power, active power plan, and sleep capability.",
        command=(
            "Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | "
            "Select-Object Name, BatteryStatus, EstimatedChargeRemaining, EstimatedRunTime; "
            "powercfg /getactivescheme; powercfg /a"
        ),
        requires_approval=False,
    ),
    "Get-DisplayDockStatus": SupportTool(
        name="Get-DisplayDockStatus",
        tier=1,
        type="readonly",
        description="Check display adapters, monitors, docks, and display-related devices.",
        command=(
            "Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | "
            "Select-Object Name, DriverVersion, AdapterRAM, VideoModeDescription; "
            "Get-CimInstance Win32_DesktopMonitor -ErrorAction SilentlyContinue | Select-Object Name, ScreenWidth, ScreenHeight; "
            "Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | "
            "Where-Object { $_.Name -match 'dock|display|monitor|graphics|usb-c|thunderbolt' } | "
            "Select-Object -First 20 Name, Status, PNPClass, Manufacturer"
        ),
        requires_approval=False,
    ),
    "Get-USBDeviceStatus": SupportTool(
        name="Get-USBDeviceStatus",
        tier=1,
        type="readonly",
        description="List USB, HID, and problem PnP devices.",
        command=(
            "Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | "
            "Where-Object { $_.PNPClass -match 'USB|HIDClass|Keyboard|Mouse|Image|Camera|Bluetooth' -or $_.ConfigManagerErrorCode -ne 0 } | "
            "Select-Object -First 30 Name, Status, PNPClass, ConfigManagerErrorCode, Manufacturer"
        ),
        requires_approval=False,
    ),
    "Get-DriverProblemDevices": SupportTool(
        name="Get-DriverProblemDevices",
        tier=1,
        type="readonly",
        description="List devices reporting driver or PnP error codes.",
        command=(
            "Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | "
            "Where-Object { $_.ConfigManagerErrorCode -ne 0 } | "
            "Select-Object Name, PNPClass, Status, ConfigManagerErrorCode, Manufacturer, DeviceID"
        ),
        requires_approval=False,
    ),
    "Get-OEMDeviceProfile": SupportTool(
        name="Get-OEMDeviceProfile",
        tier=1,
        type="readonly",
        description="Detect endpoint manufacturer, model, BIOS, and installed OEM update utilities.",
        command=OEM_DEVICE_PROFILE_COMMAND,
        requires_approval=False,
    ),
    "Get-UserProfileStatus": SupportTool(
        name="Get-UserProfileStatus",
        tier=1,
        type="readonly",
        description="Check current user profile path, profile disk use, and common shell folders.",
        command=(
            "$profilePath=$env:USERPROFILE; "
            "$bytes=(Get-ChildItem -LiteralPath $profilePath -Force -ErrorAction SilentlyContinue | "
            "Measure-Object -Property Length -Sum).Sum; "
            "[PSCustomObject]@{User=$env:USERNAME; ProfilePath=$profilePath; ProfileRootSizeMB=[math]::Round(($bytes/1MB),2)}; "
            "[PSCustomObject]@{DesktopExists=(Test-Path ([Environment]::GetFolderPath('Desktop'))); "
            "DocumentsExists=(Test-Path ([Environment]::GetFolderPath('MyDocuments'))); TempPath=$env:TEMP}"
        ),
        requires_approval=False,
    ),
    "Get-NetworkDriveStatus": SupportTool(
        name="Get-NetworkDriveStatus",
        tier=1,
        type="readonly",
        description="List mapped network drives, SMB client configuration, and active SMB mappings.",
        command=(
            "Get-PSDrive -PSProvider FileSystem | Where-Object DisplayRoot | Select-Object Name, DisplayRoot, Root, Free; "
            "Get-SmbMapping -ErrorAction SilentlyContinue | Select-Object LocalPath, RemotePath, Status; "
            "Get-SmbClientConfiguration -ErrorAction SilentlyContinue | Select-Object EnableSecuritySignature, RequireSecuritySignature"
        ),
        requires_approval=False,
    ),
    "Get-OfflineFilesStatus": SupportTool(
        name="Get-OfflineFilesStatus",
        tier=1,
        type="readonly",
        description="Check Offline Files service and cache status.",
        command=(
            "Get-Service CscService -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; "
            "Get-CimInstance -Namespace root\\cimv2 -ClassName Win32_OfflineFilesCache -ErrorAction SilentlyContinue | "
            "Select-Object Enabled, Active, Location"
        ),
        requires_approval=False,
    ),
    "Get-RemoteSupportToolStatus": SupportTool(
        name="Get-RemoteSupportToolStatus",
        tier=1,
        type="readonly",
        description="Check common remote support and remote access tools.",
        command=(
            "Get-Process AnyDesk,TeamViewer,QuickAssist,msra,Tailscale,RemoteHelp -ErrorAction SilentlyContinue | "
            "Select-Object Name, Id, CPU, StartTime; "
            "Get-Service AnyDesk,TeamViewer,Tailscale -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType; "
            "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "-ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'AnyDesk|TeamViewer|Quick Assist|Remote Help|Tailscale|Citrix|Workspace' } | "
            "Select-Object -First 15 DisplayName, DisplayVersion, Publisher"
        ),
        requires_approval=False,
    ),
    "Get-CitrixVDIStatus": SupportTool(
        name="Get-CitrixVDIStatus",
        tier=1,
        type="readonly",
        description="Check Citrix Workspace, Receiver, and active VDI session processes.",
        command=(
            "Get-Process SelfService,Receiver,CDViewer,wfica32,AuthManSvr,concentr -ErrorAction SilentlyContinue | "
            "Select-Object Name, Id, CPU, StartTime; "
            "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "-ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'Citrix|Workspace|Receiver' } | "
            "Select-Object -First 10 DisplayName, DisplayVersion, Publisher"
        ),
        requires_approval=False,
    ),
    "Get-AssetComplianceStatus": SupportTool(
        name="Get-AssetComplianceStatus",
        tier=1,
        type="readonly",
        description="Collect asset identity, BIOS, domain, encryption, Defender, and management status.",
        command=(
            "Get-CimInstance Win32_ComputerSystem | Select-Object Name, Manufacturer, Model, Domain, PartOfDomain; "
            "Get-CimInstance Win32_BIOS | Select-Object SerialNumber, SMBIOSBIOSVersion; "
            "Get-BitLockerVolume -ErrorAction SilentlyContinue | Select-Object MountPoint, ProtectionStatus, VolumeStatus; "
            "Get-MpComputerStatus -ErrorAction SilentlyContinue | Select-Object AntivirusEnabled, RealTimeProtectionEnabled; "
            "Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -like '*EnterpriseMgmt*' } | "
            "Select-Object -First 5 TaskName, TaskPath, State"
        ),
        requires_approval=False,
    ),
    "Clear-TempFiles": SupportTool(
        name="Clear-TempFiles",
        tier=2,
        type="action",
        description="Remove user temporary files.",
        command=CLEAN_TEMP_COMMAND,
        requires_approval=True,
    ),
    "Run-PerformanceCleanup": SupportTool(
        name="Run-PerformanceCleanup",
        tier=2,
        type="action",
        description="Clear temporary files to reduce common endpoint performance drag.",
        command=CLEAN_TEMP_COMMAND,
        requires_approval=True,
    ),
    "Flush-DNS": SupportTool(
        name="Flush-DNS",
        tier=2,
        type="action",
        description="Clear the local DNS resolver cache.",
        command="Clear-DnsClientCache; Write-Output 'DNS Cache Flushed Successfully'",
        requires_approval=True,
    ),
    "Restart-NetAdapter": SupportTool(
        name="Restart-NetAdapter",
        tier=2,
        type="action",
        description="Disable and re-enable active network adapters.",
        command="Get-NetAdapter | Where-Object Status -eq 'Up' | Restart-NetAdapter -Confirm:$false; Write-Output 'Active adapters restarted.'",
        requires_approval=True,
    ),
    "Renew-DHCPLease": SupportTool(
        name="Renew-DHCPLease",
        tier=2,
        type="action",
        description="Release and request a new IPv4 address from DHCP.",
        command="ipconfig /release; ipconfig /renew; Write-Output 'DHCP Lease Successfully Renewed.'",
        requires_approval=True,
    ),
    "Reset-OutlookClientState": SupportTool(
        name="Reset-OutlookClientState",
        tier=2,
        type="action",
        description="Reset Outlook navigation pane and clear Outlook RoamCache.",
        command=(
            "Stop-Process -Name OUTLOOK -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\Microsoft\\Outlook\\RoamCache\\*\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Start-Process outlook.exe -ArgumentList '/resetnavpane' -ErrorAction SilentlyContinue; "
            "Write-Output 'Outlook client state reset requested.'"
        ),
        requires_approval=True,
    ),
    "Clear-TeamsCache": SupportTool(
        name="Clear-TeamsCache",
        tier=2,
        type="action",
        description="Close Teams and clear common Teams client cache folders.",
        command=(
            "Stop-Process -Name Teams,ms-teams -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:APPDATA\\Microsoft\\Teams\\Cache\\*\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\Packages\\MSTeams_8wekyb3d8bbwe\\LocalCache\\Microsoft\\MSTeams\\*\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Write-Output 'Teams cache cleared. Ask the user to reopen Teams.'"
        ),
        requires_approval=True,
    ),
    "Restart-PrintSpooler": SupportTool(
        name="Restart-PrintSpooler",
        tier=2,
        type="action",
        description="Restart the Windows Print Spooler service.",
        command="Restart-Service -Name Spooler -Force; Write-Output 'Print Spooler restarted.'",
        requires_approval=True,
    ),
    "Resume-BitLockerProtection": SupportTool(
        name="Resume-BitLockerProtection",
        tier=3,
        type="action",
        description="Resume BitLocker protection on volumes where protection is suspended.",
        command=(
            "Get-BitLockerVolume | Where-Object { $_.ProtectionStatus -eq 'Off' } | "
            "ForEach-Object { Resume-BitLocker -MountPoint $_.MountPoint -ErrorAction Continue }; "
            "Write-Output 'BitLocker protection resume attempted where applicable.'"
        ),
        requires_approval=True,
    ),
    "Purge-KerberosTickets": SupportTool(
        name="Purge-KerberosTickets",
        tier=2,
        type="action",
        description="Purge cached Kerberos tickets so the user can reauthenticate.",
        command="klist purge; Write-Output 'Kerberos tickets purged. Ask the user to sign in again.'",
        requires_approval=True,
    ),
    "Sync-IntuneDevice": SupportTool(
        name="Sync-IntuneDevice",
        tier=2,
        type="action",
        description="Trigger Intune device management sync from local scheduled tasks.",
        command=(
            "Get-ScheduledTask | Where-Object { $_.TaskPath -like '*EnterpriseMgmt*' -and $_.TaskName -eq 'PushLaunch' } | "
            "Start-ScheduledTask; Write-Output 'Intune device sync requested.'"
        ),
        requires_approval=True,
    ),
    "Restart-WindowsUpdateServices": SupportTool(
        name="Restart-WindowsUpdateServices",
        tier=2,
        type="action",
        description="Restart Windows Update related services.",
        command=(
            "Restart-Service -Name wuauserv,bits,cryptsvc -Force -ErrorAction Continue; "
            "Write-Output 'Windows Update related services restarted.'"
        ),
        requires_approval=True,
    ),
    "Reset-Winsock": SupportTool(
        name="Reset-Winsock",
        tier=3,
        type="action",
        description="Reset Winsock and TCP/IP. Reboot is required.",
        command=(
            "netsh winsock reset; netsh int ip reset; "
            "Write-Output 'Winsock and TCP/IP reset successfully. A SYSTEM REBOOT IS REQUIRED to complete the fix.'"
        ),
        requires_approval=True,
    ),
    "Clear-BrowserCache": SupportTool(
        name="Clear-BrowserCache",
        tier=2,
        type="action",
        description="Close common browsers and clear current-user browser cache folders.",
        command=(
            "Stop-Process -Name msedge,chrome,firefox -Force -ErrorAction SilentlyContinue; "
            "$paths=@("
            "\"$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\\Default\\Cache\\*\","
            "\"$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\\Default\\Code Cache\\*\","
            "\"$env:LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Cache\\*\","
            "\"$env:LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Code Cache\\*\","
            "\"$env:APPDATA\\Mozilla\\Firefox\\Profiles\\*\\cache2\\entries\\*\"); "
            "$paths | ForEach-Object { Remove-Item $_ -Recurse -Force -ErrorAction SilentlyContinue }; "
            "Write-Output 'Browser cache cleared for Edge, Chrome, and Firefox where present.'"
        ),
        requires_approval=True,
    ),
    "Reset-OneDriveSync": SupportTool(
        name="Reset-OneDriveSync",
        tier=2,
        type="action",
        description="Reset the OneDrive sync client and restart it when available.",
        command=(
            "Stop-Process -Name OneDrive -Force -ErrorAction SilentlyContinue; "
            "$paths=@(\"$env:LOCALAPPDATA\\Microsoft\\OneDrive\\OneDrive.exe\","
            "\"$env:ProgramFiles\\Microsoft OneDrive\\OneDrive.exe\","
            "\"${env:ProgramFiles(x86)}\\Microsoft OneDrive\\OneDrive.exe\"); "
            "$exe=$paths | Where-Object { Test-Path $_ } | Select-Object -First 1; "
            "if ($exe) { Start-Process $exe -ArgumentList '/reset'; Start-Sleep -Seconds 5; Start-Process $exe; "
            "Write-Output 'OneDrive sync reset requested.' } else { Write-Output 'OneDrive executable was not found.' }"
        ),
        requires_approval=True,
    ),
    "Clear-OfficeDocumentCache": SupportTool(
        name="Clear-OfficeDocumentCache",
        tier=2,
        type="action",
        description="Close Office apps and clear the Microsoft Office document cache.",
        command=(
            "Stop-Process -Name WINWORD,EXCEL,POWERPNT,ONENOTE,MSACCESS,MSPUB,MSOSYNC -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\Microsoft\\Office\\16.0\\OfficeFileCache\\*\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Write-Output 'Office document cache cleared. Ask the user to reopen Office apps.'"
        ),
        requires_approval=True,
    ),
    "Clear-AdobeReaderCache": SupportTool(
        name="Clear-AdobeReaderCache",
        tier=2,
        type="action",
        description="Close Adobe Reader/Acrobat and clear common current-user cache folders.",
        command=(
            "Stop-Process -Name AcroRd32,Acrobat -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:APPDATA\\Adobe\\Acrobat\\DC\\Cache\\*\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\Adobe\\Acrobat\\DC\\Cache\\*\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Write-Output 'Adobe Reader/Acrobat cache cleared where present.'"
        ),
        requires_approval=True,
    ),
    "Clear-CollaborationAppCaches": SupportTool(
        name="Clear-CollaborationAppCaches",
        tier=2,
        type="action",
        description="Close Zoom, Webex, and Slack and clear common current-user cache folders.",
        command=(
            "Stop-Process -Name Zoom,Webex,ptoneclk,Slack,CiscoCollabHost -Force -ErrorAction SilentlyContinue; "
            "$paths=@("
            "\"$env:APPDATA\\Zoom\\data\\*\","
            "\"$env:LOCALAPPDATA\\WebEx\\Cache\\*\","
            "\"$env:APPDATA\\Cisco\\Webex\\Cache\\*\","
            "\"$env:APPDATA\\Slack\\Cache\\*\","
            "\"$env:APPDATA\\Slack\\Code Cache\\*\"); "
            "$paths | ForEach-Object { Remove-Item $_ -Recurse -Force -ErrorAction SilentlyContinue }; "
            "Write-Output 'Collaboration app caches cleared where present.'"
        ),
        requires_approval=True,
    ),
    "Restart-AudioServices": SupportTool(
        name="Restart-AudioServices",
        tier=2,
        type="action",
        description="Restart Windows audio services for speaker, microphone, or headset issues.",
        command="Restart-Service -Name Audiosrv,AudioEndpointBuilder -Force -ErrorAction Continue; Write-Output 'Windows audio services restarted.'",
        requires_approval=True,
    ),
    "Restart-CameraFrameServer": SupportTool(
        name="Restart-CameraFrameServer",
        tier=2,
        type="action",
        description="Restart the Windows Camera Frame Server service when present.",
        command=(
            "$svc=Get-Service FrameServer -ErrorAction SilentlyContinue; "
            "if ($svc) { Restart-Service FrameServer -Force -ErrorAction Continue; Write-Output 'Camera Frame Server restarted.' } "
            "else { Write-Output 'Camera Frame Server service was not found on this endpoint.' }"
        ),
        requires_approval=True,
    ),
    "Restart-BluetoothService": SupportTool(
        name="Restart-BluetoothService",
        tier=2,
        type="action",
        description="Restart the Bluetooth Support Service for pairing/device issues.",
        command="Restart-Service -Name bthserv -Force -ErrorAction Continue; Write-Output 'Bluetooth Support Service restarted.'",
        requires_approval=True,
    ),
    "Restart-RemoteDesktopServices": SupportTool(
        name="Restart-RemoteDesktopServices",
        tier=3,
        type="action",
        description="Restart Remote Desktop Services. This may disconnect active RDP sessions.",
        command="Restart-Service -Name TermService -Force -ErrorAction Continue; Write-Output 'Remote Desktop Services restart attempted. Active RDP sessions may have been disconnected.'",
        requires_approval=True,
    ),
    "Resync-SystemTime": SupportTool(
        name="Resync-SystemTime",
        tier=2,
        type="action",
        description="Start Windows Time if needed and request time resynchronization.",
        command="Start-Service w32time -ErrorAction SilentlyContinue; w32tm /resync /force; Write-Output 'System time resync requested.'",
        requires_approval=True,
    ),
    "Update-DefenderSignatures": SupportTool(
        name="Update-DefenderSignatures",
        tier=2,
        type="action",
        description="Update Microsoft Defender antivirus signatures.",
        command="Update-MpSignature; Write-Output 'Microsoft Defender signature update requested.'",
        requires_approval=True,
    ),
    "Restart-SCCMClient": SupportTool(
        name="Restart-SCCMClient",
        tier=2,
        type="action",
        description="Restart the Configuration Manager/SCCM client service when installed.",
        command=(
            "$svc=Get-Service CcmExec -ErrorAction SilentlyContinue; "
            "if ($svc) { Restart-Service CcmExec -Force -ErrorAction Continue; Write-Output 'SCCM client service restarted.' } "
            "else { Write-Output 'SCCM client service was not found on this endpoint.' }"
        ),
        requires_approval=True,
    ),
    "Refresh-GroupPolicy": SupportTool(
        name="Refresh-GroupPolicy",
        tier=2,
        type="action",
        description="Force a user and computer Group Policy refresh.",
        command="gpupdate /force; Write-Output 'Group Policy refresh requested.'",
        requires_approval=True,
    ),
    "Restart-ExplorerShell": SupportTool(
        name="Restart-ExplorerShell",
        tier=2,
        type="action",
        description="Restart Windows Explorer shell for taskbar, Start menu, or File Explorer issues.",
        command="Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Process explorer.exe; Write-Output 'Windows Explorer shell restarted.'",
        requires_approval=True,
    ),
    "Restart-WindowsSearchService": SupportTool(
        name="Restart-WindowsSearchService",
        tier=2,
        type="action",
        description="Restart Windows Search indexing services.",
        command="Restart-Service -Name WSearch -Force -ErrorAction Continue; Write-Output 'Windows Search service restarted.'",
        requires_approval=True,
    ),
    "Reset-WindowsStoreCache": SupportTool(
        name="Reset-WindowsStoreCache",
        tier=2,
        type="action",
        description="Reset Microsoft Store cache with wsreset.",
        command="Start-Process wsreset.exe -Wait -ErrorAction SilentlyContinue; Write-Output 'Microsoft Store cache reset requested.'",
        requires_approval=True,
    ),
    "Reset-WindowsUpdateCache": SupportTool(
        name="Reset-WindowsUpdateCache",
        tier=3,
        type="action",
        description="Reset Windows Update cache folders and restart update services.",
        command=(
            "Stop-Service wuauserv,bits,cryptsvc -Force -ErrorAction SilentlyContinue; "
            "Rename-Item \"$env:SystemRoot\\SoftwareDistribution\" \"SoftwareDistribution.old\" -ErrorAction SilentlyContinue; "
            "Rename-Item \"$env:SystemRoot\\System32\\catroot2\" \"catroot2.old\" -ErrorAction SilentlyContinue; "
            "Start-Service cryptsvc,bits,wuauserv -ErrorAction Continue; "
            "Write-Output 'Windows Update cache reset attempted.'"
        ),
        requires_approval=True,
    ),
    "Repair-SystemFiles": SupportTool(
        name="Repair-SystemFiles",
        tier=3,
        type="action",
        description="Run System File Checker to repair protected Windows system files.",
        command="sfc /scannow; Write-Output 'System File Checker scan completed.'",
        requires_approval=True,
    ),
    "Rescan-PnPDevices": SupportTool(
        name="Rescan-PnPDevices",
        tier=2,
        type="action",
        description="Rescan Plug and Play devices to redetect USB, camera, docking, display, and peripheral hardware.",
        command="pnputil /scan-devices; Write-Output 'Plug and Play device rescan requested.'",
        requires_approval=True,
    ),
    "Set-BalancedPowerPlan": SupportTool(
        name="Set-BalancedPowerPlan",
        tier=2,
        type="action",
        description="Switch Windows to the Balanced power plan.",
        command=(
            "powercfg /setactive SCHEME_BALANCED; "
            "Write-Output 'Balanced power plan activated where supported.'"
        ),
        requires_approval=True,
    ),
    "Clear-UserShellCache": SupportTool(
        name="Clear-UserShellCache",
        tier=2,
        type="action",
        description="Restart Explorer and clear current-user icon and thumbnail cache files.",
        command=(
            "Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\IconCache.db\" -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\Microsoft\\Windows\\Explorer\\iconcache*\" -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$env:LOCALAPPDATA\\Microsoft\\Windows\\Explorer\\thumbcache*\" -Force -ErrorAction SilentlyContinue; "
            "Start-Process explorer.exe; "
            "Write-Output 'User shell icon and thumbnail caches cleared.'"
        ),
        requires_approval=True,
    ),
    "Restart-WorkstationService": SupportTool(
        name="Restart-WorkstationService",
        tier=3,
        type="action",
        description="Restart the Workstation service for mapped drive or SMB client issues. Existing network sessions may disconnect.",
        command=(
            "Restart-Service -Name LanmanWorkstation -Force -ErrorAction Continue; "
            "Write-Output 'Workstation service restart attempted. Existing network drive sessions may reconnect.'"
        ),
        requires_approval=True,
    ),
    "Restart-OfflineFilesService": SupportTool(
        name="Restart-OfflineFilesService",
        tier=3,
        type="action",
        description="Restart the Offline Files service for sync/cache issues.",
        command=(
            "Restart-Service -Name CscService -Force -ErrorAction Continue; "
            "Write-Output 'Offline Files service restart attempted.'"
        ),
        requires_approval=True,
    ),
    "Restart-RemoteSupportTools": SupportTool(
        name="Restart-RemoteSupportTools",
        tier=2,
        type="action",
        description="Restart common remote support services such as AnyDesk, TeamViewer, and Tailscale when installed.",
        command=(
            "Get-Service AnyDesk,TeamViewer,Tailscale -ErrorAction SilentlyContinue | "
            "ForEach-Object { Restart-Service -Name $_.Name -Force -ErrorAction Continue }; "
            "Write-Output 'Remote support service restart attempted where tools were installed.'"
        ),
        requires_approval=True,
    ),
    "Restart-CitrixWorkspace": SupportTool(
        name="Restart-CitrixWorkspace",
        tier=2,
        type="action",
        description="Close common Citrix Workspace client processes so the user can reopen a clean VDI session.",
        command=(
            "Stop-Process -Name SelfService,Receiver,CDViewer,wfica32,AuthManSvr,concentr -Force -ErrorAction SilentlyContinue; "
            "Write-Output 'Citrix Workspace client processes were closed. Ask the user to reopen Citrix Workspace.'"
        ),
        requires_approval=True,
    ),
}


def get_tools(names: Iterable[str], include_command: bool = False) -> List[dict]:
    return [TOOLS[name].to_dict(include_command=include_command) for name in names if name in TOOLS]


def get_tool(name: Optional[str], include_command: bool = False) -> Optional[dict]:
    if not name or name not in TOOLS:
        return None
    return TOOLS[name].to_dict(include_command=include_command)


def execute_tool(name: str, approved: bool, executor=None) -> dict:
    """Execute an approved remediation tool and return a structured result."""

    if name not in TOOLS:
        raise ValueError(f"Unknown remediation action: {name}")

    tool = TOOLS[name]
    if tool.type != "action":
        raise ValueError(f"{name} is not a remediation action")
    if tool.requires_approval and not approved:
        raise ValueError(f"{name} requires explicit user approval")

    executor = executor or run_powershell
    result = executor(tool.command)
    return {
        "action": tool.to_dict(include_command=False),
        "result": result,
    }


def disable_startup_app(app_name: str, approved: bool, executor=None) -> dict:
    """Disable matching Windows startup entries after explicit approval."""

    target = _clean_startup_app_name(app_name)
    if not target:
        raise ValueError("disable_startup_app requires a non-empty app name")
    if not approved:
        raise ValueError("Disable-StartupApp requires explicit user approval")

    executor = executor or run_powershell
    command = _disable_startup_app_command(target)
    result = executor(command)
    return {
        "action": {
            "name": "Disable-StartupApp",
            "tier": 2,
            "type": "action",
            "description": f"Disable '{target}' from Windows startup without removing its Startup Apps entry where supported.",
            "requires_approval": True,
        },
        "result": result,
    }


def execute_diagnostic_tool(name: str, executor=None) -> dict:
    """Execute a read-only diagnostic tool and return a structured result."""

    if name not in TOOLS:
        raise ValueError(f"Unknown diagnostic tool: {name}")

    tool = TOOLS[name]
    if tool.type != "readonly":
        raise ValueError(f"{name} is not a read-only diagnostic tool")

    executor = executor or run_powershell
    result = executor(tool.command)
    return {
        "diagnostic": tool.to_dict(include_command=False),
        "result": result,
    }


def get_tier_tools(tier_level: int) -> List[str]:
    return [name for name, tool in TOOLS.items() if tool.tier == tier_level]


def _clean_startup_app_name(app_name: str) -> str:
    cleaned = re.sub(r"\s+", " ", str(app_name or "")).strip(" .\"'")
    cleaned = re.sub(
        r"\b(app|application|program|process|startup|start-up|entry|entries|item|items)\b",
        " ",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .\"'")
    if len(cleaned) > 80:
        cleaned = cleaned[:80].strip()
    if re.search(r"[\r\n;&|`$<>]", cleaned):
        return ""
    if cleaned.lower() in {"my", "mine", "all", "everything", "these", "those"}:
        return ""
    return cleaned


def _ps_single_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _disable_startup_app_command(app_name: str) -> str:
    target = _ps_single_quote(app_name)
    return (
        f"$target={target}; "
        "$backupRoot=Join-Path $env:LOCALAPPDATA 'EndpointSupportAgent\\DisabledStartupApps'; "
        "New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null; "
        "$backupPath=Join-Path $backupRoot (Get-Date -Format 'yyyyMMdd-HHmmss'); "
        "New-Item -ItemType Directory -Path $backupPath -Force | Out-Null; "
        "$backupFile=Join-Path $backupPath 'disabled-startup-items.jsonl'; "
        "$disabledBytes=[byte[]](0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00); "
        "function Set-StartupApprovedDisabled($Path,$Name) { "
        "New-Item -Path $Path -Force | Out-Null; "
        "New-ItemProperty -Path $Path -Name $Name -PropertyType Binary -Value $disabledBytes -Force | Out-Null "
        "}; "
        "$matches=@(); "
        "$runKeys=@("
        "@{Path='HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'; Scope='HKCU'},"
        "@{Path='HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'; Scope='HKLM'},"
        "@{Path='HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run'; Scope='HKLM32'}"
        "); "
        "foreach ($key in $runKeys) { "
        "if (Test-Path $key.Path) { "
        "$props=Get-ItemProperty -LiteralPath $key.Path -ErrorAction SilentlyContinue; "
        "foreach ($property in $props.PSObject.Properties) { "
        "if ($property.Name -notlike 'PS*' -and "
        "($property.Name -like \"*$target*\" -or [string]$property.Value -like \"*$target*\")) { "
        "$matches += [PSCustomObject]@{Kind='Registry'; Path=$key.Path; Scope=$key.Scope; Name=$property.Name; Command=[string]$property.Value} "
        "} } } }; "
        "$startupFolders=@("
        "@{Path=[Environment]::GetFolderPath('Startup'); Scope='UserStartup'},"
        "@{Path=[Environment]::GetFolderPath('CommonStartup'); Scope='CommonStartup'}"
        "); "
        "$shell=$null; try { $shell=New-Object -ComObject WScript.Shell } catch {}; "
        "foreach ($folder in $startupFolders) { "
        "if ($folder.Path -and (Test-Path $folder.Path)) { "
        "Get-ChildItem -LiteralPath $folder.Path -File -ErrorAction SilentlyContinue | ForEach-Object { "
        "$shortcutTarget=''; $shortcutArguments=''; "
        "if ($_.Extension -ieq '.lnk' -and $shell) { "
        "try { $shortcut=$shell.CreateShortcut($_.FullName); $shortcutTarget=$shortcut.TargetPath; $shortcutArguments=$shortcut.Arguments } catch {} "
        "}; "
        "$searchText=\"$($_.Name) $($_.FullName) $shortcutTarget $shortcutArguments\"; "
        "if ($searchText -like \"*$target*\") { "
        "$matches += [PSCustomObject]@{Kind='StartupFile'; Path=$_.FullName; Scope=$folder.Scope; Name=$_.Name; Command=$searchText} "
        "} } } }; "
        "Get-ScheduledTask -ErrorAction SilentlyContinue | ForEach-Object { "
        "$task=$_; "
        "$actionText=($task.Actions | ForEach-Object { \"$($_.Execute) $($_.Arguments)\" }) -join ' '; "
        "$searchText=\"$($task.TaskName) $($task.TaskPath) $actionText\"; "
        "if ($searchText -like \"*$target*\") { "
        "$matches += [PSCustomObject]@{Kind='ScheduledTask'; Path=$task.TaskPath; Scope='ScheduledTask'; Name=$task.TaskName; Command=$searchText} "
        "} }; "
        "if (-not $matches) { Write-Output \"No startup entry matching '$target' was found.\"; exit 0 }; "
        "$index=0; $disabled=@(); $failed=@(); "
        "foreach ($match in $matches) { "
        "$match | ConvertTo-Json -Compress | Add-Content -Path $backupFile; "
        "try { "
        "if ($match.Kind -eq 'Registry') { "
        "$approvedPath = if ($match.Path -like 'HKCU:\\*') { "
        "'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run' "
        "} elseif ($match.Path -like 'HKLM:\\Software\\WOW6432Node\\*') { "
        "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32' "
        "} else { "
        "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run' "
        "}; "
        "Set-StartupApprovedDisabled $approvedPath $match.Name "
        "} elseif ($match.Kind -eq 'StartupFile') { "
        "Copy-Item -LiteralPath $match.Path -Destination (Join-Path $backupPath $match.Name) -Force -ErrorAction SilentlyContinue; "
        "$approvedPath = if ($match.Scope -eq 'CommonStartup') { "
        "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder' "
        "} else { "
        "'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder' "
        "}; "
        "Set-StartupApprovedDisabled $approvedPath $match.Name "
        "} elseif ($match.Kind -eq 'ScheduledTask') { "
        "Disable-ScheduledTask -TaskName $match.Name -TaskPath $match.Path -ErrorAction Stop | Out-Null "
        "} "
        "$disabled += \"$($match.Name) [$($match.Scope)/$($match.Kind)]\" "
        "} catch { "
        "$failed += \"$($match.Name) [$($match.Scope)/$($match.Kind)]: $($_.Exception.Message)\" "
        "}; "
        "$index++ "
        "}; "
        "if ($disabled.Count -gt 0) { Write-Output ('Disabled startup entries: ' + ($disabled -join ', ')) }; "
        "if ($failed.Count -gt 0) { Write-Output ('Failed to disable some entries: ' + ($failed -join '; ')) }; "
        "Write-Output \"Backup saved under $backupPath\""
    )


def run_powershell(command: str, timeout: int = 60) -> dict:
    """Run PowerShell and return stdout, stderr, and exit status."""

    try:
        result = subprocess.run(
            ["powershell", "-Command", command],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except Exception as exc:
        return {"ok": False, "stdout": "", "stderr": str(exc), "returncode": -1}

    return {
        "ok": result.returncode == 0,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
        "returncode": result.returncode,
    }
