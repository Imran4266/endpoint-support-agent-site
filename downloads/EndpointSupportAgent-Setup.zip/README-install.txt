Endpoint Support Agent Setup Package
====================================

This package installs the Endpoint Support Agent on a Windows endpoint.

What is included
----------------
- Conversational Endpoint Support Agent CLI
- Local MCP server and support tools
- Endpoint diagnostics and approval-gated remediation actions
- OEM driver workflow for Dell, HP, Lenovo, and Surface guidance
- Windows setup executable, PowerShell installer, and launch helper

Install
-------
1. Download EndpointSupportAgent-Setup.exe.
2. Run the setup file.
3. Edit the generated .env file in the install folder.
4. Add OPENROUTER_API_KEY if you want LLM-powered routing.
5. Launch Start-EndpointSupportAgent.ps1 or the Start Menu shortcut.

Advanced install
----------------
The EXE contains the same setup payload as EndpointSupportAgent-Setup.zip.
If you use the ZIP directly, extract it and run:

   Set-ExecutionPolicy -Scope Process Bypass -Force
   .\install-endpoint-support-agent.ps1

Default install path
--------------------
%LOCALAPPDATA%\EndpointSupportAgent

Requirements
------------
- Windows 10 or Windows 11
- Python 3.10 or newer
- Internet access for Python dependencies, model list, and OEM utility installs
- Node.js/npm if you want the optional companion MCP servers built locally
- Administrator session for OEM driver utility installation and driver remediation

Safety note
-----------
The agent separates read-only diagnostics from endpoint-changing remediation.
Remediation actions ask for explicit approval before running.
