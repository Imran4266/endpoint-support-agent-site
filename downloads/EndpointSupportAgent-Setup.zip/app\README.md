# Endpoint Support Agent

Windows endpoint support agent using a hybrid MCP architecture.

- `agent.py` is the conversational CLI.
- `mcp_client.py` starts and calls the local MCP resolver.
- `mcp_server/server.py` exposes the `resolve_issue` tool.
- `mcp_server/server.py` also exposes `execute_remediation` for approved fixes.
- `mcp_server/issue_database.py` contains local troubleshooting knowledge.
- `GITHUB_KNOWLEDGE_FILE` can point to a JSON export of GitHub runbooks or issues.
- `GITHUB_MCP_COMMAND` can point to a live GitHub MCP server command when one is configured.

## Run

1. Copy `.env.example` to `.env`.
2. Add `OPENROUTER_API_KEY` if you want optional LLM issue-context extraction.
3. Set `OPENROUTER_MODEL` as the default fallback model.
4. Optionally set `GITHUB_KNOWLEDGE_FILE=path\to\github_knowledge.json`.
5. Optionally set `GITHUB_MCP_COMMAND`, `GITHUB_MCP_TOOL`, and `GITHUB_REPOSITORY` for live GitHub MCP lookup.
6. Run `pip install -r requirements.txt`.
7. Run `python agent.py`. The app displays the header first, then lets you choose from the live OpenRouter model list using Up/Down arrow keys and Enter. The selector fetches text models that support tool calling, since MCP routing depends on tools.

`RESOLVER_LLM_CLASSIFIER_ENABLED=false` keeps the local support resolver on fast keyword/IDF runbook matching. Enable it only if you want the resolver subprocess to make its own LLM classification call before falling back to local matching.

## Model picker

- Up/Down: move through the listed models.
- PageUp/PageDown: jump a page.
- Enter: confirm the highlighted model.
- `o`: show only OpenRouter router models, such as `openrouter/auto`.
- `f`: show only free models.
- `d`: show only paid models.
- `/`: search models.
- `a`: show all models after searching.
- `c`: enter a custom OpenRouter model ID.
- `q`: use the default fallback model.

## Chat commands

- `model` or `change model`: reopen the live model picker and switch the active LLM for the current session.
- `reset` or `new`: start a fresh conversation.
- `exit` or `quit`: close the agent.

## Remediation

The agent recommends remediation through MCP resolution results. If a recommended action is available, the CLI asks for explicit approval before calling the MCP `execute_remediation` tool. Declining the prompt leaves the endpoint unchanged.
Every local MCP issue record includes a recommended remediation action, and every remediation action requires explicit user approval before execution.
