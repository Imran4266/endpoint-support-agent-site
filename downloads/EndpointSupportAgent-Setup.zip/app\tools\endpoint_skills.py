import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


@dataclass(frozen=True)
class EndpointSkill:
    id: str
    title: str
    description: str
    categories: List[str]
    keywords: List[str]
    capability_intents: List[str]
    diagnostic_strategy: str
    safety_note: str
    escalation_signals: List[str]

    def to_dict(self, score: Optional[float] = None) -> Dict:
        data = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "categories": self.categories,
            "capability_intents": self.capability_intents,
            "diagnostic_strategy": self.diagnostic_strategy,
            "safety_note": self.safety_note,
            "escalation_signals": self.escalation_signals,
        }
        if score is not None:
            data["score"] = round(score, 2)
        return data


SKILLS: List[EndpointSkill] = [
    EndpointSkill(
        id="performance.triage",
        title="Performance Triage",
        description="Diagnose slow, hanging, freezing, disk-space, memory, and startup-load issues.",
        categories=["performance", "storage", "system"],
        keywords=[
            "slow",
            "sluggish",
            "hang",
            "freeze",
            "lag",
            "cpu",
            "memory",
            "disk",
            "storage",
            "temp",
            "temporary",
            "startup",
            "boot",
            "cleanup",
        ],
        capability_intents=["performance.cleanup", "storage.clear_temp", "startup.disable_app", "system.repair_files"],
        diagnostic_strategy="Check CPU, memory, startup apps, free disk space, and temporary files before applying cleanup.",
        safety_note="Cleanup and startup changes require approval; app restarts should be targeted to the confirmed offender.",
        escalation_signals=[
            "repeated blue screens",
            "disk health warnings",
            "security alerts",
            "device overheating or sudden shutdowns",
        ],
    ),
    EndpointSkill(
        id="network.recovery",
        title="Network Recovery",
        description="Handle internet, Wi-Fi, DNS, VPN, DHCP, and connection-drop issues.",
        categories=["network", "vpn", "rdp"],
        keywords=[
            "internet",
            "network",
            "wifi",
            "wi-fi",
            "ethernet",
            "dns",
            "vpn",
            "dhcp",
            "ip",
            "connect",
            "disconnect",
            "timeout",
            "website",
            "gateway",
            "rdp",
            "remote",
        ],
        capability_intents=["network.flush_dns", "network.restart_adapter", "network.renew_dhcp", "time.resync"],
        diagnostic_strategy="Check adapter status, IP configuration, DNS resolution, VPN state, and internet reachability before resetting anything.",
        safety_note="Restarting adapters can briefly disconnect the user; VPN and RDP changes should avoid breaking the current remote session.",
        escalation_signals=[
            "multiple users affected",
            "no IP address from DHCP",
            "corporate VPN authentication failure",
            "firewall or proxy blocks",
        ],
    ),
    EndpointSkill(
        id="productivity.app_repair",
        title="Productivity App Repair",
        description="Repair common business apps such as Outlook, Teams, OneDrive, Office, browsers, Adobe, Slack, Webex, and Zoom.",
        categories=["outlook", "teams", "onedrive", "office", "browser", "adobe", "collaboration", "store-apps", "vdi"],
        keywords=[
            "outlook",
            "teams",
            "onedrive",
            "office",
            "word",
            "excel",
            "powerpoint",
            "browser",
            "chrome",
            "edge",
            "firefox",
            "adobe",
            "acrobat",
            "pdf",
            "zoom",
            "webex",
            "slack",
            "citrix",
            "cache",
            "sync",
            "sign",
            "login",
        ],
        capability_intents=[
            "browser.clear_cache",
            "onedrive.reset_sync",
            "teams.clear_cache",
            "outlook.reset_client",
            "office.clear_document_cache",
            "adobe.clear_cache",
            "collaboration.clear_cache",
            "citrix.restart_workspace",
            "store.reset_cache",
        ],
        diagnostic_strategy="Identify the exact app and symptom, check whether the web version works, then clear app cache or restart the client when safe.",
        safety_note="Cache resets and app restarts can close the affected app; avoid profile rebuilds or reinstalls without a managed source.",
        escalation_signals=[
            "license or activation failures",
            "tenant-wide service outage",
            "data missing after sync",
            "repeated sign-in prompts across apps",
        ],
    ),
    EndpointSkill(
        id="meeting.device_readiness",
        title="Meeting Device Readiness",
        description="Troubleshoot camera, microphone, speaker, headset, Bluetooth, and meeting-client media issues.",
        categories=["audio", "camera", "bluetooth", "teams", "collaboration"],
        keywords=[
            "camera",
            "webcam",
            "microphone",
            "mic",
            "audio",
            "sound",
            "speaker",
            "headset",
            "bluetooth",
            "meeting",
            "call",
            "video",
            "blank",
            "black",
            "mute",
        ],
        capability_intents=[
            "audio.restart_services",
            "camera.restart_service",
            "bluetooth.restart_service",
            "teams.clear_cache",
            "collaboration.clear_cache",
        ],
        diagnostic_strategy="Check device presence, privacy permissions, active meeting apps, and related Windows services before restarting services.",
        safety_note="Service restarts can briefly interrupt sound, camera, or Bluetooth devices; generic driver reinstall is not automated.",
        escalation_signals=[
            "device missing from Device Manager",
            "driver error codes",
            "hardware switch or BIOS camera disabled",
            "multiple meeting apps failing after service restart",
        ],
    ),
    EndpointSkill(
        id="device.driver_triage",
        title="Device And Driver Triage",
        description="Safely triage USB, docking, display, camera, Bluetooth, scanner, and driver-detection problems.",
        categories=["camera", "bluetooth", "display-docking", "usb-peripheral", "power"],
        keywords=[
            "driver",
            "drivers",
            "oem",
            "vendor",
            "manufacturer",
            "bios",
            "firmware",
            "device",
            "usb",
            "dock",
            "docking",
            "display",
            "monitor",
            "camera",
            "webcam",
            "keyboard",
            "mouse",
            "scanner",
            "not detected",
            "not recognized",
            "pnp",
            "plug",
            "peripheral",
        ],
        capability_intents=["driver.oem_update", "devices.rescan_pnp", "camera.restart_service", "bluetooth.restart_service", "power.set_balanced"],
        diagnostic_strategy="Check problem devices, device-specific status, OEM model, and installed OEM update tools before touching drivers.",
        safety_note="Generic driver reinstall/update is blocked unless a trusted vendor, OEM, or device-management source is configured.",
        escalation_signals=[
            "driver reinstall requested",
            "device has a hardware error code",
            "firmware or BIOS dependency",
            "docking station firmware issue",
        ],
    ),
    EndpointSkill(
        id="printing.queue_recovery",
        title="Printing Queue Recovery",
        description="Diagnose printers, print queues, scanner symptoms, offline status, and spooler problems.",
        categories=["printer"],
        keywords=["printer", "printing", "print", "queue", "spooler", "offline", "scanner", "driver", "paper", "toner"],
        capability_intents=["printer.restart_spooler"],
        diagnostic_strategy="Check printer status and print queue before restarting the spooler.",
        safety_note="Restarting the spooler can interrupt active print jobs; confirm this with the user first.",
        escalation_signals=[
            "shared printer offline for multiple users",
            "driver package missing",
            "print server unavailable",
            "paper or toner fault",
        ],
    ),
    EndpointSkill(
        id="identity.security",
        title="Identity And Security Recovery",
        description="Handle sign-in tickets, BitLocker, Defender, certificate, time, and security posture issues.",
        categories=["identity", "bitlocker", "defender", "time-certificate"],
        keywords=[
            "login",
            "sign",
            "signin",
            "password",
            "kerberos",
            "ticket",
            "bitlocker",
            "recovery",
            "defender",
            "antivirus",
            "malware",
            "certificate",
            "ssl",
            "tls",
            "time",
            "clock",
        ],
        capability_intents=["identity.purge_kerberos", "time.resync", "defender.update_signatures"],
        diagnostic_strategy="Verify identity state, clock/certificate health, network reachability, and Defender status before resetting credentials or signatures.",
        safety_note="Credential, BitLocker, and security changes must remain conservative and audit-friendly.",
        escalation_signals=[
            "BitLocker recovery key required",
            "suspected compromise",
            "MFA or account lockout",
            "certificate chain failures after time resync",
        ],
    ),
    EndpointSkill(
        id="management.compliance",
        title="Endpoint Management Sync",
        description="Repair Intune, Company Portal, SCCM, Software Center, Group Policy, compliance, and inventory check-in issues.",
        categories=["intune", "sccm", "group-policy", "asset-compliance", "software", "patching"],
        keywords=[
            "intune",
            "company",
            "portal",
            "sccm",
            "software",
            "center",
            "configuration",
            "manager",
            "compliance",
            "inventory",
            "asset",
            "gpo",
            "group",
            "policy",
            "patch",
            "update",
            "deployment",
            "install",
        ],
        capability_intents=[
            "intune.sync_device",
            "sccm.restart_client",
            "group_policy.refresh",
            "asset.sync_compliance",
            "windows_update.restart_services",
            "windows_update.reset_cache",
        ],
        diagnostic_strategy="Check management client state, recent install/update events, network access, and policy status before syncing or restarting clients.",
        safety_note="Tier 3 update/cache resets can take time and may affect patch deployment state.",
        escalation_signals=[
            "device not enrolled",
            "policy conflict",
            "software deployment missing from portal",
            "many devices affected",
        ],
    ),
    EndpointSkill(
        id="windows.repair",
        title="Windows Experience Repair",
        description="Repair Windows Update, Start menu, taskbar, Explorer, Search, Store, profile shell, and system file issues.",
        categories=["patching", "shell", "search", "store-apps", "system-repair", "user-profile"],
        keywords=[
            "windows",
            "update",
            "patch",
            "taskbar",
            "start",
            "menu",
            "explorer",
            "desktop",
            "icons",
            "search",
            "index",
            "store",
            "appx",
            "msix",
            "sfc",
            "corrupt",
            "dll",
            "profile",
        ],
        capability_intents=[
            "windows_update.restart_services",
            "windows_update.reset_cache",
            "shell.restart_explorer",
            "search.restart_service",
            "store.reset_cache",
            "system.repair_files",
            "profile.clear_shell_cache",
        ],
        diagnostic_strategy="Check recent system errors, service state, pending reboot, and the affected Windows component before repair.",
        safety_note="System repairs and Windows Update cache resets are higher-impact and should be used only after simpler checks.",
        escalation_signals=[
            "repeated blue screens",
            "profile cannot load",
            "system file repair fails",
            "update rollback loop",
        ],
    ),
    EndpointSkill(
        id="file.remote_access",
        title="File And Remote Access Recovery",
        description="Handle mapped drives, file shares, Offline Files, remote support, RDP, Citrix, and access path issues.",
        categories=["file-access", "offline-files", "remote-support", "rdp", "vdi", "vpn"],
        keywords=[
            "mapped",
            "drive",
            "share",
            "smb",
            "unc",
            "file",
            "permission",
            "offline",
            "sync",
            "rdp",
            "remote",
            "citrix",
            "vdi",
            "anydesk",
            "teamviewer",
            "workspace",
        ],
        capability_intents=[
            "file_access.restart_workstation",
            "offline_files.restart_service",
            "remote_support.restart_tools",
            "citrix.restart_workspace",
            "network.flush_dns",
        ],
        diagnostic_strategy="Check network, identity, mapped-drive state, and the remote access client before restarting services.",
        safety_note="Some file and remote access service restarts are Tier 3 and can interrupt sessions or open files.",
        escalation_signals=[
            "access denied after credential refresh",
            "file share unavailable for multiple users",
            "offline files conflict",
            "active remote session would be disconnected",
        ],
    ),
]


def list_endpoint_skills() -> List[Dict]:
    return [skill.to_dict() for skill in SKILLS]


def search_endpoint_skills(query: str, limit: int = 5, category: str = "", intents: Optional[Sequence[str]] = None) -> Dict:
    ranked = rank_endpoint_skills(query, category=category, intents=intents, limit=limit)
    return {
        "tool": "search_endpoint_skills",
        "query": query,
        "skills": [skill.to_dict(score=score) for skill, score in ranked],
    }


def rank_endpoint_skills(
    text: str,
    category: str = "",
    intents: Optional[Sequence[str]] = None,
    limit: int = 3,
) -> List[Tuple[EndpointSkill, float]]:
    query_tokens = _tokens(text)
    category = str(category or "").lower()
    intent_set = {str(intent) for intent in (intents or []) if intent}
    ranked: List[Tuple[EndpointSkill, float]] = []
    text_lower = str(text or "").lower()

    for skill in SKILLS:
        score = 0.0
        if category and category in {item.lower() for item in skill.categories}:
            score += 5.0

        skill_tokens = {token for keyword in skill.keywords for token in _tokens(keyword)}
        matched_tokens = query_tokens.intersection(skill_tokens)
        score += float(len(matched_tokens))
        score += float(sum(2 for keyword in skill.keywords if keyword.lower() in text_lower and " " in keyword))

        matched_intents = intent_set.intersection(skill.capability_intents)
        score += float(len(matched_intents) * 6)

        if "driver" in query_tokens and skill.id == "device.driver_triage":
            score += 4.0
        if {"outlook", "teams", "onedrive", "office"}.intersection(query_tokens) and skill.id == "productivity.app_repair":
            score += 3.0
        if {"camera", "microphone", "audio", "bluetooth"}.intersection(query_tokens) and skill.id == "meeting.device_readiness":
            score += 2.0

        if score > 0:
            ranked.append((skill, score))

    ranked.sort(key=lambda item: (item[1], -len(item[0].capability_intents), item[0].title), reverse=True)
    return ranked[: max(1, int(limit or 3))]


def skills_for_intent(intent: str, limit: int = 2) -> List[Dict]:
    ranked = rank_endpoint_skills("", intents=[intent], limit=limit)
    return [skill.to_dict(score=score) for skill, score in ranked]


def skill_titles(skills: Iterable[Dict]) -> List[str]:
    return [str(skill.get("title")) for skill in skills if skill.get("title")]


def _tokens(text: str) -> set:
    return set(re.findall(r"[a-z0-9-]+", str(text or "").lower()))
