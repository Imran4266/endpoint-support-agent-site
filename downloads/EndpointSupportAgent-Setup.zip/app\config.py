import os
import shlex
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple

from dotenv import load_dotenv


load_dotenv()

BASE_DIR = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Settings:
    """Runtime configuration loaded from environment variables."""

    openrouter_api_key: Optional[str]
    openrouter_base_url: str
    model: str
    mcp_server_command: Tuple[str, ...]
    mcp_timeout_seconds: float
    mcp_long_timeout_seconds: float
    github_knowledge_file: Optional[str]
    github_mcp_command: Optional[Tuple[str, ...]]
    github_mcp_tool: str
    github_repository: Optional[str]
    audit_log_path: Path
    additional_mcp_servers: Dict[str, Tuple[str, ...]]
    resolver_llm_classifier_enabled: bool

def load_settings() -> Settings:
    """Create a settings object without leaking env handling into app code."""

    return Settings(
        openrouter_api_key=os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENAI_API_KEY"),
        openrouter_base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
        model=os.getenv("OPENROUTER_MODEL", os.getenv("MODEL", "openrouter/auto")),
        mcp_server_command=(
            sys.executable,
            "-m",
            "mcp_server.server",
        ),
        mcp_timeout_seconds=float(os.getenv("MCP_TIMEOUT_SECONDS", "15")),
        mcp_long_timeout_seconds=float(os.getenv("MCP_LONG_TIMEOUT_SECONDS", "1800")),
        github_knowledge_file=os.getenv("GITHUB_KNOWLEDGE_FILE"),
        github_mcp_command=_split_command(os.getenv("GITHUB_MCP_COMMAND")),
        github_mcp_tool=os.getenv("GITHUB_MCP_TOOL", "search_knowledge"),
        github_repository=os.getenv("GITHUB_REPOSITORY"),
        audit_log_path=BASE_DIR / "logs" / "audit.jsonl",
        resolver_llm_classifier_enabled=_env_bool("RESOLVER_LLM_CLASSIFIER_ENABLED", default=False),
        additional_mcp_servers={
            "filesystem": ("node", str(BASE_DIR / "servers" / "src" / "filesystem" / "dist" / "index.js"), str(BASE_DIR)),
            "memory": ("node", str(BASE_DIR / "servers" / "src" / "memory" / "dist" / "index.js")),
            "sequentialthinking": ("node", str(BASE_DIR / "servers" / "src" / "sequentialthinking" / "dist" / "index.js")),
            "everything": ("node", str(BASE_DIR / "servers" / "src" / "everything" / "dist" / "index.js"), "stdio"),
        }
    )


# Backward-compatible names for older imports.
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
MODEL = os.getenv("OPENROUTER_MODEL", os.getenv("MODEL", "openrouter/auto"))


def _split_command(command: Optional[str]) -> Optional[Tuple[str, ...]]:
    if not command:
        return None
    return tuple(shlex.split(command, posix=os.name != "nt"))


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}
