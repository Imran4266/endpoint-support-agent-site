
function Get-SystemInfo {
    [PSCustomObject]@{
        ComputerName=$env:COMPUTERNAME
        UserName=$env:USERNAME
        OS=(Get-CimInstance Win32_OperatingSystem).Caption
    } | ConvertTo-Json
}

function Get-NetworkInfo {
    Get-NetIPConfiguration | ConvertTo-Json -Depth 3
}

function Get-DiskUsage {
    Get-PSDrive -PSProvider FileSystem | Select Name,Used,Free | ConvertTo-Json
}

function Get-TopProcesses {
    Get-Process | Sort CPU -Descending | Select -First 10 | ConvertTo-Json
}

function Get-HealthReport {
    [PSCustomObject]@{
        Time=(Get-Date)
        Status="Basic Health Check Complete"
    } | ConvertTo-Json
}

function Reset-Network {
    "Requires admin approval"
}

function Clear-TempFiles {
    "Requires admin approval"
}

function Collect-SupportLogs {
    Get-EventLog -LogName System -Newest 100 | ConvertTo-Json
}

Export-ModuleMember -Function *
