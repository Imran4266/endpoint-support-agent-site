"""Local MCP runtime resolver for Endpoint Support Agent."""
