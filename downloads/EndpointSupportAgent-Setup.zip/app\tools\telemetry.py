import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from config import BASE_DIR


SENSITIVE_KEY_PARTS = (
    "api_key",
    "apikey",
    "authorization",
    "bearer",
    "client_secret",
    "password",
    "secret",
    "token",
)
MAX_TEXT_LENGTH = 700


def record_event(event_type: str, payload: Optional[Dict[str, Any]] = None, settings=None) -> None:
    """Append a redacted JSON telemetry event.

    Telemetry is best-effort: endpoint remediation should not fail because logging failed.
    """

    path = _telemetry_path(settings)
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": str(event_type or "event"),
        "payload": _redact(payload or {}),
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=True) + "\n")
    except OSError:
        return


def record_tool_execution(
    tool_name: str,
    arguments: Dict[str, Any],
    result: Dict[str, Any],
    *,
    approved: bool,
    session_id: str = "",
    settings=None,
) -> None:
    command_result = _command_result(result)
    record_event(
        "tool_execution",
        {
            "session_id": session_id,
            "tool_name": tool_name,
            "approved": bool(approved),
            "arguments": arguments,
            "ok": bool(command_result.get("ok")) if command_result else not bool(result.get("error")),
            "returncode": command_result.get("returncode") if command_result else None,
            "stdout": _short_text(command_result.get("stdout", "")) if command_result else "",
            "stderr": _short_text(command_result.get("stderr", "")) if command_result else "",
            "error": _short_text(result.get("error", "")),
            "action": result.get("action") or result.get("diagnostic") or {},
            "intent": result.get("intent") or arguments.get("intent") or "",
            "target": result.get("target") or arguments.get("target") or arguments.get("app") or "",
        },
        settings=settings,
    )


def summarize_telemetry(limit: int = 20, settings=None, path: Optional[Path] = None) -> Dict[str, Any]:
    telemetry_path = path or _telemetry_path(settings)
    if not telemetry_path.exists():
        return {
            "tool": "get_endpoint_telemetry_summary",
            "path": str(telemetry_path),
            "total_events": 0,
            "counts": {},
            "recent_events": [],
        }

    events = _read_events(telemetry_path)
    event_limit = max(1, int(limit or 20))
    counts = Counter(str(event.get("event_type") or "event") for event in events)
    return {
        "tool": "get_endpoint_telemetry_summary",
        "path": str(telemetry_path),
        "total_events": len(events),
        "counts": dict(counts),
        "recent_events": events[-event_limit:],
    }


def _telemetry_path(settings=None) -> Path:
    configured = getattr(settings, "telemetry_log_path", None)
    return Path(configured) if configured else BASE_DIR / "logs" / "telemetry.jsonl"


def _read_events(path: Path) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(item, dict):
                    events.append(item)
    except OSError:
        return []
    return events


def _command_result(result: Dict[str, Any]) -> Dict[str, Any]:
    nested = result.get("result") if isinstance(result, dict) else None
    return nested if isinstance(nested, dict) else {}


def _redact(value: Any, key: str = "") -> Any:
    key_lower = str(key or "").lower()
    if any(part in key_lower for part in SENSITIVE_KEY_PARTS):
        return "[redacted]"
    if isinstance(value, dict):
        return {str(k): _redact(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(item, key) for item in value[:50]]
    if isinstance(value, tuple):
        return [_redact(item, key) for item in value[:50]]
    if isinstance(value, str):
        return _short_text(value)
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return _short_text(str(value))


def _short_text(value: Any, limit: int = MAX_TEXT_LENGTH) -> str:
    text = str(value or "")
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."
