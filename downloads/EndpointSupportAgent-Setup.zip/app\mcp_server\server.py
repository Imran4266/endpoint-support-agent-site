import json
import sys
from typing import Any, Dict, Optional

from mcp_server.tools import MCPToolRegistry


class LocalMCPServer:
    def __init__(self, registry: MCPToolRegistry):
        self.registry = registry

    def handle(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if "id" not in request:
            return None  # Do not respond to notifications
            
        request_id = request.get("id")
        method = request.get("method")
        params = request.get("params") or {}

        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "serverInfo": {"name": "endpoint-support-local-mcp", "version": "1.0.0"},
                    "capabilities": {"tools": {}},
                }
            elif method == "tools/list":
                result = {"tools": self.registry.list_tools()}
            elif method == "tools/call":
                result = self.registry.call_tool(
                    params.get("name", ""),
                    params.get("arguments") or {},
                )
            else:
                return _error(request_id, -32601, f"Method not found: {method}")
        except ValueError as exc:
            return _error(request_id, -32602, str(exc))
        except Exception as exc:
            return _error(request_id, -32000, str(exc))

        return {"jsonrpc": "2.0", "id": request_id, "result": result}


def serve() -> None:
    server = LocalMCPServer(MCPToolRegistry())

    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            request = json.loads(line)
            response = server.handle(request)
        except json.JSONDecodeError as exc:
            response = _error(None, -32700, f"Parse error: {exc}")

        if response is not None:
            print(json.dumps(response), flush=True)


def _error(request_id, code: int, message: str) -> Dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}


if __name__ == "__main__":
    serve()
